# Whoop 两个驱动复现与可视化交付

本包包含已经执行的实验和原始证据。范围为作者提供的静态驱动模型，没有加载内核模块、操作真实设备或进行安全敏感测试。

## 先看什么

- 双击 **index.html**：离线交互演示，可逐步播放真实反例、切换五个版本并查看源码、模型和日志。不需要安装网页依赖。
- **video/whoop-reproduction-demo.mp4**：3 分 40 秒、1920×1080、无配音的中文说明视频。它是实际证据的可视化回放，不是实时桌面录屏；`narration.txt` 和 `narration.srt` 可供组员配音或加字幕。
- **slides/**：4 张 1920×1080 PNG，可直接插入小组 PPT。
- **results.csv / results.json**：实际运行结果与逐入口对判定。
- **evidence/main/**：五组完整实验的命令、原始日志、时间戳、源码、Boogie 模型、逐对检查日志。
- **evidence/witnesses/**：演示目标的实际 Corral 轨迹和来源定位。

以前的 `whoop-handoff` 是实验设计包；本包是执行后的交付。原始 `run.json` 的 `requires_manual_review` 是记录器的固定提示；核对后的结论在 `results.json`，原始记录没有为了展示而改写。

## 实际结果

所有主实验均使用 `--find-bugs --yield-race-check --k=2 --recursion-bound=1`，没有启用跳过无告警入口对的选项。Corral 使用 cooperative 调度。这里统计的是入口函数对，不是唯一源码缺陷数。

| 版本 | 分析入口对 | Whoop 告警入口对 | Whoop 错误条数 | Corral 反例入口对 | 演示目标的 Corral 结果 |
|---|---:|---:|---:|---:|---|
| A0 NVRAM 原版 | 14 | 7 | 7 | 4 | 找到反例 |
| A1 NVRAM 共同加锁 | 14 | 6 | 6 | 3 | 边界内未找到 |
| B0 GPIO 原版 | 27 | 13 | 20 | 4 | 找到反例 |
| B1 GPIO 只锁写端 | 27 | 13 | 20 | 4 | 仍有反例 |
| B2 GPIO 读写共锁 | 27 | 13 | 20 | 0 | 边界内未找到 |

**NVRAM 的目标是 `nvram_llseek × nvram_llseek`。** 两个调用共享同一 `struct file`。实际反例中，线程 2 在驱动第 55 行读取 `file->f_pos`，线程 3 在第 53 行改写这个位置；线程 2 恢复后，模型第 560 行的值稳定性断言失败。第 42 行也出现在实际轨迹中。A1 用现有 `nvram_mutex` 包住 llseek 的读、更新和返回值准备，所有退出路径释放锁；该目标对通过 Whoop 检查，Corral 未找到反例。其他 3 个含 `nvram_init` 的模型反例没有被当作已修复，也未进一步认定为真实内核缺陷。

**GPIO 的演示目标是 `pc8736x_gpio_change × pc8736x_gpio_current`。** `gpio_change` 内部先调用 current，再通过 set 写共享影子寄存器。实际反例中，线程 2 在第 204 行读 `pc8736x_gpio_shadow[port]`，线程 3 经 change → set 在第 195 行写入；线程 2 恢复后，模型第 727 行断言失败。B1 只保护写端，未持锁的读者仍可冲突；B2 让读写两端使用同一把锁，Corral 未再找到反例。B2 的静态告警仍然存在，未把其原因归结为已经证实的单一问题，也没有把“无有界反例”写成“所有告警均为误报”。

最初方案中的 GPIO `set × current` 在 B0 的 k=2、k=3 检查中都未找到反例，故改用确实产生反例的 change × current。诊断运行保存在 `evidence/diagnostics/`。B1 的 set × current 存在反例，不能据此反推 B0 同一入口对也已复现。原来用于手算的 `minor=0`、`f_pos=0` 和丢失更新时序是教学示例，本次视频没有将它们冒充求解器导出的具体数值。

A1 除增加共同锁外，还将返回值暂存为 `result = offset`，避免解锁后再读共享字段。因此 A1 是完整的临界区改写对照，不是只增加锁语句的单变量实验；原来的 `f_pos` 相对定位读取和写入仍由同一把锁保护。不能把返回处反例消失完全归因于单独增加锁这一项改动。

## 为什么这两个驱动适合小组作业

输入来自 Whoop 自带的 `driversuite/char/generic_nvram/driver.c` 与 `driversuite/char/pc8736x_gpio/driver.c`，分别只有 176、354 行，分析入口和共享对象明确；不需要真实 NVRAM 或 GPIO 硬件。NVRAM 对应论文的主要示例，GPIO 能展示“只有写者持锁仍不够”。五个版本把原版、单边锁和共同锁放在同一工具链下比较，适合解释共同锁集与反例检查。

论文以 Linux 4.0 为基准；本次实际输入身份由作者仓库提交和 SHA256 固定，不能把这些精简模型直接等同于完整 Linux 4.0 源树或当前内核驱动。

## 工具版本和两行修正

| 组件 | 实际使用版本 |
|---|---|
| Whoop | 0.7，`0f21d88b2f5f51686c65cef3ffc6a646f2a926ab`，加下述补丁 |
| Chauffeur | `ca8c44b9c50436f4b6a4f73fe0aa1de63474351e` |
| LLVM / Clang | Ubuntu 3.5.2 |
| SMACK | v1.5.0，`88ed58e42d2188c4f9f1da2617b2e125597a3f12` |
| Corral | `3aa62d7425b57295f698c6f47d3ce1910f5f5f8d`，.NET 4.5 目标框架 |
| Z3 | 4.3.2，`cee7dd39444c9060186df79c2a2c7f8845de415b` |
| Boogie | Whoop 仓库自带的 `BoogieBinaries` DLL，逐文件哈希见 runtime-manifest.json |
| 运行环境 | Ubuntu 16.04.6 amd64 用户态目录、Python 2.7.12、Mono 4.2.1.102；在现有 WSL2 Ubuntu 24.04.2 中通过便携 PRoot 执行 |

原版 Whoop 对作者的“共同加锁，应通过”样例给出 3 条错误。核对发现：重新解析入口模型后，`AnalysisContext.Locks` 缓存为空，而带 `{:lock}` 属性的锁声明仍在模型中；入口对检查却用空缓存判断锁是否存在。`patches/whoop-lock-context.patch` 将两处 `.Locks.Any(...)` 改为 `.GetLockVariables().Any(...)`，使共同锁进入检查条件。没有修改锁集更新、求解器或判定阈值。

修正后，作者的共同锁样例 5/5 对通过；无锁样例仍报错；单边锁样例仍报错且 Corral 找到反例。原始失败、修正后的成功及负对照均保存在 `evidence/calibration/`。这是一项公开记录的本地工具修正，不能称为未经修改的原版工具复现。

构建时还调整了工具路径、LLVM 头文件别名和 Corral 的框架目标。单独编译另一个 Boogie 快照的路线失败并停止，最终使用作者随仓库提供的 DLL；没有声称使用那份未编译成功的源码。构建日志全部保留，运行验收以实际样例和驱动输出为准。

## 如何重新运行

本机在本目录运行以下 PowerShell 命令；无需管理员权限：

```powershell
powershell -File .\tools\Run-Local.ps1 -Case A0_nvram_original -Mode corral
powershell -File .\tools\Run-Local.ps1 -Case A1_nvram_llseek_lock -Mode corral
powershell -File .\tools\Run-Local.ps1 -Case B0_gpio_original -Mode corral
powershell -File .\tools\Run-Local.ps1 -Case B1_gpio_writer_only -Mode corral
powershell -File .\tools\Run-Local.ps1 -Case B2_gpio_shadow_lock -Mode corral
```

新电脑需有已安装的 WSL2 Ubuntu 24.04 x86_64 或对应 Linux 用户环境。另行取得配套 `whoop-runtime-linux-x86_64.tar.gz`；在 Ubuntu 终端进入交付目录，恢复到一个**新的 Linux 文件系统目录**，不要在 Windows 解压软件中展开运行环境：

```bash
bash tools/restore-runtime.sh /path/to/whoop-runtime-linux-x86_64.tar.gz "$HOME/whoop-course-runtime"
bash tools/run.sh "$HOME/whoop-course-runtime" A0_nvram_original corral --tag demo-a0
```

恢复脚本先核对 `runtime-archive.json` 中的 SHA256，拒绝覆盖已有目录。只把运行时解压到指定目录，不安装宿主依赖，不更改 WSL 发行版或全局配置。PRoot 是便携用户态运行方式，本文不把它宣称为安全隔离边界。

新的日志保存到 `reproduced-runs/<case>_<mode>_<tag>/`，同一个 tag 不可重复，避免覆盖。纯静态模式检出竞争时 Whoop 返回 6；直接调用 RaceChecker 检出错误时返回 4，这些不是构建失败。`Verified: driver.c` 是原脚本的流程完成输出，不是最终结论；必须检查各入口对的 Corral 输出和轨迹。

`sources/` 内保存使用的五个源代码 Git 归档和运行时版权说明；完整工具、模型与 DLL 哈希在 manifest 中。`tools/provenance/` 保留本次生成与诊断脚本的历史路径，仅供审查；复跑使用上面的 `run.sh` 或 `Run-Local.ps1`。

## 给其他组员的衔接

| 后续工作 | 可以直接使用 | 需要说明 |
|---|---|---|
| 论文与形式化原理 | 两条真实轨迹、Whoop/Corral 流程图 | 共享位置、至少一方写入、缺少共同锁；静态近似与有界检查的差别 |
| 实验报告 | results.csv、4 张高清图、源代码与补丁 | 告警对数与错误条数不同；B2 仍有静态告警；本次 GPIO 原版 4 个反例对与论文 5 个不一致 |
| 课堂汇报与视频 | index.html、3:40 视频、字幕/配音稿 | 先播放原版，再切单边锁与共同锁；明确是模型反例和证据回放 |
| 他人复核 | 固定源码、运行环境、脚本、完整日志 | 同一模型与边界下复跑；不要用本实验推断真实硬件行为或现代内核状态 |

本次没有做性能复现；部分实验并发运行且处于 PRoot 用户态环境，日志中的耗时仅用于追踪，不能与论文性能表直接比较。B2 只锁住单次 shadow 访问，没有把整个 `gpio_change` 的“读—改—写”合并为一个临界区，因此不能宣称 toggle 操作整体原子。Chauffeur 的参数生成、初始化时序及外部函数抽象都是结果边界；例如 NVRAM 自动生成的 loff_t 实参包含指针转换，本次保留作者生成逻辑，没有将它包装为真实系统调用实参。

参考：[ASE 2015 论文](https://www.doc.ic.ac.uk/~afd/papers/2015/ASE.pdf)、[Whoop 作者仓库](https://github.com/smackers/whoop)。
