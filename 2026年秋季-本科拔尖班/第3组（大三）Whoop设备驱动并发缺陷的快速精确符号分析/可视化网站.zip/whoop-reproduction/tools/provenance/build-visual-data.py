import json
import re
from pathlib import Path

root = Path(__file__).resolve().parents[2]
out = root / 'outputs/whoop-reproduction'
results = json.loads((out / 'results.json').read_text())['cases']
labels = {'A0_nvram_original': 'A0 · NVRAM 原版', 'A1_nvram_llseek_lock': 'A1 · NVRAM 共同加锁',
          'B0_gpio_original': 'B0 · GPIO 原版', 'B1_gpio_writer_only': 'B1 · GPIO 只锁写端', 'B2_gpio_shadow_lock': 'B2 · GPIO 读写共锁'}
data = {'families': {'nvram': list(labels)[:2], 'gpio': list(labels)[2:]}, 'cases': {}, 'results': results}

def trace_steps(case, model):
    directory = out / 'evidence/main' / case
    log = (directory / 'stdout-stderr.log').read_text()
    block = next(b for b in log.split('Running corral\n')[1:] if model in b.splitlines()[0])
    lines = (directory / 'input' / model).read_text().splitlines()
    src = None
    mapping = {}
    for n, line in enumerate(lines, 1):
        match = re.search(r'sourceloc "driver.re.c", (\d+),', line)
        if match:
            src = int(match[1])
        mapping[n] = src
    rewritten = (directory / 'input/driver.re.c').read_text().splitlines()
    original = (directory / 'input/driver.c').read_text().splitlines()
    steps = []
    for line in block.splitlines():
        match = re.match(r'\((\d+),(\d+)\).*\.bpl\((\d+),(\d+)\):', line)
        if not match:
            continue
        num = int(match[3]); code = lines[num-1].strip(); src = mapping[num]
        if not src or src > len(original) or not re.search(r'\$M\.\d+\[', code):
            continue
        if 'f_pos' not in original[src-1] and 'pc8736x_gpio_shadow[' not in original[src-1]:
            continue
        fail = 'ASSERTION FAILS' in line
        if code.startswith('assert') and not fail:
            continue
        assert original[src-1].strip() == rewritten[src-1].strip(), (case, src)
        write = re.match(r'\$M\.\d+\[.*\] :=', code) is not None
        resource = 'f_pos' if case.startswith('A') else 'shadow[port]'
        label = '值稳定性检查失败' if fail else ('写入 ' if write else '读取 ') + resource
        explanation = ('另一线程在 yield 期间改写了同一位置，插入的稳定性断言失败。' if fail else
                       ('把新值写入共享位置。' if write else '从共享位置读取一个值，模型随后允许线程交错。'))
        steps.append({'thread': int(match[1]), 'model_line': num, 'source_line': src, 'statement': code,
                      'assertion_fails': fail, 'label': label, 'explanation': explanation})
    assert steps and steps[-1]['assertion_fails']
    return steps, 'Running corral\n' + block

for result in results:
    case = result['case']; is_a = case.startswith('A'); has_trace = result['target_corral_verdict'] == 'counterexample'
    path = 'evidence/main/' + case
    lines = (out / path / 'input/driver.c').read_text().splitlines()
    model = result['presentation_target']
    steps, raw = trace_steps(case, model) if has_trace else ([], '')
    trace_name = 'evidence/witnesses/' + case + '-target-trace.txt' if has_trace else None
    if has_trace:
        (out / trace_name).write_text(raw, encoding='utf-8')
    if is_a:
        start = next(i for i,l in enumerate(lines) if l.startswith('static loff_t nvram_llseek'))
        end = next(i for i in range(start+1,len(lines)) if lines[i].startswith('}'))
        excerpt = list(range(start,end+1))
    else:
        index = next(i for i,l in enumerate(lines) if 'pc8736x_gpio_shadow[port] = val' in l)
        start = max(index-2,0)
        end = next(i for i in range(index,len(lines)) if 'static struct nsc_gpio_ops' in lines[i])
        excerpt = list(range(start,end))
    c = {'label': labels[case], 'title': 'nvram_llseek × nvram_llseek' if is_a else 'gpio_change × gpio_current',
         'description': '同一 struct file 的两个定位调用' if is_a else 'gpio_change 内部调用 gpio_set；与 gpio_current 共享影子寄存器',
         'resource': 'file->f_pos' if is_a else 'pc8736x_gpio_shadow[port]',
         'actors': ['nvram_llseek', 'nvram_llseek'] if is_a else ['gpio_current', 'gpio_change → gpio_set'],
         'source': [{'line': i+1,'text': lines[i]} for i in excerpt], 'steps': steps,
         'sourcePath': path + '/input/driver.c', 'modelPath': path + '/input/' + model,
         'logPath': path + '/stdout-stderr.log', 'tracePath': trace_name,
         'cleanNote': '两个 llseek 调用共同持有 nvram_mutex，并将返回值暂存为局部变量；这是临界区改写对照，不是只加锁的单变量实验。该目标对通过 Whoop 检查，Corral 未找到反例；其他入口对仍有 3 个模型反例。' if is_a else
                      '读写两端使用同一把 gpio_shadow_lock。本次 27 个入口对的 Corral 检查均未找到反例；Whoop 的 13 个告警入口对仍保留。'}
    data['cases'][case] = c
(out / 'visual-data.json').write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
encoded = json.dumps(data, ensure_ascii=False).replace('</', '<\\/')
template = (root / 'work/reproduce/visual-template.html').read_text(encoding='utf-8')
assert template.count('__WHOOP_DATA__') == 1
(out / 'index.html').write_text(template.replace('__WHOOP_DATA__', encoded), encoding='utf-8', newline='\n')
print('VISUAL_BUILT', {k: len(v['steps']) for k,v in data['cases'].items()})
