import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

root = Path(__file__).resolve().parents[2]
out = root / 'outputs/whoop-reproduction'
frames = root / 'work/reproduce/video-frames'
frames.mkdir(exist_ok=True)
(out / 'slides').mkdir(exist_ok=True)
data = json.loads((out / 'visual-data.json').read_text(encoding='utf-8'))
W,H = 1920,1080
BG='#f5f4f0'; INK='#172b33'; MUTED='#586a70'; LINE='#cdd6d4'; TEAL='#006e64'; WASH='#e3eeea'; RED='#a7352d'; REDWASH='#fae9e3'; WHITE='#ffffff'
font_path='C:/Windows/Fonts/msyh.ttc'; bold_path='C:/Windows/Fonts/msyhbd.ttc'; mono_path='C:/Windows/Fonts/consola.ttf'
fonts={}
def font(size,bold=False,mono=False):
    key=(size,bold,mono)
    if key not in fonts:
        fonts[key]=ImageFont.truetype(mono_path if mono else bold_path if bold else font_path,size)
    return fonts[key]

def text(d,xy,s,size=28,fill=INK,bold=False,mono=False):
    d.text(xy,s,font=font(size,bold,mono),fill=fill)

def wrap(d,s,x,y,width,size=28,fill=INK,bold=False,line_height=None):
    f=font(size,bold); line_height=line_height or int(size*1.6)
    lines=[]
    for para in s.split('\n'):
        current=''
        for c in para:
            if current and d.textlength(current+c,font=f)>width:
                lines.append(current); current=c
            else: current+=c
        lines.append(current)
    for line in lines:
        d.text((x,y),line,font=f,fill=fill); y+=line_height
    return y

def code(d,s,x,y,width,size=24,fill=INK):
    """Wrap code at whitespace so displayed identifiers remain intact."""
    f=font(size,mono=True); current=''; lines=[]
    for token in s.split():
        candidate=(current+' '+token).strip()
        if current and d.textlength(candidate,font=f)>width:
            lines.append(current); current=token
        else: current=candidate
    if current: lines.append(current)
    for line in lines:
        assert d.textlength(line,font=f)<=width, 'Code token exceeds panel width'
        d.text((x,y),line,font=f,fill=fill); y+=int(size*1.6)
    return y

def base(chapter,title,subtitle):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    d.rectangle((0,0,W,10),fill=TEAL)
    text(d,(90,44),'WHOOP',40,bold=True,mono=True)
    text(d,(310,54),'论文复现',22,fill=MUTED)
    text(d,(1360,54),'ASE 2015 · STATIC ANALYSIS',20,fill=MUTED,mono=True)
    text(d,(90,126),chapter,20,fill=TEAL,mono=True)
    text(d,(90,166),title,48,bold=True)
    wrap(d,subtitle,90,242,1740,25,fill=MUTED)
    d.line((90,320,1830,320),fill=LINE,width=2)
    d.line((90,965,1830,965),fill=LINE,width=2)
    text(d,(90,987),'真实运行证据的可视化回放 · 非实时桌面录屏',21,fill=MUTED)
    text(d,(1340,987),'k = 2  /  recursion = 1',21,fill=MUTED,mono=True)
    return im,d

sequence=[]
def add(im,name,duration,caption,export=None):
    path=frames/(name+'.png'); im.save(path)
    sequence.append({'image':path,'duration':duration,'caption':caption,'name':name})
    if export: im.save(out/'slides'/export)

im,d=base('01 / SCOPE','两个驱动，五组对照','复现 Whoop 的潜在竞争分析，并用 Corral 搜索有界模型反例。')
text(d,(100,380),'generic_nvram',44,mono=True,bold=True)
text(d,(100,450),'共享文件位置 file->f_pos',29)
text(d,(1050,380),'pc8736x_gpio',44,mono=True,bold=True)
text(d,(1050,450),'共享影子寄存器 shadow[port]',29)
for x in (100,1050): d.line((x,530,x+650,530),fill=TEAL,width=5)
wrap(d,'原版 → 两个 llseek 共同加锁',100,572,750,29)
wrap(d,'原版 → 只锁写端 → 读写共锁',1050,572,750,29)
wrap(d,'所有实验只分析作者提供的程序模型。\n没有加载驱动、访问真实硬件或执行安全敏感测试。',100,744,1650,32)
add(im,'01-scope',12,'本次完成两个驱动、五组对照的论文方法复现。全部分析在作者的静态模型上进行，没有加载驱动或执行安全敏感测试。','01-overview.png')

im,d=base('02 / TOOLCHAIN','从驱动源码，到反例证据','所有输入、工具版本、命令和原始输出均保留在交付包中。')
items=[('Driver C','固定源码与 SHA256'),('Chauffeur / SMACK','生成 Boogie 模型'),('Whoop','符号锁集分析'),('Corral','有界反例检查')]
for i,(title,sub) in enumerate(items):
    x=95+i*445
    text(d,(x,410),str(i+1).zfill(2),56,fill=TEAL,mono=True)
    text(d,(x,500),title,30,bold=True)
    wrap(d,sub,x,560,400,24,fill=MUTED)
    if i<3: text(d,(x+365,430),'→',38,fill=TEAL)
wrap(d,'Whoop 0.7 / 0f21d88  ·  LLVM 3.5.2  ·  SMACK 1.5.0\nZ3 4.3.2  ·  Corral 3aa62d7  ·  Mono 4.2.1',100,735,1700,28)
add(im,'02-toolchain',18,'源码先转换为 Boogie 模型。Whoop 给出潜在竞争告警，Corral 再搜索具体模型反例。我们的运行环境和代码提交已经固定，未宣称逐字节复现论文原始环境。')

im,d=base('03 / CALIBRATION','先校验工具，再解释驱动结果','旧版 Whoop 读取了空的锁信息缓存；两行修正让它读取模型中现有的锁声明。')
rows=[('共同持锁','5 / 5 入口对通过','符合作者样例预期'),('无锁写入','1 / 2 入口对通过','保留竞争告警'),('只有一方持锁','3 / 5 入口对通过','Corral 找到反例')]
for i,(a,b,c) in enumerate(rows):
    y=390+i*126; text(d,(100,y),a,31,bold=True);text(d,(700,y),b,31);text(d,(1290,y),c,28,fill=TEAL);d.line((100,y+85,1810,y+85),fill=LINE,width=1)
wrap(d,'原始失败日志、修正补丁和校验结果均已保留。\n两份原版驱动没有修改；加锁版本是单独的实验对照。',100,810,1700,27,fill=MUTED)
add(im,'03-calibration',17,'在正式实验前，我们发现旧版工具的锁信息读取异常。修正仅涉及两行查找逻辑，并用作者原有的共同加锁、无锁和单边加锁样例进行校验。补丁和原始失败日志都在交付包中。')

def replay(case,chapter,seconds):
    c=data['cases'][case]; steps=c['steps']
    for n,s in enumerate(steps,1):
        im,d=base(chapter,c['label']+'：'+c['title'],'逐步呈现实际 Corral 轨迹；具体数值未导出，保留符号表达式。')
        x0=100; x2=210; x3=690; top=395; row_h=68 if len(steps)>4 else 90
        text(d,(x2,350),'THREAD 2',20,fill=MUTED,mono=True); text(d,(x3,350),'THREAD 3',20,fill=MUTED,mono=True)
        for i,item in enumerate(steps):
            y=top+i*row_h; color=INK if i<n else '#9ca9a7'
            if i==n-1: d.rectangle((100,y-4,1130,y+row_h-5),fill=REDWASH if item['assertion_fails'] else WASH)
            text(d,(112,y+11),str(i+1).zfill(2),21,fill=MUTED,mono=True)
            x=x2 if item['thread']==2 else x3
            text(d,(x,y+5),item['label'],26,fill=RED if item['assertion_fails'] and i<n else color,bold=i==n-1)
            text(d,(x,y+42),'driver.c : '+str(item['source_line'])+'  /  model : '+str(item['model_line']),15,fill=MUTED,mono=True)
            d.line((100,y+row_h-2,1130,y+row_h-2),fill=LINE,width=1)
        d.line((1200,350,1200,865),fill=LINE,width=2)
        text(d,(1250,350),'共享位置',23,fill=MUTED)
        wrap(d,c['resource'],1250,400,570,28,fill=TEAL,bold=True)
        text(d,(1250,495),'当前源码 · 第 '+str(s['source_line'])+' 行',24,fill=MUTED)
        source=next(l['text'].strip() for l in c['source'] if l['line']==s['source_line'])
        code(d,source,1250,548,555)
        text(d,(1250,682),'Boogie 模型',23,fill=MUTED)
        code(d,s['statement'],1250,732,555,fill=RED if s['assertion_fails'] else TEAL)
        wrap(d,'步骤 '+str(n)+' / '+str(len(steps))+'  ·  '+s['explanation'],100,877,1720,24,fill=RED if s['assertion_fails'] else INK)
        name=case+'-'+str(n).zfill(2)
        caption=c['label']+'，第 '+str(n)+' 步：线程 '+str(s['thread'])+'，'+s['label']+'。'+s['explanation']
        export=None
        if n==len(steps) and case=='A0_nvram_original':export='02-nvram-trace.png'
        if n==len(steps) and case=='B0_gpio_original':export='03-gpio-trace.png'
        add(im,name,seconds,caption,export)

replay('A0_nvram_original','04 / NVRAM TRACE',7)
im,d=base('05 / NVRAM CONTROL','给两个 llseek 使用同一把锁','目标：nvram_llseek × nvram_llseek')
text(d,(100,390),'A0 原版',34,bold=True);text(d,(1040,390),'A1 共同加锁',34,bold=True)
text(d,(100,485),'Whoop：有告警',31,fill=RED);text(d,(1040,485),'Whoop：目标对通过',31,fill=TEAL)
text(d,(100,565),'Corral：找到反例',31,fill=RED);text(d,(1040,565),'Corral：边界内未找到反例',31,fill=TEAL)
wrap(d,'本次真实反例出现在返回前对 f_pos 的读取（第 55 行），\n另一个线程已经改写同一位置（第 53 行）。',100,740,1700,31)
wrap(d,'其他 3 个包含初始化入口的模型反例仍保留；不能据此宣称整个驱动已修复。',100,862,1700,25,fill=MUTED)
add(im,'05-nvram-control',15,'NVRAM 的真实反例发生在返回前的读取与另一线程的写入之间。给两个 llseek 共同加锁后，目标对通过 Whoop 检查，Corral 也未找到反例。但其他包含初始化入口的模型反例仍然保留。')

replay('B0_gpio_original','06 / GPIO TRACE',7)
replay('B1_gpio_writer_only','07 / ONE-SIDED LOCK',5)
im,d=base('08 / GPIO CONTROL','共同加锁后，再检查同一个目标','目标：gpio_change × gpio_current；change 内部通过 gpio_set 写共享数组。')
columns=[('B0 原版','找到反例',RED),('B1 只锁写端','仍有反例',RED),('B2 读写共锁','边界内未找到',TEAL)]
for i,(a,b,color) in enumerate(columns):
    x=100+i*590;text(d,(x,410),a,31,bold=True);d.line((x,480,x+490,480),fill=color,width=5);text(d,(x,535),b,32,fill=color,bold=True)
wrap(d,'B2 的 Corral 检查覆盖 27 个入口对，本次未找到反例。\nWhoop 的 13 个告警入口对仍然保留，不能把两种结果混为一谈。',100,740,1700,31)
add(im,'08-gpio-control',15,'GPIO 的单边锁不能阻止未持锁的读者。读写两端使用同一把锁后，Corral 在本次模型和边界内没有找到反例。Whoop 的静态告警仍有残留，报告中保留了这一差异。')

im,d=base('09 / RESULTS','五组实验的实际结果','按入口函数对计数；没有把论文表格中的数字当作本次运行结果。')
xs=[100,730,1060,1435]; headings=['实验版本','分析入口对','Whoop 告警对','Corral 反例对']
for x,h in zip(xs,headings):text(d,(x,355),h,25,fill=MUTED)
for i,r in enumerate(data['results']):
    y=426+i*83
    values=[data['cases'][r['case']]['label'],str(r['static']['total_pairs']),str(r['static']['potentially_racy_pairs']),str(r['corral_counterexample_pairs'])]
    for j,(x,v) in enumerate(zip(xs,values)):text(d,(x,y),v,28 if j==0 else 32,bold=j==0,mono=j>0,fill=TEAL if j==3 else INK)
    d.line((100,y+62,1800,y+62),fill=LINE,width=1)
wrap(d,'GPIO 13 个告警入口对对应 20 条错误报告。\n“未找到反例”只在本次模型与边界内成立，不是整个驱动的正确性证明。',100,868,1700,23,fill=MUTED)
add(im,'09-results',20,'表格展示全部实测计数。NVRAM 原版有四个反例入口对，加锁后剩三个。GPIO 原版和单边锁各有四个，共同加锁后为零。Whoop 告警入口对数量与错误报告条数并不相同。','04-results.png')

im,d=base('10 / LIMITS','能得出的结论，和不能省略的边界','复现的是论文方法及两个基准案例，不是实机故障或完整内核验证。')
facts=[('源码与模型','输入来自固定 Whoop driversuite 快照；硬件调用、参数与初始化均经过作者模型抽象。'),('工具适配','使用公开提交及两行锁信息修正；不是原论文环境的逐字节重建。'),('目标调整','GPIO 演示采用实际有反例的 change × current，原版 set × current 未得到同样结果。'),('有界结论','k = 2、递归边界 1。共同锁只保护所选共享访问，不保证复合 toggle 操作整体原子。')]
for i,(a,b) in enumerate(facts):
    y=375+i*133;text(d,(100,y),a,30,bold=True);wrap(d,b,445,y,1320,27,fill=MUTED);d.line((100,y+104,1800,y+104),fill=LINE,width=1)
add(im,'10-limits',18,'需要保留四个边界：我们分析作者的模型；工具做了透明的适配；GPIO 演示目标根据实际反例调整；未找到反例受边界限制，共同锁也不等于完整复合操作已经原子化。')

im,d=base('11 / HANDOFF','组员可以从这些证据继续','先打开 index.html；每个演示都能追溯到源码、模型与完整日志。')
tasks=[('原理与逻辑','解释共享位置、共同锁集、静态告警与有界反例的关系。'),('报告与图表','使用 results.csv、高清图片、真实源码行号和反例轨迹。'),('汇报与复跑','使用交互页面或本视频；配套环境和脚本支持本地重新运行。')]
for i,(a,b) in enumerate(tasks):
    y=400+i*150;text(d,(100,y),str(i+1).zfill(2),50,fill=TEAL,mono=True);text(d,(240,y),a,32,bold=True);wrap(d,b,730,y,1050,28,fill=MUTED)
wrap(d,'两个驱动的论文复现、加锁对照、运行证据与可视化交付',100,872,1700,25)
add(im,'11-handoff',15,'交付包已经包含交互页面、视频、高清图片、版本清单、源码、原始日志和复跑脚本。组员可以据此完成理论说明、实验报告与课堂汇报，并检查每项结论对应的证据。')

concat=frames/'concat.txt'
lines=[];time=0;subtitles=[];chapters=[]
def stamp(t):
    ms=int(round(t*1000));return '%02d:%02d:%02d,%03d'%(ms//3600000,(ms//60000)%60,(ms//1000)%60,ms%1000)
for i,item in enumerate(sequence,1):
    lines+=['file '+"'"+item['image'].as_posix()+"'",'duration '+str(item['duration'])]
    subtitles.append(str(i)+'\n'+stamp(time)+' --> '+stamp(time+item['duration'])+'\n'+item['caption']+'\n')
    chapters.append({'start_seconds':time,'end_seconds':time+item['duration'],'frame':item['name'],'caption':item['caption']})
    time+=item['duration']
lines.append('file '+"'"+sequence[-1]['image'].as_posix()+"'")
concat.write_text('\n'.join(lines)+'\n',encoding='utf-8')
(out/'video/narration.srt').write_text('\n'.join(subtitles),encoding='utf-8-sig')
(out/'video/chapters.json').write_text(json.dumps(chapters,ensure_ascii=False,indent=2),encoding='utf-8')
(out/'video/narration.txt').write_text('\n\n'.join('%02d:%02d  %s'%(int(c['start_seconds'])//60,int(c['start_seconds'])%60,c['caption']) for c in chapters),encoding='utf-8')
print(json.dumps({'frames':len(sequence),'seconds':time,'concat':str(concat)},ensure_ascii=False))
