from __future__ import print_function
import json
import os
import subprocess
import sys
import time

run = '/workspace/work/reproduce/runs/' + sys.argv[1]
with open(run + '/run.json') as stream:
    meta = json.load(stream)
assert meta['status'] == 'finished', 'Wait for the full run first'
cmd = ['timeout', '-k', '15s', '300s', 'mono', '/opt/whoop/src/whoop/Binaries/WhoopRaceChecker.exe',
       '/nologo', '/typeEncoding:m', '/mv:-', '/doNotUseLabels', '/enhancedErrorMessages:1',
       '/whoopDecl:/opt/whoop/src/whoop/Model/whoop_decl.bpl', '/z3exe:/opt/whoop/local/bin/z3.exe',
       '/originalFile:' + run + '/input/driver.c', '/trace', 'driver.bpl']
with open(run + '/pair-checker.log', 'wb') as stream:
    code = subprocess.call(cmd, cwd=run + '/input', stdout=stream, stderr=subprocess.STDOUT)
with open(run + '/pair-checker-command.json', 'w') as stream:
    json.dump({'argv': cmd, 'exit_code': code, 'note': 'RaceChecker only, diagnostic trace enabled; same models and summaries'}, stream, indent=2)
print('PAIR_CHECKER_EXIT', code, run)
sys.exit(0 if code in (0, 4) else code)
