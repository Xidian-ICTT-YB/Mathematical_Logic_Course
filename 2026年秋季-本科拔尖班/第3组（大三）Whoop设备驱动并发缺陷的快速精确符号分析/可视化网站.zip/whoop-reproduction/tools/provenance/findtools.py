"""Task-local Whoop 0.7 runtime configuration; no analysis algorithm changes."""
rootDir = "/opt/whoop"
whoopDir = rootDir + "/src/whoop"
llvmSrcDir = "/usr/lib/llvm-3.5"
llvmBinDir = "/usr/lib/llvm-3.5/bin"
# Upstream whoop.py hard-codes clang/3.4/include. This directory contains
# an explicit compatibility symlink to the installed Clang 3.5.2 headers.
llvmLibDir = rootDir + "/llvm-compat"
chauffeurDir = rootDir + "/build/chauffeur"
smackSrcDir = rootDir + "/local/include"
smackBinDir = rootDir + "/local/bin"
corralBinDir = rootDir + "/src/corral/bin/Debug"
whoopBinDir = rootDir + "/src/whoop/Binaries"
z3BinDir = rootDir + "/local/bin"
cvc4BinDir = rootDir + "/unused-cvc4"

def init(prefixPath):
    pass
