import json
import re
from pathlib import Path

root = Path(__file__).resolve().parent / 'runs'
for run in sorted(root.iterdir()):
    meta_path = run / 'run.json'
    if not meta_path.exists():
        continue
    meta = json.loads(meta_path.read_text())
    if meta['status'] != 'finished':
        continue
    log = (run / 'stdout-stderr.log').read_text(errors='replace')
    summary = re.search(r'Whoop static lockset analyser finished with (\d+) \(out of (\d+)\) entry point pairs verified, (\d+) errors?', log)
    pairs = []
    for block in log.split('Running corral\n')[1:]:
        match = re.search(r'(driver_check_racy_[^\s/]+\.bpl)', block)
        if not match:
            raise ValueError('Missing Corral input: ' + str(run))
        verdict = 'unknown'
        if 'Program has a potential bug: True bug' in block and 'ASSERTION FAILS' in block:
            verdict = 'counterexample'
        elif 'Program has no bugs' in block:
            verdict = 'no_counterexample_within_bounds'
        pair = {'model': match.group(1), 'verdict': verdict}
        pairs.append(pair)
    result = {'case': meta['case'], 'run': run.name, 'mode': meta['mode'], 'exit_code': meta['exit_code'],
              'wall_seconds': meta['wall_seconds'], 'bounds': meta['bounds'], 'pairs': pairs,
              'static': None if not summary else {'verified_pairs': int(summary[1]), 'total_pairs': int(summary[2]), 'reported_errors': int(summary[3])}}
    (run / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
    if meta['mode'] != 'preflight':
        print(json.dumps({k: v for k, v in result.items() if k != 'pairs'}))
        for pair in pairs:
            if pair['verdict'] == 'counterexample' or 'nvram_llseek_nvram_llseek' in pair['model'] or 'gpio_current_pc8736x_gpio_set' in pair['model'] or 'gpio_set_pc8736x_gpio_current' in pair['model']:
                print('  ', pair['model'], pair['verdict'])
