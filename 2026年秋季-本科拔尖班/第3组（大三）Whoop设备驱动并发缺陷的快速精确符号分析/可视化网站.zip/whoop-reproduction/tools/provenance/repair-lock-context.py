from __future__ import print_function
import hashlib
import io
import os
import shutil
import difflib

root = '/opt/whoop/src/whoop'
relative = 'Source/Whoop/Regions/PairCheckingRegion.cs'
path = root + '/' + relative
with io.open(path, encoding='utf-8') as stream:
    before = stream.read()
old = 'this.AC1.Locks.Any(v => v.Name.Equals(l.Name)) &&\n            !this.AC2.Locks.Any(v => v.Name.Equals(l.Name))'
new = 'this.AC1.GetLockVariables().Any(v => v.Name.Equals(l.Name)) &&\n            !this.AC2.GetLockVariables().Any(v => v.Name.Equals(l.Name))'
assert before.count(old) == 1, 'Unexpected source: do not patch a different version'
assert not os.path.exists('/opt/whoop/upstream-binaries'), 'Backup already exists; inspect before repeating'
shutil.copytree(root + '/Binaries', '/opt/whoop/upstream-binaries')
shutil.copyfile(path, path + '.upstream')
after = before.replace(old, new)
with io.open(path, 'w', encoding='utf-8') as stream:
    stream.write(after)
with io.open('/workspace/work/reproduce/whoop-lock-context.patch', 'w', encoding='utf-8') as stream:
    stream.write(u''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), 'a/' + relative, 'b/' + relative)))
print('Applied two-line lock declaration lookup repair; original source and binaries retained')
