from __future__ import print_function
import datetime
import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import time

case = sys.argv[1]
assert case in ['B0_gpio_original', 'B1_gpio_writer_only', 'B2_gpio_shadow_lock']
source = '/workspace/work/reproduce/runs/' + case + '_corral_final1/input'
dest = '/workspace/work/reproduce/runs/' + case + '_target_k3'
model = 'driver_check_racy_pc8736x_gpio_current_pc8736x_gpio_set.bpl'
os.makedirs(dest + '/input')
for name in [model, 'driver.c', 'driver.re.c']:
    shutil.copyfile(source + '/' + name, dest + '/input/' + name)
cmd = ['timeout', '-k', '15s', '300s', 'mono', '/opt/whoop/src/corral/bin/Debug/corral.exe',
       '/k:3', '/recursionBound:1', '/cooperative', model]
meta = {'case': case, 'mode': 'target_corral', 'status': 'running', 'argv': cmd,
        'bounds': {'k': 3, 'recursion_bound': 1}, 'source_model': source + '/' + model,
        'input_sha256': hashlib.sha256(open(source + '/' + model, 'rb').read()).hexdigest(),
        'started_utc': datetime.datetime.utcnow().isoformat() + 'Z',
        'execution_scope': 'author_models_static_analysis_only_no_driver_loading'}
with open(dest + '/run.json', 'w') as stream:
    json.dump(meta, stream, indent=2)
started = time.time()
with open(dest + '/stdout-stderr.log', 'wb') as log, io.open(dest + '/events.jsonl', 'w', encoding='utf-8') as events:
    process = subprocess.Popen(cmd, cwd=dest + '/input', stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    for line in iter(process.stdout.readline, b''):
        log.write(line)
        log.flush()
        events.write(json.dumps({'seconds': round(time.time() - started, 4), 'text': line.decode('utf-8', 'replace')}) + u'\n')
        events.flush()
    code = process.wait()
meta.update(status='finished', exit_code=code, wall_seconds=round(time.time() - started, 4), ended_utc=datetime.datetime.utcnow().isoformat() + 'Z')
with open(dest + '/run.json', 'w') as stream:
    json.dump(meta, stream, indent=2)
print(dest, 'exit', code)
sys.exit(code)
