import csv
import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path

workspace = Path(__file__).resolve().parents[2]
scratch = workspace / 'work/reproduce'
old = workspace / 'outputs/whoop-handoff'
out = workspace / 'outputs/whoop-reproduction'
out.mkdir(exist_ok=True)

def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()

for name in ['cases', 'patches']:
    shutil.copytree(old / name, out / name, dirs_exist_ok=True)
shutil.copyfile(old / 'LICENSE-drivers.txt', out / 'LICENSE-drivers.txt')
shutil.copyfile(scratch / 'whoop-lock-context.patch', out / 'patches/whoop-lock-context.patch')
shutil.copyfile(scratch / 'runtime-manifest.json', out / 'runtime-manifest.json')
for folder in ['sources', 'tools', 'evidence/main', 'evidence/calibration', 'evidence/diagnostics', 'evidence/witnesses', 'build-logs', 'video']:
    (out / folder).mkdir(parents=True, exist_ok=True)

repos = {'whoop': 'https://github.com/smackers/whoop', 'chauffeur': 'https://github.com/mc-imperial/chauffeur',
         'smack': 'https://github.com/smackers/smack', 'corral': 'https://github.com/boogie-org/corral', 'z3': 'https://github.com/Z3Prover/z3'}
components = {}
for component, url in repos.items():
    commit = subprocess.check_output(['git', '-C', str(workspace / 'work' / component), 'rev-parse', 'HEAD'], text=True).strip()
    archive = scratch / 'sources' / (component + '.tar')
    shutil.copyfile(archive, out / 'sources' / archive.name)
    components[component] = {'repository': url, 'commit': commit, 'archive': 'sources/' + archive.name, 'sha256': sha(archive)}
    if component == 'whoop':
        components[component]['patch'] = 'patches/whoop-lock-context.patch'
        components[component]['patch_sha256'] = sha(out / 'patches/whoop-lock-context.patch')

lock = json.loads((old / 'source-lock.json').read_text())
lock.pop('candidate_toolchain', None)
lock['status'] = 'executed_with_documented_tool_patch'
lock['components'] = components
lock['runtime'] = {'guest': 'Ubuntu 16.04.6 amd64', 'host_tested': 'WSL2 Ubuntu 24.04.2 x86_64',
                   'python': '2.7.12', 'llvm_clang': '3.5.2', 'mono': '4.2.1.102', 'z3': '4.3.2',
                   'boogie': 'Whoop/BoogieBinaries bundled DLLs, hashes in runtime-manifest.json',
                   'corral_framework': 'built with /p:TargetFrameworkVersion=v4.5',
                   'base_image_url': 'https://cdimage.ubuntu.com/ubuntu-base/releases/16.04/release/ubuntu-base-16.04.6-base-amd64.tar.gz',
                   'base_image_sha256': '9c160b522568c0c3f2c396cfe7c966f1a63aa1a5e9f6f966a74fdf3571ad49a0'}

results = {'status': 'completed_with_limits', 'bounds': {'k': 2, 'recursion_bound': 1},
           'tool_patch': 'patches/whoop-lock-context.patch', 'scope': 'static author models only; no kernel module loading', 'cases': []}
for case in lock['cases']:
    case['execution_status'] = 'executed'
    source = scratch / 'runs' / (case['id'] + '_corral_final1')
    dest = out / 'evidence/main' / case['id']
    shutil.copytree(source, dest, dirs_exist_ok=True)
    summary = json.loads((source / 'summary.json').read_text())
    assert sha(dest / 'input/driver.c') == case['sha256']
    text = (source / 'pair-checker.log').read_text()
    checks = re.findall(r'Verifying \$([^\s]+) \.\.\.(.*?)(?=Parsing|Whoop static|\Z)', text, flags=re.S)
    static_pairs = []
    for name, body in checks:
        verdict = 'unknown'
        if re.search(r'\]\s+verified', body):
            verdict = 'verified'
        elif re.search(r'\]\s+errors?', body):
            verdict = 'potential_race'
        static_pairs.append({'pair': name.split('$'), 'verdict': verdict})
    assert len(static_pairs) == summary['static']['total_pairs']
    summary['static_pairs'] = static_pairs
    summary['static']['potentially_racy_pairs'] = sum(p['verdict'] == 'potential_race' for p in static_pairs)
    summary['corral_counterexample_pairs'] = sum(p['verdict'] == 'counterexample' for p in summary['pairs'])
    summary['evidence_directory'] = 'evidence/main/' + case['id']
    target = 'nvram_llseek_nvram_llseek' if case['id'].startswith('A') else 'pc8736x_gpio_change_pc8736x_gpio_current'
    summary['presentation_target'] = 'driver_check_racy_' + target + '.bpl'
    summary['target_corral_verdict'] = next(p['verdict'] for p in summary['pairs'] if p['model'] == summary['presentation_target'])
    results['cases'].append(summary)

for source in sorted((scratch / 'runs').iterdir()):
    if source.name.startswith('G'):
        shutil.copytree(source, out / 'evidence/calibration' / source.name, dirs_exist_ok=True)
    elif source.name.endswith('_target_k3') or '_no_infer' in source.name:
        shutil.copytree(source, out / 'evidence/diagnostics' / source.name, dirs_exist_ok=True)

for case_id, model, label, memory in [
    ('A0_nvram_original', 'driver_check_racy_nvram_llseek_nvram_llseek.bpl', 'nvram', '$M.0['),
    ('B0_gpio_original', 'driver_check_racy_pc8736x_gpio_change_pc8736x_gpio_current.bpl', 'gpio', '$M.5[')
]:
    src = scratch / 'runs' / (case_id + '_corral_final1')
    log = (src / 'stdout-stderr.log').read_text()
    block = next(b for b in log.split('Running corral\n')[1:] if model in b.splitlines()[0])
    (out / 'evidence/witnesses' / (label + '-corral-trace.txt')).write_text('Running corral\n' + block, encoding='utf-8')
    lines = (src / 'input' / model).read_text().splitlines()
    last_source, mapped = None, {}
    for num, line in enumerate(lines, 1):
        loc = re.search(r'sourceloc "driver.re.c", (\d+), (\d+)', line)
        if loc:
            last_source = {'line': int(loc[1]), 'column': int(loc[2])}
        mapped[num] = last_source
    steps = []
    for log_line in block.splitlines():
        match = re.search(r'^\((\d+),(\d+)\).*\.bpl\((\d+),(\d+)\):', log_line)
        if not match:
            continue
        num = int(match[3])
        code = lines[num - 1].strip()
        if memory not in code or not mapped[num]:
            continue
        steps.append({'thread': int(match[1]), 'context_label': int(match[2]), 'model_line': num, 'source_line': mapped[num]['line'],
                      'statement': code, 'assertion_fails': 'ASSERTION FAILS' in log_line, 'raw_trace_line': log_line})
    assert any(step['assertion_fails'] for step in steps)
    write_json(out / 'evidence/witnesses' / (label + '-steps.json'), {'case': case_id, 'model': model, 'steps': steps,
            'note': 'Extracted from actual Corral trace; no concrete numeric memory values inferred'})

write_json(out / 'source-lock.json', lock)
write_json(out / 'results.json', results)
with (out / 'results.csv').open('w', newline='', encoding='utf-8-sig') as stream:
    writer = csv.writer(stream)
    writer.writerow(['case', 'pairs', 'Whoop_potentially_racy_pairs', 'Whoop_error_count', 'Corral_counterexample_pairs', 'target_verdict', 'k', 'recursion_bound'])
    for result in results['cases']:
        writer.writerow([result['case'], result['static']['total_pairs'], result['static']['potentially_racy_pairs'], result['static']['reported_errors'],
                         result['corral_counterexample_pairs'], result['target_corral_verdict'], 2, 1])
for source in (scratch / 'logs').iterdir():
    if source.is_file():
        shutil.copyfile(source, out / 'build-logs' / source.name)
for name in ['findtools.py', 'collect-runtime.py', 'repair-lock-context.py', 'check-pairs.py', 'check-gpio-target.py', 'summarize-runs.py']:
    shutil.copyfile(scratch / name, out / 'tools' / name)
runner = (scratch / 'record-run.py').read_text()
runner = runner.replace("WORKSPACE = '/workspace'", "WORKSPACE = '/repro'")
runner = runner.replace("PACKAGE = WORKSPACE + '/outputs/whoop-handoff'", "PACKAGE = WORKSPACE")
runner = runner.replace("WORKSPACE + '/work/reproduce/runs/'", "WORKSPACE + '/reproduced-runs/'")
(out / 'tools/run.py').write_text(runner, encoding='utf-8', newline='\n')
print(json.dumps([{k: result[k] for k in ['case', 'target_corral_verdict', 'corral_counterexample_pairs']} for result in results['cases']], ensure_ascii=False))
for label in ['nvram', 'gpio']:
    print(label, (out / 'evidence/witnesses' / (label + '-steps.json')).read_text())
