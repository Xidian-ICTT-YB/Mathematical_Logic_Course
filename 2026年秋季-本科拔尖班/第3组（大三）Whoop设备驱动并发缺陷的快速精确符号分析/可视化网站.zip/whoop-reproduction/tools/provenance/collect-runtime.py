from __future__ import print_function
import hashlib
import io
import json
import os
import subprocess

def sha(path):
    value = hashlib.sha256()
    with open(path, 'rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            value.update(chunk)
    return value.hexdigest()

commands = {
    'os': ['cat', '/etc/os-release'],
    'python': ['python2.7', '--version'],
    'mono': ['mono', '--version'],
    'clang': ['/usr/lib/llvm-3.5/bin/clang', '--version'],
    'llvm': ['/usr/lib/llvm-3.5/bin/llvm-config', '--version'],
    'z3': ['/opt/whoop/local/bin/z3', '--version'],
    'packages': ['dpkg-query', '-W', '-f=${Package}\t${Version}\t${Architecture}\n']
}
result = {'commands': {}, 'files_sha256': {}, 'model_files_sha256': {},
          'execution': 'Unprivileged PRoot userland under existing WSL2 Ubuntu; no driver loaded or device access tests'}
for name, command in commands.items():
    result['commands'][name] = subprocess.check_output(command, stderr=subprocess.STDOUT).decode('utf-8')
paths = ['/opt/whoop/local/bin/z3', '/opt/whoop/local/bin/smack',
         '/opt/whoop/build/chauffeur/chauffeur', '/opt/whoop/src/corral/bin/Debug/corral.exe',
         '/opt/whoop/src/whoop/whoop.py', '/opt/whoop/src/whoop/findtools.py',
         '/opt/whoop/src/whoop/Source/Whoop/Regions/PairCheckingRegion.cs']
for folder in ['/opt/whoop/src/whoop/Binaries', '/opt/whoop/src/whoop/BoogieBinaries', '/opt/whoop/upstream-binaries']:
    paths += [folder + '/' + name for name in sorted(os.listdir(folder)) if name.endswith(('.dll', '.exe'))]
for path in paths:
    result['files_sha256'][path] = sha(path)
for base, dirs, files in os.walk('/opt/whoop/src/whoop/Model'):
    for name in files:
        path = os.path.join(base, name)
        result['model_files_sha256'][path] = sha(path)
with io.open('/workspace/work/reproduce/runtime-manifest.json', 'w', encoding='utf-8') as stream:
    stream.write(json.dumps(result, indent=2, sort_keys=True) + u'\n')
print('RUNTIME_MANIFEST_RECORDED')
