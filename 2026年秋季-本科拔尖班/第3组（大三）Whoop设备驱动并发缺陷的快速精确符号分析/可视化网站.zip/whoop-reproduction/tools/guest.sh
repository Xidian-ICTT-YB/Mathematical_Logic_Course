#!/usr/bin/env bash
set -euo pipefail
runtime=${1:?Usage: guest.sh RUNTIME_DIRECTORY COMMAND [ARGS...]}
shift
runtime=$(realpath "$runtime")
package=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
test -x "$runtime/portable/usr/bin/proot" || { echo 'Missing portable PRoot runtime' >&2; exit 2; }
test -f "$runtime/rootfs/opt/whoop/src/whoop/Binaries/WhoopEngine.exe" || exit 2
mkdir -p "$runtime/rootfs/dev" "$runtime/rootfs/proc" "$runtime/rootfs/repro" "$runtime/rootfs/tmp"
ln -sfn /proc/self/fd "$runtime/rootfs/dev/fd"
export LD_LIBRARY_PATH="$runtime/portable/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
exec "$runtime/portable/usr/bin/proot" -0 -r "$runtime/rootfs" \
  -b /dev/null -b /dev/urandom -b /dev/random -b /dev/zero -b /proc \
  -b "$package:/repro" -w /repro \
  /usr/bin/env -u LD_LIBRARY_PATH WHOOP_GUEST=1 PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin LANG=C LC_ALL=C "$@"
