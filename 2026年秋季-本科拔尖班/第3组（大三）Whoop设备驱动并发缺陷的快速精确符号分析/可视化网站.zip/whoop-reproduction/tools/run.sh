#!/usr/bin/env bash
set -euo pipefail
runtime=${1:?Usage: run.sh RUNTIME_DIRECTORY CASE [static|corral] --tag UNIQUE}
shift
exec bash "$(dirname "${BASH_SOURCE[0]}")/guest.sh" "$runtime" python2.7 -u /repro/tools/run.py "$@"
