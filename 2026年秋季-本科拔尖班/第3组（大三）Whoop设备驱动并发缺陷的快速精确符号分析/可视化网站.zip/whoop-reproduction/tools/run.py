#!/usr/bin/env python2.7
from __future__ import print_function
import argparse
import datetime
import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import time

WORKSPACE = '/repro'
WHOOP = '/opt/whoop/src/whoop'
PACKAGE = WORKSPACE

def digest(path):
    value = hashlib.sha256()
    with open(path, 'rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()

def json_write(path, value):
    with io.open(path, 'w', encoding='utf-8') as stream:
        stream.write(json.dumps(value, ensure_ascii=True, indent=2) + u'\n')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case')
    parser.add_argument('mode', choices=['static', 'corral', 'preflight'])
    parser.add_argument('--tag', required=True)
    parser.add_argument('--timeout', type=int, default=300)
    parser.add_argument('--wall-timeout', type=int, default=1200)
    parser.add_argument('--extra', action='append', default=[])
    args = parser.parse_args()
    if not all(c.isalnum() or c in '_-' for c in args.tag):
        parser.error('Use a simple unique tag')
    with open(PACKAGE + '/source-lock.json', 'rb') as stream:
        locked = json.load(stream)
    cases = dict((item['id'], item) for item in locked['cases'])
    smoke = {
        'G0_racy': 'testsuite/basic_data_races/no_locks/write_race/test.c',
        'G0_locked': 'testsuite/two_entry_points/no_race/case_1/test.c',
        'G1_one_sided': 'testsuite/two_entry_points/write_write_race_1/test.c'
    }
    if args.case in cases:
        source = PACKAGE + '/' + cases[args.case]['file']
        expected = cases[args.case]['sha256']
    elif args.case in smoke:
        source = WHOOP + '/' + smoke[args.case]
        expected = digest(source)
    else:
        parser.error('Unknown case')
    if digest(source) != expected:
        raise RuntimeError('Input SHA256 mismatch: ' + source)
    run_dir = WORKSPACE + '/reproduced-runs/' + args.case + '_' + args.mode + '_' + args.tag
    input_dir = run_dir + '/input'
    os.makedirs(input_dir)
    shutil.copyfile(source, input_dir + '/driver.c')
    command = ['timeout', '-k', '15s', str(args.wall_timeout) + 's', 'python2.7', '-u', WHOOP + '/whoop.py', 'driver.c',
               '--verbose', '--time', '--keep-temps', '--print-pairs', '--timeout=' + str(args.timeout)]
    if args.mode == 'corral':
        command.extend(['--find-bugs', '--yield-race-check', '--k=2', '--recursion-bound=1'])
    elif args.mode == 'preflight':
        command.append('--stop-at-bpl')
    command.extend(args.extra)
    meta = {'case': args.case, 'mode': args.mode, 'status': 'running', 'argv': command, 'cwd': input_dir,
            'input_sha256': expected, 'started_utc': datetime.datetime.utcnow().isoformat() + 'Z',
            'whoop_source_commit': locked['whoop_commit'],
            'whoop_py_sha256': digest(WHOOP + '/whoop.py'),
            'findtools_sha256': digest(WHOOP + '/findtools.py'),
            'whoop_engine_sha256': digest(WHOOP + '/Binaries/WhoopEngine.exe'),
            'whoop_library_sha256': digest(WHOOP + '/Binaries/Whoop.dll'),
            'whoop_pair_checking_source_sha256': digest(WHOOP + '/Source/Whoop/Regions/PairCheckingRegion.cs'),
            'bounds': {'k': 2, 'recursion_bound': 1} if args.mode == 'corral' else None,
            'classification': 'requires_manual_review',
            'execution_scope': 'author_models_static_analysis_only_no_driver_loading'}
    json_write(run_dir + '/run.json', meta)
    print('RUN_DIRECTORY ' + run_dir)
    sys.stdout.flush()
    started = time.time()
    with open(run_dir + '/stdout-stderr.log', 'wb') as log, io.open(run_dir + '/events.jsonl', 'w', encoding='utf-8') as events:
        process = subprocess.Popen(command, cwd=input_dir, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        for line in iter(process.stdout.readline, b''):
            log.write(line)
            log.flush()
            events.write(json.dumps({'seconds': round(time.time() - started, 4), 'stream': 'combined',
                                     'text': line.decode('utf-8', 'replace')}, ensure_ascii=True) + u'\n')
            events.flush()
            sys.stdout.write(line)
            sys.stdout.flush()
        exit_code = process.wait()
    meta.update(status='finished', exit_code=exit_code, wall_seconds=round(time.time() - started, 4),
                ended_utc=datetime.datetime.utcnow().isoformat() + 'Z')
    meta['generated_files'] = dict((name, digest(input_dir + '/' + name)) for name in sorted(os.listdir(input_dir))
                                   if os.path.isfile(input_dir + '/' + name))
    json_write(run_dir + '/run.json', meta)
    print('RUN_EXIT_CODE %d (not an automatic verdict)' % exit_code)
    return exit_code

if __name__ == '__main__':
    sys.exit(main())
