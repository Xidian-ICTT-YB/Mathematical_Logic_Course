param(
    [ValidateSet('A0_nvram_original','A1_nvram_llseek_lock','B0_gpio_original','B1_gpio_writer_only','B2_gpio_shadow_lock','G0_locked','G0_racy','G1_one_sided')]
    [string]$Case = 'A0_nvram_original',
    [ValidateSet('static','corral')][string]$Mode = 'corral',
    [string]$Runtime = '/var/tmp/whoop-repro-20261025/work',
    [string]$Tag = ('demo-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
)
$ErrorActionPreference = 'Stop'
$linuxScript = (& wsl.exe -d Ubuntu -- wslpath -a (Join-Path $PSScriptRoot 'run.sh')).Trim()
if ($LASTEXITCODE -ne 0) { throw 'Cannot locate the package in the Ubuntu WSL distribution.' }
& wsl.exe -d Ubuntu -- bash $linuxScript $Runtime $Case $Mode --tag $Tag
if ($LASTEXITCODE -ne 0) {
    Write-Host 'Check reproduced-runs/<case>_<mode>_<tag>/run.json and the log. A static race report has Whoop exit code 6.'
}
