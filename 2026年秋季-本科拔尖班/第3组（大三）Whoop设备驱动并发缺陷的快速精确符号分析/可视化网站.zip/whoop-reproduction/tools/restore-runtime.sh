#!/usr/bin/env bash
set -euo pipefail
archive=${1:?Usage: restore-runtime.sh ARCHIVE NEW_RUNTIME_DIRECTORY}
destination=${2:?Choose a new directory on the Linux filesystem}
archive=$(realpath "$archive")
package=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
test ! -e "$destination" || { echo 'Destination already exists; choose a new directory.' >&2; exit 2; }
expected=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["sha256"])' "$package/runtime-archive.json")
actual=$(sha256sum "$archive" | cut -d ' ' -f1)
test "$actual" = "$expected" || { echo 'Runtime SHA256 mismatch' >&2; exit 2; }
mkdir -p "$destination"
tar --extract --gzip --no-same-owner --file "$archive" --directory "$destination"
bash "$package/tools/guest.sh" "$destination" /opt/whoop/local/bin/z3 --version
echo 'Runtime restored. No host packages or kernel modules were installed.'
