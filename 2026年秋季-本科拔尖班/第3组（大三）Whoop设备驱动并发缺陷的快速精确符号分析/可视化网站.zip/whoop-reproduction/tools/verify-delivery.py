"""Read-only verification of the delivered claims against preserved evidence."""
import argparse
import hashlib
import json
import re
from pathlib import Path

root = Path(__file__).resolve().parents[1]

def load(path):
    return json.loads(path.read_text(encoding='utf-8'))

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            value.update(chunk)
    return value.hexdigest()

def parse_log(log):
    summary = re.search(r'finished with (\d+) \(out of (\d+)\) entry point pairs verified, (\d+) errors?',log)
    assert summary, 'Missing Whoop stage summary'
    pairs = {}
    for block in log.split('Running corral\n')[1:]:
        model = re.search(r'(driver_check_racy_[^\s/]+\.bpl)',block).group(1)
        assert model not in pairs, 'Duplicate pair run'
        if 'Program has a potential bug: True bug' in block and 'ASSERTION FAILS' in block:
            pairs[model] = 'counterexample'
        elif 'Program has no bugs' in block:
            pairs[model] = 'no_counterexample_within_bounds'
        else:
            raise AssertionError('Unresolved Corral verdict: '+model)
    return (int(summary[1]),int(summary[2]),int(summary[3])),pairs

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--record',action='store_true')
    args=parser.parse_args()
    lock=load(root/'source-lock.json'); results=load(root/'results.json'); visual=load(root/'visual-data.json')
    targets={'A0_nvram_original':'counterexample','A1_nvram_llseek_lock':'no_counterexample_within_bounds',
             'B0_gpio_original':'counterexample','B1_gpio_writer_only':'counterexample','B2_gpio_shadow_lock':'no_counterexample_within_bounds'}
    checks=[]
    for c in lock['cases']:
        assert digest(root/c['file'])==c['sha256'],c['id']+' source hash'
    for component,entry in lock['components'].items():
        assert digest(root/entry['archive'])==entry['sha256'],component+' archive hash'
    assert digest(root/'patches/whoop-lock-context.patch')==lock['components']['whoop']['patch_sha256']
    checks.append('Five C inputs, five source archives and tool patch match locked SHA256 values')
    for result in results['cases']:
        case=result['case']; directory=root/result['evidence_directory']; meta=load(directory/'run.json')
        assert meta['status']=='finished' and meta['exit_code']==0
        assert meta['bounds']==results['bounds']=={'k':2,'recursion_bound':1}
        stats,pairs=parse_log((directory/'stdout-stderr.log').read_text())
        assert stats==(result['static']['verified_pairs'],result['static']['total_pairs'],result['static']['reported_errors'])
        assert len(pairs)==stats[1]
        assert pairs=={p['model']:p['verdict'] for p in result['pairs']}
        assert pairs[result['presentation_target']]==targets[case]==result['target_corral_verdict']
        assert sum(v=='counterexample' for v in pairs.values())==result['corral_counterexample_pairs']
        for name,sha in meta['generated_files'].items():
            assert digest(directory/'input'/name)==sha,(case,name)
        c=visual['cases'][case]
        for key in ['sourcePath','logPath','modelPath','tracePath']:
            if c[key]: assert (root/c[key]).is_file(),c[key]
        model_lines=(root/c['modelPath']).read_text().splitlines()
        if c['steps']:
            trace=(root/c['tracePath']).read_text()
            assert c['steps'][-1]['assertion_fails']
            for s in c['steps']:
                assert model_lines[s['model_line']-1].strip()==s['statement']
                assert re.search(r'\('+str(s['thread'])+r',\d+\).*\.bpl\('+str(s['model_line'])+r',',trace)
                assert any(line['line']==s['source_line'] for line in c['source'])
        checks.append(case+': logs, bounds, generated files, target verdict and displayed trace agree')
    calibration=root/'evidence/calibration'
    locked=load(calibration/'G0_locked_static_repaired1/run.json')
    unlocked=load(calibration/'G0_racy_static_repaired1/run.json')
    assert locked['exit_code']==0 and unlocked['exit_code']==6
    assert 'Program has a potential bug: True bug' in (calibration/'G1_one_sided_corral_repaired1/stdout-stderr.log').read_text()
    checks.append('Calibration retains the positive and negative controls')
    for case in ['A0_nvram_original','B2_gpio_shadow_lock']:
        replay=root/'reproduced-runs'/(case+'_corral_archive_acceptance')
        assert load(replay/'run.json')['status']=='finished'
        main_dir=root/'evidence/main'/case
        assert parse_log((replay/'stdout-stderr.log').read_text())==parse_log((main_dir/'stdout-stderr.log').read_text())
        original_meta=load(main_dir/'run.json'); repeat_meta=load(replay/'run.json')
        for field in ['whoop_engine_sha256','whoop_library_sha256','whoop_pair_checking_source_sha256','input_sha256']:
            assert original_meta[field]==repeat_meta[field],field
    checks.append('Two complete reruns from a newly extracted runtime reproduce all pair verdicts (A0 and B2)')
    html=(root/'index.html').read_text(encoding='utf-8')
    for href in re.findall(r'href="([^"]+)"',html.split('<script')[0]):
        if not href.startswith(('https:','http:','#')):
            assert (root/href).is_file(),href
    assert '__WHOOP_DATA__' not in html
    assert len(list((root/'slides').glob('*.png')))==4
    checks.append('All local HTML links exist; data embedded; four presentation PNGs present')
    if (root/'SHA256SUMS').exists():
        count=0
        for line in (root/'SHA256SUMS').read_text().splitlines():
            sha,name=line.split('  ',1)
            assert digest(root/name)==sha,name
            count+=1
        checks.append('Full delivery file hash verification: '+str(count)+' files')
    if args.record:
        (root/'verification.json').write_text(json.dumps({'status':'passed','checks':checks,
            'visual_review':'Minimal demo inspected in local HTTP preview: all five versions, step controls, source highlighting and automatic playback work; browser console reported no errors. Introductory headers, footer, result and handoff tabs were removed from the page. Existing slides and video were not changed in this UI update.',
            'offline_file_preview':'Browser tool rejects file: protocol; file-navigation validation not performed. Page contains its own CSS, JavaScript and data, with no external runtime dependencies.',
            'self_review':'Reviewed driver and tool patches, shared-access boundaries and result wording. A1 also caches its return value and is not a lock-only experiment; B2 does not make the whole read-modify-write operation atomic. Negative Corral outcomes remain bounded; residual Whoop warnings are retained. These limitations are documented.',
            'scope':'No driver loading, hardware test or security-sensitive test performed.'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'passed','checks':checks},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
