procedure corral_atomic_begin();



procedure corral_atomic_end();



procedure corral_getThreadID() returns (t: int);



var $M.0: [int]int;

var $M.1: int;

var $M.2: [int]int;

var $M.3: [int]int;

var $M.4: [int]int;

var $M.5: [int]int;

var $M.6: [int]int;

var $M.7: [int]int;

var $M.8: [int]int;

var $M.9: [int]int;

var $M.10: [int]int;

var $M.11: [int]int;

var $M.12: [int]int;

var $M.13: [int]int;

var $M.14: [int]int;

var $M.15: [int]int;

var $M.16: [int]int;

axiom $GLOBALS_BOTTOM == -5188;

const unique .str: int;

const unique .str1: int;

const unique .str10: int;

const unique .str100: int;

const unique .str101: int;

const unique .str102: int;

const unique .str103: int;

const unique .str104: int;

const unique .str11: int;

const unique .str12: int;

const unique .str13: int;

const unique .str14: int;

const unique .str15: int;

const unique .str16: int;

const unique .str17: int;

const unique .str18: int;

const unique .str19: int;

const unique .str2: int;

const unique .str20: int;

const unique .str21: int;

const unique .str22: int;

const unique .str23: int;

const unique .str24: int;

const unique .str25: int;

const unique .str26: int;

const unique .str27: int;

const unique .str28: int;

const unique .str29: int;

const unique .str3: int;

const unique .str30: int;

const unique .str31: int;

const unique .str32: int;

const unique .str33: int;

const unique .str34: int;

const unique .str35: int;

const unique .str36: int;

const unique .str37: int;

const unique .str38: int;

const unique .str39: int;

const unique .str4: int;

const unique .str40: int;

const unique .str41: int;

const unique .str42: int;

const unique .str43: int;

const unique .str44: int;

const unique .str45: int;

const unique .str46: int;

const unique .str47: int;

const unique .str48: int;

const unique .str49: int;

const unique .str5: int;

const unique .str50: int;

const unique .str51: int;

const unique .str52: int;

const unique .str53: int;

const unique .str54: int;

const unique .str55: int;

const unique .str56: int;

const unique .str57: int;

const unique .str58: int;

const unique .str59: int;

const unique .str6: int;

const unique .str60: int;

const unique .str61: int;

const unique .str62: int;

const unique .str63: int;

const unique .str64: int;

const unique .str65: int;

const unique .str66: int;

const unique .str67: int;

const unique .str68: int;

const unique .str69: int;

const unique .str7: int;

const unique .str70: int;

const unique .str71: int;

const unique .str72: int;

const unique .str73: int;

const unique .str74: int;

const unique .str75: int;

const unique .str76: int;

const unique .str77: int;

const unique .str78: int;

const unique .str79: int;

const unique .str8: int;

const unique .str80: int;

const unique .str81: int;

const unique .str82: int;

const unique .str83: int;

const unique .str84: int;

const unique .str85: int;

const unique .str86: int;

const unique .str87: int;

const unique .str88: int;

const unique .str89: int;

const unique .str9: int;

const unique .str90: int;

const unique .str91: int;

const unique .str92: int;

const unique .str93: int;

const unique .str94: int;

const unique .str95: int;

const unique .str96: int;

const unique .str97: int;

const unique .str98: int;

const unique .str99: int;

const unique __SMACK_decls: int;

const unique __SMACK_nondet: int;

const unique __SMACK_nondet.XXX: int;

const unique _whoop_exit: int;

const unique _whoop_init: int;

const unique alloc_testdev: int;

const unique entrypoint2: int;

const unique init: int;

const unique malloc: int;

const unique mutex_init: int;

const unique mutex_lock: int;

const unique mutex_unlock: int;

const unique whoop$checker: int;

procedure {:inline 1} __SMACK_nondet() returns ($r: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16;



implementation {:inline 1} __SMACK_nondet() returns ($r: int)
{
  var $p0: int;

  $bb0:
    assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 53, 3} true;
    $p0 := $M.1;
    assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 54, 3} true;
    havoc $p0;
    assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 55, 3} true;
    $r := $p0;
    return;
}



procedure {:inline 1} alloc_testdev(sizeof_priv: int) returns ($r: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16;



implementation {:inline 1} alloc_testdev(sizeof_priv: int) returns ($r: int)
{
  var $p0: int;
  var $p1: int;
  var $p2: int;

  $bb0:
    assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 20, 51} true;
    $p0 := sizeof_priv;
    assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 20, 51} true;
    call $p1 := $malloc($p0);
    assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 20, 51} true;
    $p2 := $p1;
    assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 21, 2} true;
    $r := $p2;
    return;
}



procedure entrypoint2(dev: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16;



implementation entrypoint2(dev: int)
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
  var $p4: int;
  var $p5: int;

  $bb0:
    assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 26, 2} true;
    $p0 := dev;
    assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 26, 2} true;
    $p1 := $pa($p0, 32, 1);
    assume {:sourceloc "driver.re.c", 21, 22} true;
    $p2 := $p1;
    assume {:sourceloc "driver.re.c", 23, 2} true;
    $p3 := $pa($pa($p2, 0, 12), 4, 1);
    assume {:sourceloc "driver.re.c", 23, 2} true;
    yield;
    call mutex_lock($p3);
    assume {:sourceloc "driver.re.c", 24, 2} true;
    $p4 := $pa($pa($p2, 0, 12), 0, 1);
    assume {:sourceloc "driver.re.c", 24, 2} true;
    $M.16[$p4] := 2;
    assume {:sourceloc "driver.re.c", 25, 2} true;
    $p5 := $pa($pa($p2, 0, 12), 4, 1);
    assume {:sourceloc "driver.re.c", 25, 2} true;
    yield;
    call mutex_unlock($p5);
    assume {:sourceloc "driver.re.c", 26, 1} true;
    return;
}



procedure {:entrypoint} init(pdev: int, ent: int) returns ($r: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16;



implementation {:entrypoint} init(pdev: int, ent: int) returns ($r: int)
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
  var $p4: int;

  $bb0:
    assume {:sourceloc "driver.re.c", 31, 28} true;
    call $p0 := alloc_testdev(12);
    assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 26, 2} true;
    $p1 := $p0;
    assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 26, 2} true;
    $p2 := $pa($p1, 32, 1);
    assume {:sourceloc "driver.re.c", 33, 7} true;
    $p3 := $p2;
    assume {:sourceloc "driver.re.c", 34, 2} true;
    $p4 := $pa($pa($p3, 0, 12), 4, 1);
    assume {:sourceloc "driver.re.c", 34, 2} true;
    call mutex_init($p4);
    assume {:sourceloc "driver.re.c", 36, 2} true;
    $r := 0;
    call whoop$checker(pdev, ent);
    return;
}



procedure {:inline 1} mutex_init(lock: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16;



implementation {:inline 1} mutex_init(lock: int)
{
  var $p0: int;
  var $p1: int;

  $bb0:
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 29, 2} true;
    $p0 := $pa($pa(lock, 0, 8), 4, 1);
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 29, 2} true;
    $M.4[$p0] := 0;
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 30, 2} true;
    $p1 := $pa($pa(lock, 0, 8), 0, 1);
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 30, 2} true;
    $M.5[$p1] := 1;
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 31, 1} true;
    return;
}



procedure {:inline 1} mutex_lock(lock: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16;



implementation {:inline 1} mutex_lock(lock: int)
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;

  $bb0:
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 35, 12} true;
    call $p0 := __SMACK_nondet();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 36, 2} true;
    call $p0 := corral_getThreadID();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 38, 2} true;
    call corral_atomic_begin();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 39, 2} true;
    $p1 := $pa($pa(lock, 0, 8), 4, 1);
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 39, 2} true;
    $p2 := $M.4[$p1];
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 39, 2} true;
    assume $p2 == 0;
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 40, 2} true;
    $p3 := $pa($pa(lock, 0, 8), 4, 1);
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 40, 2} true;
    $M.4[$p3] := $p0;
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 41, 2} true;
    call corral_atomic_end();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 42, 1} true;
    return;
}



procedure {:inline 1} mutex_unlock(lock: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16;



implementation {:inline 1} mutex_unlock(lock: int)
{
  var $p0: int;
  var $p1: int;

  $bb0:
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 61, 12} true;
    call $p0 := __SMACK_nondet();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 62, 2} true;
    call $p0 := corral_getThreadID();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 64, 2} true;
    call corral_atomic_begin();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 65, 2} true;
    $p1 := $pa($pa(lock, 0, 8), 4, 1);
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 65, 2} true;
    $M.4[$p1] := 0;
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 66, 2} true;
    call corral_atomic_end();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 67, 1} true;
    return;
}



procedure {:inline 1} whoop$checker(pdev: int, ent: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16;



implementation {:inline 1} whoop$checker(pdev: int, ent: int)
{
  var $p0: int;

  $bb0:
    assume {:sourceloc "driver.re.c", 49, 8} true;
    assume {:sourceloc "driver.re.c", 51, 2} true;
    async call entrypoint2$ep($p0);
    assume {:sourceloc "driver.re.c", 52, 2} true;
    assume {:sourceloc "driver.re.c", 53, 1} true;
    return;
}



axiom __SMACK_nondet.XXX == -34;

axiom _whoop_init == -5180;

axiom _whoop_exit == -5188;

axiom $NULL == 0;

axiom $and(0, 0) == 0;

axiom $and(0, 1) == 0;

axiom $and(1, 0) == 0;

axiom $and(1, 1) == 1;

axiom $or(0, 0) == 0;

axiom $or(0, 1) == 1;

axiom $or(1, 0) == 1;

axiom $or(1, 1) == 1;

axiom $xor(0, 0) == 0;

axiom $xor(0, 1) == 1;

axiom $xor(1, 0) == 1;

axiom $xor(1, 1) == 0;

axiom (forall f1: float, f2: float :: f1 != f2 || $foeq(f1, f2));

axiom (forall f: float :: $si2fp($fp2si(f)) == f);

axiom (forall f: float :: $ui2fp($fp2ui(f)) == f);

axiom (forall i: int :: $fp2si($si2fp(i)) == i);

axiom (forall i: int :: $fp2ui($ui2fp(i)) == i);

const $GLOBALS_BOTTOM: int;

const $MOP: $mop;

const $UNDEF: int;

const unique $NULL: int;

function $and(p1: int, p2: int) : int;

function $ashr(p1: int, p2: int) : int;

function $base(int) : int;

function $extractvalue(p: int, i: int) : int;

function $fadd(f1: float, f2: float) : float;

function $fdiv(f1: float, f2: float) : float;

function $ffalse(f1: float, f2: float) : bool;

function $fmul(f1: float, f2: float) : float;

function $foeq(f1: float, f2: float) : bool;

function $foge(f1: float, f2: float) : bool;

function $fogt(f1: float, f2: float) : bool;

function $fole(f1: float, f2: float) : bool;

function $folt(f1: float, f2: float) : bool;

function $fone(f1: float, f2: float) : bool;

function $ford(f1: float, f2: float) : bool;

function $fp(ipart: int, fpart: int, epart: int) : float;

function $fp2si(f: float) : int;

function $fp2ui(f: float) : int;

function $frem(f1: float, f2: float) : float;

function $fsub(f1: float, f2: float) : float;

function $ftrue(f1: float, f2: float) : bool;

function $fueq(f1: float, f2: float) : bool;

function $fuge(f1: float, f2: float) : bool;

function $fugt(f1: float, f2: float) : bool;

function $fule(f1: float, f2: float) : bool;

function $fult(f1: float, f2: float) : bool;

function $fune(f1: float, f2: float) : bool;

function $funo(f1: float, f2: float) : bool;

function $lshr(p1: int, p2: int) : int;

function $nand(p1: int, p2: int) : int;

function $or(p1: int, p2: int) : int;

function $shl(p1: int, p2: int) : int;

function $si2fp(i: int) : float;

function $ui2fp(i: int) : float;

function $xor(p1: int, p2: int) : int;

function {:builtin "div"} $sdiv(p1: int, p2: int) : int;

function {:builtin "div"} $udiv(p1: int, p2: int) : int;

function {:builtin "rem"} $srem(p1: int, p2: int) : int;

function {:builtin "rem"} $urem(p1: int, p2: int) : int;

function {:inline} $add(p1: int, p2: int) : int
{
  p1 + p2
}

function {:inline} $b2i(b: bool) : int
{
  (if b then 1 else 0)
}

function {:inline} $b2p(b: bool) : int
{
  (if b then 1 else 0)
}

function {:inline} $i2b(i: int) : bool
{
  i != 0
}

function {:inline} $i2p(p: int) : int
{
  p
}

function {:inline} $isExternal(p: int) : bool
{
  p < $GLOBALS_BOTTOM - 32768
}

function {:inline} $max(p1: int, p2: int) : int
{
  (if p1 > p2 then p1 else p2)
}

function {:inline} $min(p1: int, p2: int) : int
{
  (if p1 > p2 then p2 else p1)
}

function {:inline} $mul(p1: int, p2: int) : int
{
  p1 * p2
}

function {:inline} $p2b(p: int) : bool
{
  p != 0
}

function {:inline} $p2i(p: int) : int
{
  p
}

function {:inline} $pa(pointer: int, index: int, size: int) : int
{
  pointer + index * size
}

function {:inline} $sge(p1: int, p2: int) : bool
{
  p1 >= p2
}

function {:inline} $sgt(p1: int, p2: int) : bool
{
  p1 > p2
}

function {:inline} $sle(p1: int, p2: int) : bool
{
  p1 <= p2
}

function {:inline} $slt(p1: int, p2: int) : bool
{
  p1 < p2
}

function {:inline} $sub(p1: int, p2: int) : int
{
  p1 - p2
}

function {:inline} $trunc(p: int, size: int) : int
{
  p
}

function {:inline} $uge(p1: int, p2: int) : bool
{
  p1 >= p2
}

function {:inline} $ugt(p1: int, p2: int) : bool
{
  p1 > p2
}

function {:inline} $ule(p1: int, p2: int) : bool
{
  p1 <= p2
}

function {:inline} $ult(p1: int, p2: int) : bool
{
  p1 < p2
}

function {:inline} $umax(p1: int, p2: int) : int
{
  (if p1 > p2 then p1 else p2)
}

function {:inline} $umin(p1: int, p2: int) : int
{
  (if p1 > p2 then p2 else p1)
}

procedure {:inline 1} $malloc(n: int) returns (p: int);
  modifies $CurrAddr, $Alloc;



implementation {:inline 1} $malloc(n: int) returns (p: int)
{
  anon0:
    assume $CurrAddr > 0;
    p := $CurrAddr;
    goto anon4_Then, anon4_Else;

  anon4_Then:
    assume {:partition} n > 0;
    $CurrAddr := $CurrAddr + n;
    goto anon3;

  anon4_Else:
    assume {:partition} 0 >= n;
    $CurrAddr := $CurrAddr + 1;
    goto anon3;

  anon3:
    $Alloc[p] := true;
    return;
}



procedure {:inline 1} boogie_si_record_bool(b: bool);



procedure {:inline 1} boogie_si_record_float(f: float);



procedure {:inline 1} boogie_si_record_int(i: int);



procedure {:inline 1} boogie_si_record_mop(m: $mop);



type $mop;

type float;

var $Alloc: [int]bool;

var $CurrAddr: int;

var $exn: bool;

var $exnv: int;

procedure entrypoint2$ep($p0: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16;



implementation entrypoint2$ep($p0: int)
{

  _EP:
    call entrypoint2($p0);
    return;
}


