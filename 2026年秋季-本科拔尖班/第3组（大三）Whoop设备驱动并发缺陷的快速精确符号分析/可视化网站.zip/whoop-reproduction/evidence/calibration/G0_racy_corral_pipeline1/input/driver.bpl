// BEGIN SMACK-GENERATED CODE

// Memory region declarations: 18
var $M.0: [int] int;
var $M.1: int;
var $M.2: [int] int;
var $M.3: [int] int;
var $M.4: [int] int;
var $M.5: [int] int;
var $M.6: [int] int;
var $M.7: [int] int;
var $M.8: [int] int;
var $M.9: [int] int;
var $M.10: [int] int;
var $M.11: [int] int;
var $M.12: [int] int;
var $M.13: [int] int;
var $M.14: [int] int;
var $M.15: [int] int;
var $M.16: [int] int;
var $M.17: [int] int;

axiom $GLOBALS_BOTTOM == -5188;
const unique .str: int;
const unique .str1: int;
const unique .str10: int;
const unique .str100: int;
const unique .str101: int;
const unique .str102: int;
const unique .str103: int;
const unique .str104: int;
const unique .str11: int;
const unique .str12: int;
const unique .str13: int;
const unique .str14: int;
const unique .str15: int;
const unique .str16: int;
const unique .str17: int;
const unique .str18: int;
const unique .str19: int;
const unique .str2: int;
const unique .str20: int;
const unique .str21: int;
const unique .str22: int;
const unique .str23: int;
const unique .str24: int;
const unique .str25: int;
const unique .str26: int;
const unique .str27: int;
const unique .str28: int;
const unique .str29: int;
const unique .str3: int;
const unique .str30: int;
const unique .str31: int;
const unique .str32: int;
const unique .str33: int;
const unique .str34: int;
const unique .str35: int;
const unique .str36: int;
const unique .str37: int;
const unique .str38: int;
const unique .str39: int;
const unique .str4: int;
const unique .str40: int;
const unique .str41: int;
const unique .str42: int;
const unique .str43: int;
const unique .str44: int;
const unique .str45: int;
const unique .str46: int;
const unique .str47: int;
const unique .str48: int;
const unique .str49: int;
const unique .str5: int;
const unique .str50: int;
const unique .str51: int;
const unique .str52: int;
const unique .str53: int;
const unique .str54: int;
const unique .str55: int;
const unique .str56: int;
const unique .str57: int;
const unique .str58: int;
const unique .str59: int;
const unique .str6: int;
const unique .str60: int;
const unique .str61: int;
const unique .str62: int;
const unique .str63: int;
const unique .str64: int;
const unique .str65: int;
const unique .str66: int;
const unique .str67: int;
const unique .str68: int;
const unique .str69: int;
const unique .str7: int;
const unique .str70: int;
const unique .str71: int;
const unique .str72: int;
const unique .str73: int;
const unique .str74: int;
const unique .str75: int;
const unique .str76: int;
const unique .str77: int;
const unique .str78: int;
const unique .str79: int;
const unique .str8: int;
const unique .str80: int;
const unique .str81: int;
const unique .str82: int;
const unique .str83: int;
const unique .str84: int;
const unique .str85: int;
const unique .str86: int;
const unique .str87: int;
const unique .str88: int;
const unique .str89: int;
const unique .str9: int;
const unique .str90: int;
const unique .str91: int;
const unique .str92: int;
const unique .str93: int;
const unique .str94: int;
const unique .str95: int;
const unique .str96: int;
const unique .str97: int;
const unique .str98: int;
const unique .str99: int;
const unique __SMACK_decls: int;
const unique __SMACK_nondet: int;
const unique __SMACK_nondet.XXX: int;
const unique _whoop_exit: int;
const unique _whoop_init: int;
const unique alloc_testdev: int;
const unique assert_: int;
const unique assume_: int;
const unique entrypoint: int;
const unique init: int;
const unique malloc: int;
const unique mutex_init: int;
const unique mutex_lock: int;
const unique mutex_lock_interruptible: int;
const unique mutex_unlock: int;
const unique spin_lock: int;
const unique spin_lock_bh: int;
const unique spin_lock_init: int;
const unique spin_lock_irq: int;
const unique spin_lock_irqsave: int;
const unique spin_unlock: int;
const unique spin_unlock_bh: int;
const unique spin_unlock_irq: int;
const unique spin_unlock_irqrestore: int;
const unique whoop$checker: int;
procedure {:inline 1} $static_init()
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
  $M.1 := 0;
  $M.2[_whoop_init] := 0;
  $M.3[_whoop_exit] := 0;
  return;
}
procedure {:inline 1} __SMACK_nondet()
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
  var $p0: int;
$bb0:
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 53, 3} true;
  $p0 := $M.1;
  call {:cexpr "x"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 54, 3} true;
  havoc $p0;
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 55, 3} true;
  $r := $p0;
  $exn := false;
  return;
}
procedure {:inline 1} alloc_testdev(sizeof_priv: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
$bb0:
  call {:cexpr "sizeof_priv"} boogie_si_record_int(sizeof_priv);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 20, 51} true;
  $p0 := sizeof_priv;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 20, 51} true;
  call $p1 := $malloc($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 20, 51} true;
  $p2 := $p1;
  call {:cexpr "dev"} boogie_si_record_int($p2);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 21, 2} true;
  $r := $p2;
  $exn := false;
  return;
}
procedure {:inline 1} assert_(v: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
$bb0:
  call {:cexpr "v"} boogie_si_record_int(v);
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 37, 3} true;
  assert v != 0;
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 38, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} assume_(v: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
$bb0:
  call {:cexpr "v"} boogie_si_record_int(v);
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 41, 3} true;
  assume v != 0;
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 42, 1} true;
  $exn := false;
  return;
}
procedure entrypoint(dev: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
$bb0:
  call {:cexpr "dev"} boogie_si_record_int(dev);
  call {:cexpr "dev"} boogie_si_record_int(dev);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 26, 2} true;
  $p0 := dev;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 26, 2} true;
  $p1 := $pa($p0, 32, 1);
  assume {:sourceloc "driver.re.c", 13, 22} true;
  $p2 := $p1;
  call {:cexpr "tp"} boogie_si_record_int($p2);
  assume {:sourceloc "driver.re.c", 15, 2} true;
  $p3 := $pa($pa($p2, 0, 4), 0, 1);
  assume {:sourceloc "driver.re.c", 15, 2} true;
  $M.17[$p3] := 1;
  assume {:sourceloc "driver.re.c", 16, 1} true;
  $exn := false;
  return;
}
procedure init(pdev: int, ent: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
$bb0:
  call {:cexpr "pdev"} boogie_si_record_int(pdev);
  call {:cexpr "ent"} boogie_si_record_int(ent);
  assume {:sourceloc "driver.re.c", 21, 28} true;
  call $p0 := alloc_testdev(4);
  call {:cexpr "dev"} boogie_si_record_int($p0);
  call {:cexpr "dev"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 26, 2} true;
  $p1 := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 26, 2} true;
  $p2 := $pa($p1, 32, 1);
  assume {:sourceloc "driver.re.c", 23, 7} true;
  $p3 := $p2;
  call {:cexpr "tp"} boogie_si_record_int($p3);
  assume {:sourceloc "driver.re.c", 25, 2} true;
  $r := 0;
  $exn := false;
  return;
}
procedure {:inline 1} mutex_init(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 29, 2} true;
  $p0 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 29, 2} true;
  $M.4[$p0] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 30, 2} true;
  $p1 := $pa($pa(lock, 0, 8), 0, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 30, 2} true;
  $M.4[$p1] := 1;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 31, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} mutex_lock(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 35, 12} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 36, 2} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 38, 2} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 39, 2} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 39, 2} true;
  $p2 := $M.5[$p1];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 39, 2} true;
  assume $p2 == 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 40, 2} true;
  $p3 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 40, 2} true;
  $M.5[$p3] := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 41, 2} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 42, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} mutex_lock_interruptible(lock: int)
  returns ($r: bool)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
  var $b1: bool;
  var $b3: bool;
  var $b8: bool;
  var $p0: int;
  var $p2: int;
  var $p4: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 46, 19} true;
  call $p0 := __SMACK_nondet();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 46, 19} true;
  $b1 := ($p0 != 0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 46, 19} true;
  $p2 := $b2p($b1);
  call {:cexpr "ret"} boogie_si_record_int($p2);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 47, 5} true;
  $b3 := $i2b($p2);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 47, 5} true;
  goto $bb1, $bb3;
$bb1:
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 47, 5} true;
  assume $b3;
  goto $bb2;
$bb2:
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 56, 2} true;
  $b8 := $i2b($p2);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 56, 2} true;
  $r := $b8;
  $exn := false;
  return;
$bb3:
  assume !($b3);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 48, 13} true;
  call $p4 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p4);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 49, 3} true;
  call $p4 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 51, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 52, 3} true;
  $p5 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 52, 3} true;
  $p6 := $M.6[$p5];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 52, 3} true;
  assume $p6 == 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 53, 3} true;
  $p7 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 53, 3} true;
  $M.6[$p7] := $p4;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 54, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 55, 2} true;
  goto $bb2;
}
procedure {:inline 1} mutex_unlock(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 61, 12} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 62, 2} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 64, 2} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 65, 2} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 65, 2} true;
  $M.7[$p1] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 66, 2} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 67, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_lock(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 34, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 35, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 37, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 38, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 38, 3} true;
  $p2 := $M.9[$p1];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 38, 3} true;
  assume $p2 == 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 39, 3} true;
  $p3 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 39, 3} true;
  $M.9[$p3] := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 40, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 41, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_lock_bh(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 67, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 68, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 70, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 71, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 71, 3} true;
  $p2 := $M.12[$p1];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 71, 3} true;
  assume $p2 == 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 72, 3} true;
  $p3 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 72, 3} true;
  $M.12[$p3] := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 73, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 74, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_lock_init(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 28, 3} true;
  $p0 := $pa($pa(lock, 0, 8), 0, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 28, 3} true;
  $M.8[$p0] := 1;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 29, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 29, 3} true;
  $M.8[$p1] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 30, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_lock_irq(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 56, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 57, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 59, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 60, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 60, 3} true;
  $p2 := $M.11[$p1];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 60, 3} true;
  assume $p2 == 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 61, 3} true;
  $p3 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 61, 3} true;
  $M.11[$p3] := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 62, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 63, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_lock_irqsave(lock: int, value: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  call {:cexpr "value"} boogie_si_record_int(value);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 45, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 46, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 48, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 49, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 49, 3} true;
  $p2 := $M.10[$p1];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 49, 3} true;
  assume $p2 == 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 50, 3} true;
  $p3 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 50, 3} true;
  $M.10[$p3] := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 51, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 52, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_unlock(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 78, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 79, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 81, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 82, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 82, 3} true;
  $M.13[$p1] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 83, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 84, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_unlock_bh(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 108, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 109, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 111, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 112, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 112, 3} true;
  $M.16[$p1] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 113, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 114, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_unlock_irq(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 98, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 99, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 101, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 102, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 102, 3} true;
  $M.15[$p1] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 103, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 104, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_unlock_irqrestore(lock: int, value: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  call {:cexpr "value"} boogie_si_record_int(value);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 88, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 89, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 91, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 92, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 92, 3} true;
  $M.14[$p1] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 93, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 94, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} whoop$checker(pdev: int, ent: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17;
{
  var $p0: int;
$bb0:
  call {:cexpr "pdev"} boogie_si_record_int(pdev);
  call {:cexpr "ent"} boogie_si_record_int(ent);
  // WARNING: ignoring llvm.debug call.
  assume true;
  assume {:sourceloc "driver.re.c", 37, 8} true;
  call $p0 := alloc_testdev(4);
  call {:cexpr "dev"} boogie_si_record_int($p0);
  assume {:sourceloc "driver.re.c", 39, 2} true;
  call entrypoint($p0);
  assume {:sourceloc "driver.re.c", 40, 1} true;
  $exn := false;
  return;
}
axiom (__SMACK_nondet.XXX == -34);
axiom (_whoop_init == -5180);
axiom (_whoop_exit == -5188);
axiom $NULL == 0;
axiom $and(0,0) == 0;
axiom $and(0,1) == 0;
axiom $and(1,0) == 0;
axiom $and(1,1) == 1;
axiom $or(0,0) == 0;
axiom $or(0,1) == 1;
axiom $or(1,0) == 1;
axiom $or(1,1) == 1;
axiom $xor(0,0) == 0;
axiom $xor(0,1) == 1;
axiom $xor(1,0) == 1;
axiom $xor(1,1) == 0;
axiom (forall f1, f2: float :: f1 != f2 || $foeq(f1,f2));
axiom (forall f: float :: $si2fp($fp2si(f)) == f);
axiom (forall f: float :: $ui2fp($fp2ui(f)) == f);
axiom (forall i: int :: $fp2si($si2fp(i)) == i);
axiom (forall i: int :: $fp2ui($ui2fp(i)) == i);
const $GLOBALS_BOTTOM: int;
const $MOP: $mop;
const $UNDEF: int;
const unique $NULL: int;
function $and(p1:int, p2:int) returns (int);
function $ashr(p1:int, p2:int) returns (int);
function $base(int) returns (int);
function $extractvalue(p: int, i: int) returns (int);
function $fadd(f1:float, f2:float) returns (float);
function $fdiv(f1:float, f2:float) returns (float);
function $ffalse(f1:float, f2:float) returns (bool);
function $fmul(f1:float, f2:float) returns (float);
function $foeq(f1:float, f2:float) returns (bool);
function $foge(f1:float, f2:float) returns (bool);
function $fogt(f1:float, f2:float) returns (bool);
function $fole(f1:float, f2:float) returns (bool);
function $folt(f1:float, f2:float) returns (bool);
function $fone(f1:float, f2:float) returns (bool);
function $ford(f1:float, f2:float) returns (bool);
function $fp(ipart:int, fpart:int, epart:int) returns (float);
function $fp2si(f:float) returns (int);
function $fp2ui(f:float) returns (int);
function $frem(f1:float, f2:float) returns (float);
function $fsub(f1:float, f2:float) returns (float);
function $ftrue(f1:float, f2:float) returns (bool);
function $fueq(f1:float, f2:float) returns (bool);
function $fuge(f1:float, f2:float) returns (bool);
function $fugt(f1:float, f2:float) returns (bool);
function $fule(f1:float, f2:float) returns (bool);
function $fult(f1:float, f2:float) returns (bool);
function $fune(f1:float, f2:float) returns (bool);
function $funo(f1:float, f2:float) returns (bool);
function $lshr(p1:int, p2:int) returns (int);
function $nand(p1:int, p2:int) returns (int);
function $or(p1:int, p2:int) returns (int);
function $shl(p1:int, p2:int) returns (int);
function $si2fp(i:int) returns (float);
function $ui2fp(i:int) returns (float);
function $xor(p1:int, p2:int) returns (int);
function {:builtin "div"} $sdiv(p1:int, p2:int) returns (int);
function {:builtin "div"} $udiv(p1:int, p2:int) returns (int);
function {:builtin "rem"} $srem(p1:int, p2:int) returns (int);
function {:builtin "rem"} $urem(p1:int, p2:int) returns (int);
function {:inline} $add(p1:int, p2:int) returns (int) {p1 + p2}
function {:inline} $b2i(b: bool) returns (int) {if b then 1 else 0}
function {:inline} $b2p(b: bool) returns (int) {if b then 1 else 0}
function {:inline} $i2b(i: int) returns (bool) {i != 0}
function {:inline} $i2p(p: int) returns (int) {p}
function {:inline} $isExternal(p: int) returns (bool) { p < $GLOBALS_BOTTOM - 32768 }
function {:inline} $max(p1:int, p2:int) returns (int) {if p1 > p2 then p1 else p2}
function {:inline} $min(p1:int, p2:int) returns (int) {if p1 > p2 then p2 else p1}
function {:inline} $mul(p1:int, p2:int) returns (int) {p1 * p2}
function {:inline} $p2b(p: int) returns (bool) {p != 0}
function {:inline} $p2i(p: int) returns (int) {p}
function {:inline} $pa(pointer: int, index: int, size: int) returns (int) {pointer + index * size}
function {:inline} $sge(p1:int, p2:int) returns (bool) {p1 >= p2}
function {:inline} $sgt(p1:int, p2:int) returns (bool) {p1 > p2}
function {:inline} $sle(p1:int, p2:int) returns (bool) {p1 <= p2}
function {:inline} $slt(p1:int, p2:int) returns (bool) {p1 < p2}
function {:inline} $sub(p1:int, p2:int) returns (int) {p1 - p2}
function {:inline} $trunc(p: int, size: int) returns (int) {p}
function {:inline} $uge(p1:int, p2:int) returns (bool) {p1 >= p2}
function {:inline} $ugt(p1:int, p2:int) returns (bool) {p1 > p2}
function {:inline} $ule(p1:int, p2:int) returns (bool) {p1 <= p2}
function {:inline} $ult(p1:int, p2:int) returns (bool) {p1 < p2}
function {:inline} $umax(p1:int, p2:int) returns (int) {if p1 > p2 then p1 else p2}
function {:inline} $umin(p1:int, p2:int) returns (int) {if p1 > p2 then p2 else p1}
procedure {:inline 1} $alloca(n: int) returns (p: int)
modifies $CurrAddr, $Alloc;
{
  assume $CurrAddr > 0;
  p := $CurrAddr;
  if (n > 0) {
    $CurrAddr := $CurrAddr + n;
  } else {
    $CurrAddr := $CurrAddr + 1;
  }
  $Alloc[p] := true;
}
procedure {:inline 1} $free(p: int)
modifies $Alloc;
{
  $Alloc[p] := false;
}
procedure {:inline 1} $malloc(n: int) returns (p: int)
modifies $CurrAddr, $Alloc;
{
  assume $CurrAddr > 0;
  p := $CurrAddr;
  if (n > 0) {
    $CurrAddr := $CurrAddr + n;
  } else {
    $CurrAddr := $CurrAddr + 1;
  }
  $Alloc[p] := true;
}
procedure {:inline 1} boogie_si_record_bool(b: bool);
procedure {:inline 1} boogie_si_record_float(f: float);
procedure {:inline 1} boogie_si_record_int(i: int);
procedure {:inline 1} boogie_si_record_mop(m: $mop);
type $mop;
type float;
var $Alloc: [int] bool;
var $CurrAddr:int;
var $exn: bool;
var $exnv: int;

// END SMACK-GENERATED CODE
