// BEGIN SMACK-GENERATED CODE

// Memory region declarations: 55
var $M.0: [int] int;
var $M.1: int;
var $M.2: int;
var $M.3: [int] int;
var $M.4: [int] int;
var $M.5: [int] int;
var $M.6: [int] int;
var $M.7: int;
var $M.8: [int] int;
var $M.9: [int] int;
var $M.10: [int] int;
var $M.11: int;
var $M.12: int;
var $M.13: [int] int;
var $M.14: [int] int;
var $M.15: [int] int;
var $M.16: [int] int;
var $M.17: [int] int;
var $M.18: [int] int;
var $M.19: [int] int;
var $M.20: [int] int;
var $M.21: [int] int;
var $M.22: [int] int;
var $M.23: [int] int;
var $M.24: [int] int;
var $M.25: [int] int;
var $M.26: [int] int;
var $M.27: [int] int;
var $M.28: [int] int;
var $M.29: [int] int;
var $M.30: [int] int;
var $M.31: [int] int;
var $M.32: [int] int;
var $M.33: [int] int;
var $M.34: [int] int;
var $M.35: [int] int;
var $M.36: [int] int;
var $M.37: [int] int;
var $M.38: [int] int;
var $M.39: [int] int;
var $M.40: [int] int;
var $M.41: [int] int;
var $M.42: [int] int;
var $M.43: [int] int;
var $M.44: [int] int;
var $M.45: [int] int;
var $M.46: [int] int;
var $M.47: [int] int;
var $M.48: [int] int;
var $M.49: [int] int;
var $M.50: [int] int;
var $M.51: [int] int;
var $M.52: [int] int;
var $M.53: [int] int;
var $M.54: [int] int;

axiom $GLOBALS_BOTTOM == -5949;
const unique .str: int;
const unique .str1: int;
const unique .str10: int;
const unique .str100: int;
const unique .str101: int;
const unique .str102: int;
const unique .str103: int;
const unique .str104: int;
const unique .str105: int;
const unique .str106: int;
const unique .str107: int;
const unique .str108: int;
const unique .str109: int;
const unique .str11: int;
const unique .str110: int;
const unique .str111: int;
const unique .str112: int;
const unique .str113: int;
const unique .str114: int;
const unique .str115: int;
const unique .str116: int;
const unique .str117: int;
const unique .str118: int;
const unique .str119: int;
const unique .str12: int;
const unique .str120: int;
const unique .str13: int;
const unique .str14: int;
const unique .str15: int;
const unique .str16: int;
const unique .str17: int;
const unique .str18: int;
const unique .str19: int;
const unique .str2: int;
const unique .str20: int;
const unique .str21: int;
const unique .str22: int;
const unique .str23: int;
const unique .str24: int;
const unique .str25: int;
const unique .str26: int;
const unique .str27: int;
const unique .str28: int;
const unique .str29: int;
const unique .str3: int;
const unique .str30: int;
const unique .str31: int;
const unique .str32: int;
const unique .str33: int;
const unique .str34: int;
const unique .str35: int;
const unique .str36: int;
const unique .str37: int;
const unique .str38: int;
const unique .str39: int;
const unique .str4: int;
const unique .str40: int;
const unique .str41: int;
const unique .str42: int;
const unique .str43: int;
const unique .str44: int;
const unique .str45: int;
const unique .str46: int;
const unique .str47: int;
const unique .str48: int;
const unique .str49: int;
const unique .str5: int;
const unique .str50: int;
const unique .str51: int;
const unique .str52: int;
const unique .str53: int;
const unique .str54: int;
const unique .str55: int;
const unique .str56: int;
const unique .str57: int;
const unique .str58: int;
const unique .str59: int;
const unique .str6: int;
const unique .str60: int;
const unique .str61: int;
const unique .str62: int;
const unique .str63: int;
const unique .str64: int;
const unique .str65: int;
const unique .str66: int;
const unique .str67: int;
const unique .str68: int;
const unique .str69: int;
const unique .str7: int;
const unique .str70: int;
const unique .str71: int;
const unique .str72: int;
const unique .str73: int;
const unique .str74: int;
const unique .str75: int;
const unique .str76: int;
const unique .str77: int;
const unique .str78: int;
const unique .str79: int;
const unique .str8: int;
const unique .str80: int;
const unique .str81: int;
const unique .str82: int;
const unique .str83: int;
const unique .str84: int;
const unique .str85: int;
const unique .str86: int;
const unique .str87: int;
const unique .str88: int;
const unique .str89: int;
const unique .str9: int;
const unique .str90: int;
const unique .str91: int;
const unique .str92: int;
const unique .str93: int;
const unique .str94: int;
const unique .str95: int;
const unique .str96: int;
const unique .str97: int;
const unique .str98: int;
const unique .str99: int;
const unique MAJOR: int;
const unique MINOR: int;
const unique MKDEV: int;
const unique __SMACK_decls: int;
const unique __SMACK_nondet: int;
const unique __SMACK_nondet.XXX: int;
const unique _whoop_exit: int;
const unique _whoop_init: int;
const unique alloc_chrdev_region: int;
const unique alloc_testdev: int;
const unique assert_: int;
const unique assume_: int;
const unique cdev_add: int;
const unique cdev_del: int;
const unique cdev_init: int;
const unique copy_from_user: int;
const unique copy_to_user: int;
const unique current_fs_time3: int;
const unique current_kernel_time2: int;
const unique dev_dbg: int;
const unique dev_err: int;
const unique dev_info: int;
const unique device_select: int;
const unique gpio_shadow_lock: int;
const unique inb_p: int;
const unique ioread16: int;
const unique ioread32: int;
const unique ioread8: int;
const unique ioremap: int;
const unique jiffies: int;
const unique major: int;
const unique malloc: int;
const unique memcpy_fromio: int;
const unique mutex_init: int;
const unique mutex_lock: int;
const unique mutex_lock_interruptible: int;
const unique mutex_unlock: int;
const unique no_llseek: int;
const unique nonseekable_open: int;
const unique nsc_gpio_dump: int;
const unique nsc_gpio_read: int;
const unique nsc_gpio_write: int;
const unique outb_p: int;
const unique pc8736x_gpio_base: int;
const unique pc8736x_gpio_cdev: int;
const unique pc8736x_gpio_change: int;
const unique pc8736x_gpio_cleanup: int;
const unique pc8736x_gpio_config_lock: int;
const unique pc8736x_gpio_configure: int;
const unique pc8736x_gpio_current: int;
const unique pc8736x_gpio_fileops: int;
const unique pc8736x_gpio_get: int;
const unique pc8736x_gpio_init: int;
const unique pc8736x_gpio_open: int;
const unique pc8736x_gpio_ops: int;
const unique pc8736x_gpio_set: int;
const {:count 4} unique pc8736x_gpio_shadow: int;
const unique pc8736x_init_shadow: int;
const unique pc8736x_superio_present: int;
const unique pdev: int;
const unique platform_device_add: int;
const unique platform_device_alloc: int;
const unique platform_device_del: int;
const unique platform_device_put: int;
const unique platform_device_unregister: int;
const {:count 4} unique port_offset: int;
const unique readb: int;
const unique readl: int;
const unique readw: int;
const unique register_chrdev_region: int;
const unique release_region: int;
const unique request_region: int;
const unique select_pin: int;
const unique selected_device: int;
const unique spin_lock: int;
const unique spin_lock_bh: int;
const unique spin_lock_init: int;
const unique spin_lock_irq: int;
const unique spin_lock_irqsave: int;
const unique spin_unlock: int;
const unique spin_unlock_bh: int;
const unique spin_unlock_irq: int;
const unique spin_unlock_irqrestore: int;
const unique superio_cmd: int;
const unique timespec_trunc1: int;
const unique unregister_chrdev_region: int;
const unique usb_register: int;
const unique whoop$checker: int;
const unique writeb: int;
const unique writel: int;
const unique writew: int;
procedure {:inline 1} $static_init()
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  $M.1 := 0;
  $M.2 := 0;
  $M.3[$pa(port_offset, 0, 4)] := 0;
  $M.3[$pa(port_offset, 1, 4)] := 4;
  $M.3[$pa(port_offset, 2, 4)] := 8;
  $M.3[$pa(port_offset, 3, 4)] := 10;
  $M.4[pdev] := 0;
  $M.5[$pa(gpio_shadow_lock, 0, 1)] := 1;
  $M.5[$pa(gpio_shadow_lock, 4, 1)] := 0;
  $M.6[$pa(pc8736x_gpio_shadow, 0, 1)] := 0;
  $M.6[$pa(pc8736x_gpio_shadow, 1, 1)] := 0;
  $M.6[$pa(pc8736x_gpio_shadow, 2, 1)] := 0;
  $M.6[$pa(pc8736x_gpio_shadow, 3, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_ops, 0, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_ops, 8, 1)] := pc8736x_gpio_configure;
  $M.0[$pa(pc8736x_gpio_ops, 16, 1)] := nsc_gpio_dump;
  $M.0[$pa(pc8736x_gpio_ops, 24, 1)] := pc8736x_gpio_get;
  $M.0[$pa(pc8736x_gpio_ops, 32, 1)] := pc8736x_gpio_set;
  $M.0[$pa(pc8736x_gpio_ops, 40, 1)] := pc8736x_gpio_change;
  $M.0[$pa(pc8736x_gpio_ops, 48, 1)] := pc8736x_gpio_current;
  $M.0[$pa(pc8736x_gpio_ops, 56, 1)] := 0;
  $M.7 := 0;
  $M.0[$pa(pc8736x_gpio_cdev, 0, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_cdev, 8, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_cdev, 16, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_cdev, 20, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 0, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 8, 1)] := no_llseek;
  $M.0[$pa(pc8736x_gpio_fileops, 16, 1)] := nsc_gpio_read;
  $M.0[$pa(pc8736x_gpio_fileops, 24, 1)] := nsc_gpio_write;
  $M.0[$pa(pc8736x_gpio_fileops, 32, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 40, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 48, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 56, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 64, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 72, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 80, 1)] := pc8736x_gpio_open;
  $M.0[$pa(pc8736x_gpio_fileops, 88, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 96, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 104, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 112, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 120, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 128, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 136, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 144, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 152, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 160, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 168, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 176, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 184, 1)] := 0;
  $M.0[$pa(pc8736x_gpio_fileops, 192, 1)] := 0;
  $M.8[_whoop_init] := pc8736x_gpio_init;
  $M.9[_whoop_exit] := pc8736x_gpio_cleanup;
  $M.10[jiffies] := 0;
  $M.11 := 255;
  $M.12 := 0;
  $M.5[$pa(pc8736x_gpio_config_lock, 0, 1)] := 1;
  $M.5[$pa(pc8736x_gpio_config_lock, 4, 1)] := 0;
  return;
}
procedure MAJOR#0()
  returns ($r: int);
procedure MAJOR#1(p#0: int)
  returns ($r: int);
procedure MINOR#0()
  returns ($r: int);
procedure MINOR#1(p#0: int)
  returns ($r: int);
procedure MKDEV#0()
  returns ($r: int);
procedure MKDEV#2(p#0: int, p#1: int)
  returns ($r: int);
procedure {:inline 1} __SMACK_nondet()
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
$bb0:
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 53, 3} true;
  $p0 := $M.1;
  call {:cexpr "x"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 54, 3} true;
  havoc $p0;
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 55, 3} true;
  $r := $p0;
  $exn := false;
  return;
}
procedure {:inline 1} alloc_chrdev_region(p#0: int, p#1: int, p#2: int, p#3: int)
  returns ($r: int);
procedure {:inline 1} alloc_testdev(sizeof_priv: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
$bb0:
  call {:cexpr "sizeof_priv"} boogie_si_record_int(sizeof_priv);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 20, 51} true;
  $p0 := sizeof_priv;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 20, 51} true;
  call $p1 := $malloc($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 20, 51} true;
  $p2 := $p1;
  call {:cexpr "dev"} boogie_si_record_int($p2);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 21, 2} true;
  $r := $p2;
  $exn := false;
  return;
}
procedure {:inline 1} assert_(v: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
$bb0:
  call {:cexpr "v"} boogie_si_record_int(v);
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 37, 3} true;
  assert v != 0;
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 38, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} assume_(v: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
$bb0:
  call {:cexpr "v"} boogie_si_record_int(v);
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 41, 3} true;
  assume v != 0;
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 42, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} cdev_add(p#0: int, p#1: int, p#2: int)
  returns ($r: int);
procedure {:inline 1} cdev_del(p#0: int);
procedure {:inline 1} cdev_init(p#0: int, p#1: int);
procedure {:inline 1} copy_from_user(to: int, from: int, n: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "to"} boogie_si_record_int(to);
  call {:cexpr "from"} boogie_si_record_int(from);
  call {:cexpr "n"} boogie_si_record_int(n);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/uaccess.h", 29, 10} true;
  call $p0 := __SMACK_nondet();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/uaccess.h", 29, 10} true;
  $p1 := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/uaccess.h", 29, 10} true;
  $r := $p1;
  $exn := false;
  return;
}
procedure {:inline 1} copy_to_user(to: int, from: int, n: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "to"} boogie_si_record_int(to);
  call {:cexpr "from"} boogie_si_record_int(from);
  call {:cexpr "n"} boogie_si_record_int(n);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/uaccess.h", 24, 10} true;
  call $p0 := __SMACK_nondet();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/uaccess.h", 24, 10} true;
  $p1 := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/uaccess.h", 24, 10} true;
  $r := $p1;
  $exn := false;
  return;
}
procedure {:inline 1} current_fs_time3(ret: int, sb: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
  var $p10: int;
  var $p11: int;
  var $p12: int;
  var $p13: int;
  var $p14: int;
  var $p15: int;
  var $p16: int;
  var $p17: int;
  var $p18: int;
  var $p19: int;
  var $p2: int;
  var $p20: int;
  var $p21: int;
  var $p22: int;
  var $p23: int;
  var $p24: int;
  var $p25: int;
  var $p26: int;
  var $p27: int;
  var $p28: int;
  var $p29: int;
  var $p3: int;
  var $p30: int;
  var $p31: int;
  var $p32: int;
  var $p4: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;
  var $p8: int;
  var $p9: int;
$bb0:
  call $p0 := $alloca($mul(16, 1));
  call $p1 := $alloca($mul(16, 1));
  call {:cexpr "sb"} boogie_si_record_int(sb);
  // WARNING: ignoring llvm.debug call.
  assume true;
  call $p2 := $alloca($mul(16, 1));
  call $p3 := current_kernel_time2($p2);
  $p4 := $pa($pa($p2, 0, 16), 0, 1);
  $p5 := $M.0[$p4];
  $p6 := $pa($pa($p2, 0, 16), 8, 1);
  $p7 := $M.0[$p6];
  $p8 := $M.0[$p2];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 545, 25} true;
  $p9 := $p1;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 545, 25} true;
  $p10 := $pa($pa($p9, 0, 16), 0, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 545, 25} true;
  $M.52[$p10] := $p5;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 545, 25} true;
  $p11 := $pa($pa($p9, 0, 16), 8, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 545, 25} true;
  $M.52[$p11] := $p7;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p12 := $pa($pa(sb, 0, 304), 268, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p13 := $M.53[$p12];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p14 := $p1;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p15 := $pa($pa($p14, 0, 16), 0, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p16 := $M.52[$p15];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p17 := $pa($pa($p14, 0, 16), 8, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p18 := $M.52[$p17];
  call $p19 := $alloca($mul(16, 1));
  call $p20 := timespec_trunc1($p19, $p16, $p18, $p13);
  $p21 := $pa($pa($p19, 0, 16), 0, 1);
  $p22 := $M.0[$p21];
  $p23 := $pa($pa($p19, 0, 16), 8, 1);
  $p24 := $M.0[$p23];
  $p25 := $M.0[$p19];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p26 := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p27 := $pa($pa($p26, 0, 16), 0, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $M.51[$p27] := $p22;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p28 := $pa($pa($p26, 0, 16), 8, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $M.51[$p28] := $p24;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p29 := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p30 := $M.51[$p29];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p31 := ret;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p32 := $p29;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  call $memcpy.51.51($p31, $p32, 16, 8, false);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $r := $p30;
  $exn := false;
  return;
}
procedure {:inline 1} current_kernel_time2(ret: int)
  returns ($r: int);
procedure dev_dbg#0()
  returns ($r: int);
procedure dev_dbg#2(p#0: int, p#1: int)
  returns ($r: int);
procedure dev_dbg#3(p#0: int, p#1: int, p#2: int)
  returns ($r: int);
procedure dev_dbg#4(p#0: int, p#1: int, p#2: int, p#3: int)
  returns ($r: int);
procedure dev_dbg#6(p#0: int, p#1: int, p#2: int, p#3: int, p#4: int, p#5: int)
  returns ($r: int);
procedure dev_dbg#7(p#0: int, p#1: int, p#2: int, p#3: int, p#4: int, p#5: int, p#6: int)
  returns ($r: int);
procedure dev_dbg#8(p#0: int, p#1: int, p#2: int, p#3: int, p#4: int, p#5: int, p#6: int, p#7: int)
  returns ($r: int);
procedure dev_err#0()
  returns ($r: int);
procedure dev_err#2(p#0: int, p#1: int)
  returns ($r: int);
procedure dev_err#3(p#0: int, p#1: int, p#2: int)
  returns ($r: int);
procedure dev_info#0()
  returns ($r: int);
procedure dev_info#2(p#0: int, p#1: int)
  returns ($r: int);
procedure dev_info#3(p#0: int, p#1: int, p#2: int)
  returns ($r: int);
procedure {:inline 1} device_select(devldn: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
  var $p4: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;
$bb0:
  call {:cexpr "devldn"} boogie_si_record_int(devldn);
  call {:cexpr "addr"} boogie_si_record_int(7);
  call {:cexpr "val"} boogie_si_record_int(devldn);
  assume {:sourceloc "driver.re.c", 85, 2} true;
  $p0 := $trunc(7, 8);
  assume {:sourceloc "driver.re.c", 85, 2} true;
  $p1 := $M.12;
  assume {:sourceloc "driver.re.c", 85, 2} true;
  $p2 := $p1;
  assume {:sourceloc "driver.re.c", 85, 2} true;
  call outb_p($p0, $p2);
  assume {:sourceloc "driver.re.c", 86, 2} true;
  $p3 := $trunc(devldn, 8);
  assume {:sourceloc "driver.re.c", 86, 2} true;
  $p4 := $M.12;
  assume {:sourceloc "driver.re.c", 86, 2} true;
  $p5 := $p4;
  assume {:sourceloc "driver.re.c", 86, 2} true;
  $p6 := $add($p5, 1);
  assume {:sourceloc "driver.re.c", 86, 2} true;
  call outb_p($p3, $p6);
  assume {:sourceloc "driver.re.c", 116, 2} true;
  $p7 := $trunc(devldn, 8);
  assume {:sourceloc "driver.re.c", 116, 2} true;
  $M.11 := $p7;
  call {:cexpr "selected_device"} boogie_si_record_int($p7);
  assume {:sourceloc "driver.re.c", 117, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} inb_p(p#0: int)
  returns ($r: int);
procedure {:inline 1} ioread16(addr: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "addr"} boogie_si_record_int(addr);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 77, 9} true;
  call $p0 := readw(addr);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 77, 9} true;
  $p1 := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 77, 9} true;
  $r := $p1;
  $exn := false;
  return;
}
procedure {:inline 1} ioread32(addr: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
$bb0:
  call {:cexpr "addr"} boogie_si_record_int(addr);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 82, 9} true;
  call $p0 := readl(addr);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 82, 9} true;
  $r := $p0;
  $exn := false;
  return;
}
procedure {:inline 1} ioread8(addr: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "addr"} boogie_si_record_int(addr);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 72, 9} true;
  call $p0 := readb(addr);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 72, 9} true;
  $p1 := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 72, 9} true;
  $r := $p1;
  $exn := false;
  return;
}
procedure {:inline 1} ioremap(offset: int, size: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
$bb0:
  call {:cexpr "offset"} boogie_si_record_int(offset);
  call {:cexpr "size"} boogie_si_record_int(size);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 10, 26} true;
  call $p0 := $malloc(size);
  call {:cexpr "memory"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 11, 2} true;
  $r := $p0;
  $exn := false;
  return;
}
procedure {:inline 1} memcpy_fromio(dst: int, src: int, count: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
$bb0:
  call {:cexpr "dst"} boogie_si_record_int(dst);
  call {:cexpr "src"} boogie_si_record_int(src);
  call {:cexpr "count"} boogie_si_record_int(count);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 110, 2} true;
  call $memcpy.54.54(dst, src, count, 1, false);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 111, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} mutex_init(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 29, 2} true;
  $p0 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 29, 2} true;
  $M.22[$p0] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 30, 2} true;
  $p1 := $pa($pa(lock, 0, 8), 0, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 30, 2} true;
  $M.22[$p1] := 1;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 31, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} mutex_lock(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 35, 12} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 36, 2} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 38, 2} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 39, 2} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 39, 2} true;
  $p2 := $M.5[$p1];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 39, 2} true;
  assume $p2 == 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 40, 2} true;
  $p3 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 40, 2} true;
  $M.5[$p3] := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 41, 2} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 42, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} mutex_lock_interruptible(lock: int)
  returns ($r: bool)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $b1: bool;
  var $b3: bool;
  var $b8: bool;
  var $p0: int;
  var $p2: int;
  var $p4: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 46, 19} true;
  call $p0 := __SMACK_nondet();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 46, 19} true;
  $b1 := ($p0 != 0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 46, 19} true;
  $p2 := $b2p($b1);
  call {:cexpr "ret"} boogie_si_record_int($p2);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 47, 5} true;
  $b3 := $i2b($p2);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 47, 5} true;
  goto $bb1, $bb3;
$bb1:
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 47, 5} true;
  assume $b3;
  goto $bb2;
$bb2:
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 56, 2} true;
  $b8 := $i2b($p2);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 56, 2} true;
  $r := $b8;
  $exn := false;
  return;
$bb3:
  assume !($b3);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 48, 13} true;
  call $p4 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p4);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 49, 3} true;
  call $p4 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 51, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 52, 3} true;
  $p5 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 52, 3} true;
  $p6 := $M.23[$p5];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 52, 3} true;
  assume $p6 == 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 53, 3} true;
  $p7 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 53, 3} true;
  $M.23[$p7] := $p4;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 54, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 55, 2} true;
  goto $bb2;
}
procedure {:inline 1} mutex_unlock(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 61, 12} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 62, 2} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 64, 2} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 65, 2} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 65, 2} true;
  $M.5[$p1] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 66, 2} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 67, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} no_llseek(p#0: int, p#1: int, p#2: int)
  returns ($r: int);
procedure {:inline 1} nonseekable_open(p#0: int, p#1: int)
  returns ($r: int);
procedure {:inline 1} nsc_gpio_dump(p#0: int, p#1: int);
procedure {:inline 1} nsc_gpio_read(p#0: int, p#1: int, p#2: int, p#3: int)
  returns ($r: int);
procedure {:inline 1} nsc_gpio_write(p#0: int, p#1: int, p#2: int, p#3: int)
  returns ($r: int);
procedure {:inline 1} outb_p(p#0: int, p#1: int);
procedure pc8736x_gpio_change(index: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $b1: bool;
  var $b2: bool;
  var $p0: int;
  var $p3: int;
$bb0:
  call {:cexpr "index"} boogie_si_record_int(index);
  assume {:sourceloc "driver.re.c", 215, 27} true;
  call $p0 := pc8736x_gpio_current(index);
  assume {:sourceloc "driver.re.c", 215, 27} true;
  $b1 := ($p0 != 0);
  assume {:sourceloc "driver.re.c", 215, 27} true;
  $b2 := $i2b($xor($b2i($b1), $b2i(true)));
  assume {:sourceloc "driver.re.c", 215, 27} true;
  $p3 := $b2p($b2);
  assume {:sourceloc "driver.re.c", 215, 2} true;
  call pc8736x_gpio_set(index, $p3);
  assume {:sourceloc "driver.re.c", 216, 1} true;
  $exn := false;
  return;
}
procedure pc8736x_gpio_cleanup()
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
  var $p4: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;
  var $p8: int;
$bb0:
  assume {:sourceloc "driver.re.c", 350, 2} true;
  $p0 := $M.4[pdev];
  assume {:sourceloc "driver.re.c", 350, 2} true;
  $p1 := $pa($pa($p0, 0, 168), 16, 1);
  assume {:sourceloc "driver.re.c", 350, 2} true;
  call $p2 := dev_dbg#2($p1, $pa($pa(.str119, 0, 9), 0, 1));
  assume {:sourceloc "driver.re.c", 352, 2} true;
  call cdev_del(pc8736x_gpio_cdev);
  assume {:sourceloc "driver.re.c", 353, 27} true;
  $p3 := $M.7;
  assume {:sourceloc "driver.re.c", 353, 27} true;
  call $p4 := MKDEV#2($p3, 0);
  assume {:sourceloc "driver.re.c", 353, 2} true;
  call unregister_chrdev_region($p4, 32);
  assume {:sourceloc "driver.re.c", 354, 2} true;
  $p5 := $M.2;
  assume {:sourceloc "driver.re.c", 354, 2} true;
  call $p6 := release_region#2($p5, 16);
  assume {:sourceloc "driver.re.c", 356, 2} true;
  $p7 := $M.4[pdev];
  assume {:sourceloc "driver.re.c", 356, 2} true;
  call $p8 := platform_device_unregister#1($p7);
  assume {:sourceloc "driver.re.c", 357, 1} true;
  $exn := false;
  return;
}
procedure pc8736x_gpio_configure(index: int, mask: int, bits: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
  var $p10: int;
  var $p11: int;
  var $p12: int;
  var $p13: int;
  var $p14: int;
  var $p15: int;
  var $p16: int;
  var $p2: int;
  var $p3: int;
  var $p4: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;
  var $p8: int;
  var $p9: int;
$bb0:
  call {:cexpr "index"} boogie_si_record_int(index);
  call {:cexpr "mask"} boogie_si_record_int(mask);
  call {:cexpr "bits"} boogie_si_record_int(bits);
  call {:cexpr "index"} boogie_si_record_int(index);
  call {:cexpr "mask"} boogie_si_record_int(mask);
  call {:cexpr "bits"} boogie_si_record_int(bits);
  call {:cexpr "func_slct"} boogie_si_record_int(241);
  assume {:sourceloc "driver.re.c", 132, 2} true;
  call mutex_lock(pc8736x_gpio_config_lock);
  assume {:sourceloc "driver.re.c", 134, 2} true;
  call device_select(7);
  assume {:sourceloc "driver.re.c", 135, 2} true;
  call select_pin(index);
  call {:cexpr "addr"} boogie_si_record_int(241);
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p0 := $trunc(241, 8);
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p1 := $M.12;
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p2 := $p1;
  assume {:sourceloc "driver.re.c", 91, 2} true;
  call outb_p($p0, $p2);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p3 := $M.12;
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p4 := $p3;
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p5 := $add($p4, 1);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  call $p6 := inb_p($p5);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p7 := $p6;
  call {:cexpr "config"} boogie_si_record_int($p7);
  assume {:sourceloc "driver.re.c", 141, 2} true;
  $p8 := $and($p7, mask);
  assume {:sourceloc "driver.re.c", 141, 2} true;
  $p9 := $or($p8, bits);
  call {:cexpr "new_config"} boogie_si_record_int($p9);
  call {:cexpr "addr"} boogie_si_record_int(241);
  call {:cexpr "val"} boogie_si_record_int($p9);
  assume {:sourceloc "driver.re.c", 85, 2} true;
  $p10 := $trunc(241, 8);
  assume {:sourceloc "driver.re.c", 85, 2} true;
  $p11 := $M.12;
  assume {:sourceloc "driver.re.c", 85, 2} true;
  $p12 := $p11;
  assume {:sourceloc "driver.re.c", 85, 2} true;
  call outb_p($p10, $p12);
  assume {:sourceloc "driver.re.c", 86, 2} true;
  $p13 := $trunc($p9, 8);
  assume {:sourceloc "driver.re.c", 86, 2} true;
  $p14 := $M.12;
  assume {:sourceloc "driver.re.c", 86, 2} true;
  $p15 := $p14;
  assume {:sourceloc "driver.re.c", 86, 2} true;
  $p16 := $add($p15, 1);
  assume {:sourceloc "driver.re.c", 86, 2} true;
  call outb_p($p13, $p16);
  assume {:sourceloc "driver.re.c", 144, 2} true;
  call mutex_unlock(pc8736x_gpio_config_lock);
  assume {:sourceloc "driver.re.c", 151, 9} true;
  $r := $p7;
  $exn := false;
  return;
}
procedure pc8736x_gpio_current(minor: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
  var $p4: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;
  var $p8: int;
$bb0:
  call {:cexpr "minor"} boogie_si_record_int(minor);
  assume {:sourceloc "driver.re.c", 204, 2} true;
  $p0 := $and(minor, 31);
  call {:cexpr "minor"} boogie_si_record_int($p0);
  assume {:sourceloc "driver.re.c", 205, 2} true;
  $p1 := $lshr($p0, 3);
  call {:cexpr "port"} boogie_si_record_int($p1);
  assume {:sourceloc "driver.re.c", 206, 2} true;
  $p2 := $and($p0, 7);
  call {:cexpr "bit"} boogie_si_record_int($p2);
  assume {:sourceloc "driver.re.c", 207, 2} true;
  call mutex_lock(gpio_shadow_lock);
  assume {:sourceloc "driver.re.c", 208, 2} true;
  $p3 := $p1;
  assume {:sourceloc "driver.re.c", 208, 2} true;
  $p4 := $pa($pa(pc8736x_gpio_shadow, 0, 4), $p3, 1);
  assume {:sourceloc "driver.re.c", 208, 2} true;
  $p5 := $M.6[$p4];
  assume {:sourceloc "driver.re.c", 208, 2} true;
  $p6 := $p5;
  assume {:sourceloc "driver.re.c", 208, 2} true;
  $p7 := $ashr($p6, $p2);
  assume {:sourceloc "driver.re.c", 208, 2} true;
  $p8 := $and($p7, 1);
  call {:cexpr "value"} boogie_si_record_int($p8);
  assume {:sourceloc "driver.re.c", 209, 2} true;
  call mutex_unlock(gpio_shadow_lock);
  assume {:sourceloc "driver.re.c", 210, 2} true;
  $r := $p8;
  $exn := false;
  return;
}
procedure pc8736x_gpio_get(minor: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
  var $p10: int;
  var $p11: int;
  var $p12: int;
  var $p13: int;
  var $p14: int;
  var $p15: int;
  var $p16: int;
  var $p17: int;
  var $p18: int;
  var $p19: int;
  var $p2: int;
  var $p20: int;
  var $p3: int;
  var $p4: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;
  var $p8: int;
  var $p9: int;
$bb0:
  call {:cexpr "minor"} boogie_si_record_int(minor);
  assume {:sourceloc "driver.re.c", 159, 2} true;
  $p0 := $lshr(minor, 3);
  call {:cexpr "port"} boogie_si_record_int($p0);
  assume {:sourceloc "driver.re.c", 160, 2} true;
  $p1 := $and(minor, 7);
  call {:cexpr "bit"} boogie_si_record_int($p1);
  assume {:sourceloc "driver.re.c", 161, 8} true;
  $p2 := $M.2;
  assume {:sourceloc "driver.re.c", 161, 8} true;
  $p3 := $p0;
  assume {:sourceloc "driver.re.c", 161, 8} true;
  $p4 := $pa($pa(port_offset, 0, 16), $p3, 4);
  assume {:sourceloc "driver.re.c", 161, 8} true;
  $p5 := $M.3[$p4];
  assume {:sourceloc "driver.re.c", 161, 8} true;
  $p6 := $add($p2, $p5);
  assume {:sourceloc "driver.re.c", 161, 8} true;
  $p7 := $add($p6, 1);
  assume {:sourceloc "driver.re.c", 161, 8} true;
  call $p8 := inb_p($p7);
  assume {:sourceloc "driver.re.c", 161, 8} true;
  $p9 := $p8;
  call {:cexpr "val"} boogie_si_record_int($p9);
  assume {:sourceloc "driver.re.c", 162, 2} true;
  $p10 := $ashr($p9, $p1);
  call {:cexpr "val"} boogie_si_record_int($p10);
  assume {:sourceloc "driver.re.c", 163, 2} true;
  $p11 := $and($p10, 1);
  call {:cexpr "val"} boogie_si_record_int($p11);
  assume {:sourceloc "driver.re.c", 165, 2} true;
  $p12 := $M.4[pdev];
  assume {:sourceloc "driver.re.c", 165, 2} true;
  $p13 := $pa($pa($p12, 0, 168), 16, 1);
  assume {:sourceloc "driver.re.c", 165, 2} true;
  $p14 := $M.2;
  assume {:sourceloc "driver.re.c", 165, 2} true;
  $p15 := $p0;
  assume {:sourceloc "driver.re.c", 165, 2} true;
  $p16 := $pa($pa(port_offset, 0, 16), $p15, 4);
  assume {:sourceloc "driver.re.c", 165, 2} true;
  $p17 := $M.3[$p16];
  assume {:sourceloc "driver.re.c", 165, 2} true;
  $p18 := $add($p14, $p17);
  assume {:sourceloc "driver.re.c", 165, 2} true;
  $p19 := $add($p18, 1);
  assume {:sourceloc "driver.re.c", 165, 2} true;
  call $p20 := dev_dbg#6($p13, $pa($pa(.str105, 0, 40), 0, 1), minor, $p19, $p1, $p11);
  assume {:sourceloc "driver.re.c", 169, 2} true;
  $r := $p11;
  $exn := false;
  return;
}
procedure pc8736x_gpio_init()
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $b15: bool;
  var $b31: bool;
  var $b43: bool;
  var $b5: bool;
  var $b67: bool;
  var $b77: bool;
  var $b86: bool;
  var $b9: bool;
  var $b93: bool;
  var $p0: int;
  var $p1: int;
  var $p10: int;
  var $p100: int;
  var $p101: int;
  var $p102: int;
  var $p103: int;
  var $p11: int;
  var $p12: int;
  var $p13: int;
  var $p14: int;
  var $p16: int;
  var $p17: int;
  var $p18: int;
  var $p19: int;
  var $p2: int;
  var $p20: int;
  var $p21: int;
  var $p22: int;
  var $p23: int;
  var $p24: int;
  var $p25: int;
  var $p26: int;
  var $p27: int;
  var $p28: int;
  var $p29: int;
  var $p3: int;
  var $p30: int;
  var $p32: int;
  var $p33: int;
  var $p34: int;
  var $p35: int;
  var $p36: int;
  var $p37: int;
  var $p38: int;
  var $p39: int;
  var $p4: int;
  var $p40: int;
  var $p41: int;
  var $p42: int;
  var $p44: int;
  var $p45: int;
  var $p46: int;
  var $p47: int;
  var $p48: int;
  var $p49: int;
  var $p50: int;
  var $p51: int;
  var $p52: int;
  var $p53: int;
  var $p54: int;
  var $p55: int;
  var $p56: int;
  var $p57: int;
  var $p58: int;
  var $p59: int;
  var $p6: int;
  var $p60: int;
  var $p61: int;
  var $p62: int;
  var $p63: int;
  var $p64: int;
  var $p65: int;
  var $p66: int;
  var $p68: int;
  var $p69: int;
  var $p7: int;
  var $p70: int;
  var $p71: int;
  var $p72: int;
  var $p73: int;
  var $p74: int;
  var $p75: int;
  var $p76: int;
  var $p78: int;
  var $p79: int;
  var $p8: int;
  var $p80: int;
  var $p81: int;
  var $p82: int;
  var $p83: int;
  var $p84: int;
  var $p85: int;
  var $p87: int;
  var $p88: int;
  var $p89: int;
  var $p90: int;
  var $p91: int;
  var $p92: int;
  var $p94: int;
  var $p95: int;
  var $p96: int;
  var $p97: int;
  var $p98: int;
  var $p99: int;
$bb0:
  call $p0 := $alloca($mul(4, 1));
  // WARNING: ignoring llvm.debug call.
  assume true;
  assume {:sourceloc "driver.re.c", 267, 9} true;
  call $p1 := platform_device_alloc#2($pa($pa(.str110, 0, 13), 0, 1), 0);
  assume {:sourceloc "driver.re.c", 267, 9} true;
  $p2 := $p1;
  assume {:sourceloc "driver.re.c", 267, 9} true;
  $p3 := $i2p($p2);
  assume {:sourceloc "driver.re.c", 267, 9} true;
  $M.4[pdev] := $p3;
  call {:cexpr "pdev"} boogie_si_record_int($p3);
  assume {:sourceloc "driver.re.c", 268, 6} true;
  $p4 := $M.4[pdev];
  assume {:sourceloc "driver.re.c", 268, 6} true;
  $b5 := ($p4 != 0);
  assume {:sourceloc "driver.re.c", 268, 6} true;
  goto $bb1, $bb2;
$bb1:
  assume $b5;
  assume {:sourceloc "driver.re.c", 271, 7} true;
  $p7 := $M.4[pdev];
  assume {:sourceloc "driver.re.c", 271, 7} true;
  call $p8 := platform_device_add#1($p7);
  call {:cexpr "rc"} boogie_si_record_int($p8);
  assume {:sourceloc "driver.re.c", 272, 6} true;
  $b9 := ($p8 != 0);
  assume {:sourceloc "driver.re.c", 272, 6} true;
  goto $bb4, $bb5;
$bb2:
  assume !($b5);
  assume {:sourceloc "driver.re.c", 269, 3} true;
  $p6 := -12;
  goto $bb3;
$bb3:
  assume {:sourceloc "driver.re.c", 346, 1} true;
  $r := $p6;
  $exn := false;
  return;
$bb4:
  assume $b9;
  call {:cexpr "rc"} boogie_si_record_int(-19);
  assume {:sourceloc "driver.re.c", 274, 3} true;
  $p10 := -19;
  goto $bb6;
$bb5:
  assume !($b9);
  assume {:sourceloc "driver.re.c", 276, 2} true;
  $p11 := $M.4[pdev];
  assume {:sourceloc "driver.re.c", 276, 2} true;
  $p12 := $pa($pa($p11, 0, 168), 16, 1);
  assume {:sourceloc "driver.re.c", 276, 2} true;
  call $p13 := dev_info#2($p12, $pa($pa(.str111, 0, 42), 0, 1));
  assume {:sourceloc "driver.re.c", 278, 7} true;
  call $p14 := pc8736x_superio_present();
  assume {:sourceloc "driver.re.c", 278, 7} true;
  $b15 := ($p14 != 0);
  assume {:sourceloc "driver.re.c", 278, 7} true;
  goto $bb7, $bb8;
$bb6:
  assume {:sourceloc "driver.re.c", 343, 2} true;
  $p102 := $M.4[pdev];
  assume {:sourceloc "driver.re.c", 343, 2} true;
  call $p103 := platform_device_put#1($p102);
  assume {:sourceloc "driver.re.c", 345, 2} true;
  $p6 := $p10;
  goto $bb3;
$bb7:
  assume $b15;
  assume {:sourceloc "driver.re.c", 283, 2} true;
  $p20 := $M.4[pdev];
  assume {:sourceloc "driver.re.c", 283, 2} true;
  $p21 := $pa($pa($p20, 0, 168), 16, 1);
  assume {:sourceloc "driver.re.c", 283, 2} true;
  $M.0[$pa($pa(pc8736x_gpio_ops, 0, 64), 56, 1)] := $p21;
  call {:cexpr "addr"} boogie_si_record_int(33);
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p22 := $trunc(33, 8);
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p23 := $M.12;
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p24 := $p23;
  assume {:sourceloc "driver.re.c", 91, 2} true;
  call outb_p($p22, $p24);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p25 := $M.12;
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p26 := $p25;
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p27 := $add($p26, 1);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  call $p28 := inb_p($p27);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p29 := $p28;
  call {:cexpr "rc"} boogie_si_record_int($p29);
  assume {:sourceloc "driver.re.c", 289, 6} true;
  $p30 := $and($p29, 1);
  assume {:sourceloc "driver.re.c", 289, 6} true;
  $b31 := ($p30 != 0);
  assume {:sourceloc "driver.re.c", 289, 6} true;
  goto $bb10, $bb11;
$bb8:
  assume !($b15);
  call {:cexpr "rc"} boogie_si_record_int(-19);
  assume {:sourceloc "driver.re.c", 280, 3} true;
  $p16 := $M.4[pdev];
  assume {:sourceloc "driver.re.c", 280, 3} true;
  $p17 := $pa($pa($p16, 0, 168), 16, 1);
  assume {:sourceloc "driver.re.c", 280, 3} true;
  call $p18 := dev_err#2($p17, $pa($pa(.str112, 0, 17), 0, 1));
  assume {:sourceloc "driver.re.c", 281, 3} true;
  $p19 := -19;
  goto $bb9;
$bb9:
  assume {:sourceloc "driver.re.c", 341, 2} true;
  $p100 := $M.4[pdev];
  assume {:sourceloc "driver.re.c", 341, 2} true;
  call $p101 := platform_device_del#1($p100);
  assume {:sourceloc "driver.re.c", 341, 2} true;
  $p10 := $p19;
  goto $bb6;
$bb10:
  assume $b31;
  assume {:sourceloc "driver.re.c", 294, 2} true;
  call device_select(7);
  call {:cexpr "addr"} boogie_si_record_int(48);
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p35 := $trunc(48, 8);
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p36 := $M.12;
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p37 := $p36;
  assume {:sourceloc "driver.re.c", 91, 2} true;
  call outb_p($p35, $p37);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p38 := $M.12;
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p39 := $p38;
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p40 := $add($p39, 1);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  call $p41 := inb_p($p40);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p42 := $p41;
  assume {:sourceloc "driver.re.c", 295, 7} true;
  $b43 := ($p42 != 0);
  assume {:sourceloc "driver.re.c", 295, 7} true;
  goto $bb12, $bb13;
$bb11:
  assume !($b31);
  call {:cexpr "rc"} boogie_si_record_int(-19);
  assume {:sourceloc "driver.re.c", 291, 3} true;
  $p32 := $M.4[pdev];
  assume {:sourceloc "driver.re.c", 291, 3} true;
  $p33 := $pa($pa($p32, 0, 168), 16, 1);
  assume {:sourceloc "driver.re.c", 291, 3} true;
  call $p34 := dev_err#2($p33, $pa($pa(.str113, 0, 20), 0, 1));
  assume {:sourceloc "driver.re.c", 292, 3} true;
  $p19 := -19;
  goto $bb9;
$bb12:
  assume $b43;
  call {:cexpr "addr"} boogie_si_record_int(96);
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p47 := $trunc(96, 8);
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p48 := $M.12;
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p49 := $p48;
  assume {:sourceloc "driver.re.c", 91, 2} true;
  call outb_p($p47, $p49);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p50 := $M.12;
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p51 := $p50;
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p52 := $add($p51, 1);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  call $p53 := inb_p($p52);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p54 := $p53;
  assume {:sourceloc "driver.re.c", 302, 23} true;
  $p55 := $shl($p54, 8);
  call {:cexpr "addr"} boogie_si_record_int(97);
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p56 := $trunc(97, 8);
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p57 := $M.12;
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p58 := $p57;
  assume {:sourceloc "driver.re.c", 91, 2} true;
  call outb_p($p56, $p58);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p59 := $M.12;
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p60 := $p59;
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p61 := $add($p60, 1);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  call $p62 := inb_p($p61);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p63 := $p62;
  assume {:sourceloc "driver.re.c", 303, 11} true;
  $p64 := $or($p55, $p63);
  assume {:sourceloc "driver.re.c", 303, 11} true;
  $M.2 := $p64;
  call {:cexpr "pc8736x_gpio_base"} boogie_si_record_int($p64);
  assume {:sourceloc "driver.re.c", 305, 7} true;
  $p65 := $M.2;
  assume {:sourceloc "driver.re.c", 305, 7} true;
  call $p66 := request_region#3($p65, 16, $pa($pa(.str110, 0, 13), 0, 1));
  assume {:sourceloc "driver.re.c", 305, 7} true;
  $b67 := ($p66 != 0);
  assume {:sourceloc "driver.re.c", 305, 7} true;
  goto $bb14, $bb15;
$bb13:
  assume !($b43);
  call {:cexpr "rc"} boogie_si_record_int(-19);
  assume {:sourceloc "driver.re.c", 297, 3} true;
  $p44 := $M.4[pdev];
  assume {:sourceloc "driver.re.c", 297, 3} true;
  $p45 := $pa($pa($p44, 0, 168), 16, 1);
  assume {:sourceloc "driver.re.c", 297, 3} true;
  call $p46 := dev_err#2($p45, $pa($pa(.str114, 0, 23), 0, 1));
  assume {:sourceloc "driver.re.c", 298, 3} true;
  $p19 := -19;
  goto $bb9;
$bb14:
  assume $b67;
  assume {:sourceloc "driver.re.c", 311, 2} true;
  $p72 := $M.4[pdev];
  assume {:sourceloc "driver.re.c", 311, 2} true;
  $p73 := $pa($pa($p72, 0, 168), 16, 1);
  assume {:sourceloc "driver.re.c", 311, 2} true;
  $p74 := $M.2;
  assume {:sourceloc "driver.re.c", 311, 2} true;
  call $p75 := dev_info#3($p73, $pa($pa(.str116, 0, 25), 0, 1), $p74);
  assume {:sourceloc "driver.re.c", 313, 6} true;
  $p76 := $M.7;
  assume {:sourceloc "driver.re.c", 313, 6} true;
  $b77 := ($p76 != 0);
  assume {:sourceloc "driver.re.c", 313, 6} true;
  goto $bb16, $bb17;
$bb15:
  assume !($b67);
  call {:cexpr "rc"} boogie_si_record_int(-19);
  assume {:sourceloc "driver.re.c", 307, 3} true;
  $p68 := $M.4[pdev];
  assume {:sourceloc "driver.re.c", 307, 3} true;
  $p69 := $pa($pa($p68, 0, 168), 16, 1);
  assume {:sourceloc "driver.re.c", 307, 3} true;
  $p70 := $M.2;
  assume {:sourceloc "driver.re.c", 307, 3} true;
  call $p71 := dev_err#3($p69, $pa($pa(.str115, 0, 21), 0, 1), $p70);
  assume {:sourceloc "driver.re.c", 309, 3} true;
  $p19 := -19;
  goto $bb9;
$bb16:
  assume $b77;
  assume {:sourceloc "driver.re.c", 314, 11} true;
  $p78 := $M.7;
  assume {:sourceloc "driver.re.c", 314, 11} true;
  call $p79 := MKDEV#2($p78, 0);
  assume {:sourceloc "driver.re.c", 314, 11} true;
  $M.0[$p0] := $p79;
  assume {:sourceloc "driver.re.c", 315, 8} true;
  $p80 := $M.0[$p0];
  assume {:sourceloc "driver.re.c", 315, 8} true;
  call $p81 := register_chrdev_region($p80, 32, $pa($pa(.str110, 0, 13), 0, 1));
  call {:cexpr "rc"} boogie_si_record_int($p81);
  assume {:sourceloc "driver.re.c", 316, 2} true;
  $p82 := $p81;
  goto $bb18;
$bb17:
  assume !($b77);
  assume {:sourceloc "driver.re.c", 317, 8} true;
  call $p83 := alloc_chrdev_region($p0, 0, 32, $pa($pa(.str110, 0, 13), 0, 1));
  call {:cexpr "rc"} boogie_si_record_int($p83);
  assume {:sourceloc "driver.re.c", 318, 11} true;
  $p84 := $M.0[$p0];
  assume {:sourceloc "driver.re.c", 318, 11} true;
  call $p85 := MAJOR#1($p84);
  assume {:sourceloc "driver.re.c", 318, 11} true;
  $M.7 := $p85;
  call {:cexpr "major"} boogie_si_record_int($p85);
  $p82 := $p83;
  goto $bb18;
$bb18:
  assume {:sourceloc "driver.re.c", 321, 6} true;
  $b86 := $slt($p82, 0);
  assume {:sourceloc "driver.re.c", 321, 6} true;
  goto $bb19, $bb20;
$bb19:
  assume $b86;
  assume {:sourceloc "driver.re.c", 322, 3} true;
  $p87 := $M.4[pdev];
  assume {:sourceloc "driver.re.c", 322, 3} true;
  $p88 := $pa($pa($p87, 0, 168), 16, 1);
  assume {:sourceloc "driver.re.c", 322, 3} true;
  call $p89 := dev_err#3($p88, $pa($pa(.str117, 0, 28), 0, 1), $p82);
  assume {:sourceloc "driver.re.c", 339, 2} true;
  $p90 := $M.2;
  assume {:sourceloc "driver.re.c", 339, 2} true;
  call $p91 := release_region#2($p90, 16);
  assume {:sourceloc "driver.re.c", 339, 2} true;
  $p19 := $p82;
  goto $bb9;
$bb20:
  assume !($b86);
  assume {:sourceloc "driver.re.c", 325, 6} true;
  $p92 := $M.7;
  assume {:sourceloc "driver.re.c", 325, 6} true;
  $b93 := ($p92 != 0);
  assume {:sourceloc "driver.re.c", 325, 6} true;
  goto $bb21, $bb23;
$bb21:
  assume {:sourceloc "driver.re.c", 325, 6} true;
  assume $b93;
  goto $bb22;
$bb22:
  assume {:sourceloc "driver.re.c", 330, 2} true;
  call pc8736x_init_shadow();
  assume {:sourceloc "driver.re.c", 333, 2} true;
  call cdev_init(pc8736x_gpio_cdev, pc8736x_gpio_fileops);
  assume {:sourceloc "driver.re.c", 334, 2} true;
  $p98 := $M.0[$p0];
  assume {:sourceloc "driver.re.c", 334, 2} true;
  call $p99 := cdev_add(pc8736x_gpio_cdev, $p98, 32);
  assume {:sourceloc "driver.re.c", 336, 2} true;
  $p6 := 0;
  goto $bb3;
$bb23:
  assume !($b93);
  assume {:sourceloc "driver.re.c", 326, 3} true;
  $M.7 := $p82;
  call {:cexpr "major"} boogie_si_record_int($p82);
  assume {:sourceloc "driver.re.c", 327, 3} true;
  $p94 := $M.4[pdev];
  assume {:sourceloc "driver.re.c", 327, 3} true;
  $p95 := $pa($pa($p94, 0, 168), 16, 1);
  assume {:sourceloc "driver.re.c", 327, 3} true;
  $p96 := $M.7;
  assume {:sourceloc "driver.re.c", 327, 3} true;
  call $p97 := dev_dbg#3($p95, $pa($pa(.str118, 0, 22), 0, 1), $p96);
  assume {:sourceloc "driver.re.c", 328, 2} true;
  goto $bb22;
}
procedure pc8736x_gpio_open(inode: int, file: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $b7: bool;
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
  var $p4: int;
  var $p5: int;
  var $p6: int;
  var $p8: int;
  var $p9: int;
$bb0:
  call {:cexpr "inode"} boogie_si_record_int(inode);
  call {:cexpr "file"} boogie_si_record_int(file);
  call {:cexpr "inode"} boogie_si_record_int(inode);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 483, 9} true;
  $p0 := $pa($pa(inode, 0, 280), 112, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 483, 9} true;
  $p1 := $M.0[$p0];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 483, 9} true;
  call $p2 := MINOR#1($p1);
  call {:cexpr "m"} boogie_si_record_int($p2);
  assume {:sourceloc "driver.re.c", 231, 2} true;
  $p3 := $pa($pa(file, 0, 56), 40, 1);
  assume {:sourceloc "driver.re.c", 231, 2} true;
  $M.0[$p3] := pc8736x_gpio_ops;
  assume {:sourceloc "driver.re.c", 233, 2} true;
  $p4 := $M.4[pdev];
  assume {:sourceloc "driver.re.c", 233, 2} true;
  $p5 := $pa($pa($p4, 0, 168), 16, 1);
  assume {:sourceloc "driver.re.c", 233, 2} true;
  call $p6 := dev_dbg#3($p5, $pa($pa(.str109, 0, 9), 0, 1), $p2);
  assume {:sourceloc "driver.re.c", 235, 6} true;
  $b7 := $uge($p2, 32);
  assume {:sourceloc "driver.re.c", 235, 6} true;
  goto $bb1, $bb2;
$bb1:
  assume $b7;
  assume {:sourceloc "driver.re.c", 236, 3} true;
  $p8 := -22;
  goto $bb3;
$bb2:
  assume !($b7);
  assume {:sourceloc "driver.re.c", 237, 9} true;
  call $p9 := nonseekable_open(inode, file);
  assume {:sourceloc "driver.re.c", 237, 9} true;
  $p8 := $p9;
  goto $bb3;
$bb3:
  assume {:sourceloc "driver.re.c", 238, 1} true;
  $r := $p8;
  $exn := false;
  return;
}
procedure pc8736x_gpio_set(minor: int, val: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
  var $p10: int;
  var $p11: int;
  var $p12: int;
  var $p13: int;
  var $p14: int;
  var $p15: int;
  var $p16: int;
  var $p17: int;
  var $p18: int;
  var $p19: int;
  var $p2: int;
  var $p20: int;
  var $p21: int;
  var $p22: int;
  var $p23: int;
  var $p24: int;
  var $p25: int;
  var $p26: int;
  var $p27: int;
  var $p28: int;
  var $p29: int;
  var $p3: int;
  var $p30: int;
  var $p31: int;
  var $p32: int;
  var $p33: int;
  var $p34: int;
  var $p35: int;
  var $p36: int;
  var $p37: int;
  var $p38: int;
  var $p39: int;
  var $p4: int;
  var $p40: int;
  var $p41: int;
  var $p42: int;
  var $p43: int;
  var $p44: int;
  var $p45: int;
  var $p46: int;
  var $p47: int;
  var $p48: int;
  var $p49: int;
  var $p5: int;
  var $p50: int;
  var $p51: int;
  var $p52: int;
  var $p53: int;
  var $p54: int;
  var $p55: int;
  var $p56: int;
  var $p57: int;
  var $p58: int;
  var $p59: int;
  var $p6: int;
  var $p60: int;
  var $p7: int;
  var $p8: int;
  var $p9: int;
$bb0:
  call {:cexpr "minor"} boogie_si_record_int(minor);
  call {:cexpr "val"} boogie_si_record_int(val);
  assume {:sourceloc "driver.re.c", 176, 2} true;
  $p0 := $and(minor, 31);
  call {:cexpr "minor"} boogie_si_record_int($p0);
  assume {:sourceloc "driver.re.c", 177, 2} true;
  $p1 := $lshr($p0, 3);
  call {:cexpr "port"} boogie_si_record_int($p1);
  assume {:sourceloc "driver.re.c", 178, 2} true;
  $p2 := $and($p0, 7);
  call {:cexpr "bit"} boogie_si_record_int($p2);
  assume {:sourceloc "driver.re.c", 179, 11} true;
  $p3 := $M.2;
  assume {:sourceloc "driver.re.c", 179, 11} true;
  $p4 := $p1;
  assume {:sourceloc "driver.re.c", 179, 11} true;
  $p5 := $pa($pa(port_offset, 0, 16), $p4, 4);
  assume {:sourceloc "driver.re.c", 179, 11} true;
  $p6 := $M.3[$p5];
  assume {:sourceloc "driver.re.c", 179, 11} true;
  $p7 := $add($p3, $p6);
  assume {:sourceloc "driver.re.c", 179, 11} true;
  $p8 := $add($p7, 0);
  assume {:sourceloc "driver.re.c", 179, 11} true;
  call $p9 := inb_p($p8);
  assume {:sourceloc "driver.re.c", 179, 11} true;
  $p10 := $p9;
  call {:cexpr "curval"} boogie_si_record_int($p10);
  assume {:sourceloc "driver.re.c", 181, 2} true;
  $p11 := $M.4[pdev];
  assume {:sourceloc "driver.re.c", 181, 2} true;
  $p12 := $pa($pa($p11, 0, 168), 16, 1);
  assume {:sourceloc "driver.re.c", 181, 2} true;
  $p13 := $M.2;
  assume {:sourceloc "driver.re.c", 181, 2} true;
  $p14 := $p1;
  assume {:sourceloc "driver.re.c", 181, 2} true;
  $p15 := $pa($pa(port_offset, 0, 16), $p14, 4);
  assume {:sourceloc "driver.re.c", 181, 2} true;
  $p16 := $M.3[$p15];
  assume {:sourceloc "driver.re.c", 181, 2} true;
  $p17 := $add($p13, $p16);
  assume {:sourceloc "driver.re.c", 181, 2} true;
  $p18 := $add($p17, 0);
  assume {:sourceloc "driver.re.c", 181, 2} true;
  $p19 := $shl(1, $p2);
  assume {:sourceloc "driver.re.c", 181, 2} true;
  $p20 := $xor($p19, -1);
  assume {:sourceloc "driver.re.c", 181, 2} true;
  $p21 := $and($p10, $p20);
  assume {:sourceloc "driver.re.c", 181, 2} true;
  $p22 := $shl(val, $p2);
  assume {:sourceloc "driver.re.c", 181, 2} true;
  call $p23 := dev_dbg#8($p12, $pa($pa(.str106, 0, 61), 0, 1), $p18, $p10, $p2, $p21, val, $p22);
  assume {:sourceloc "driver.re.c", 185, 2} true;
  $p24 := $shl(1, $p2);
  assume {:sourceloc "driver.re.c", 185, 2} true;
  $p25 := $xor($p24, -1);
  assume {:sourceloc "driver.re.c", 185, 2} true;
  $p26 := $and($p10, $p25);
  assume {:sourceloc "driver.re.c", 185, 2} true;
  $p27 := $shl(val, $p2);
  assume {:sourceloc "driver.re.c", 185, 2} true;
  $p28 := $or($p26, $p27);
  call {:cexpr "val"} boogie_si_record_int($p28);
  assume {:sourceloc "driver.re.c", 187, 2} true;
  $p29 := $M.4[pdev];
  assume {:sourceloc "driver.re.c", 187, 2} true;
  $p30 := $pa($pa($p29, 0, 168), 16, 1);
  assume {:sourceloc "driver.re.c", 187, 2} true;
  call $p31 := dev_dbg#7($p30, $pa($pa(.str107, 0, 46), 0, 1), $p0, $p1, $p2, $p10, $p28);
  assume {:sourceloc "driver.re.c", 190, 2} true;
  $p32 := $trunc($p28, 8);
  assume {:sourceloc "driver.re.c", 190, 2} true;
  $p33 := $M.2;
  assume {:sourceloc "driver.re.c", 190, 2} true;
  $p34 := $p1;
  assume {:sourceloc "driver.re.c", 190, 2} true;
  $p35 := $pa($pa(port_offset, 0, 16), $p34, 4);
  assume {:sourceloc "driver.re.c", 190, 2} true;
  $p36 := $M.3[$p35];
  assume {:sourceloc "driver.re.c", 190, 2} true;
  $p37 := $add($p33, $p36);
  assume {:sourceloc "driver.re.c", 190, 2} true;
  $p38 := $add($p37, 0);
  assume {:sourceloc "driver.re.c", 190, 2} true;
  call outb_p($p32, $p38);
  assume {:sourceloc "driver.re.c", 192, 11} true;
  $p39 := $M.2;
  assume {:sourceloc "driver.re.c", 192, 11} true;
  $p40 := $p1;
  assume {:sourceloc "driver.re.c", 192, 11} true;
  $p41 := $pa($pa(port_offset, 0, 16), $p40, 4);
  assume {:sourceloc "driver.re.c", 192, 11} true;
  $p42 := $M.3[$p41];
  assume {:sourceloc "driver.re.c", 192, 11} true;
  $p43 := $add($p39, $p42);
  assume {:sourceloc "driver.re.c", 192, 11} true;
  $p44 := $add($p43, 0);
  assume {:sourceloc "driver.re.c", 192, 11} true;
  call $p45 := inb_p($p44);
  assume {:sourceloc "driver.re.c", 192, 11} true;
  $p46 := $p45;
  call {:cexpr "curval"} boogie_si_record_int($p46);
  assume {:sourceloc "driver.re.c", 193, 8} true;
  $p47 := $M.2;
  assume {:sourceloc "driver.re.c", 193, 8} true;
  $p48 := $p1;
  assume {:sourceloc "driver.re.c", 193, 8} true;
  $p49 := $pa($pa(port_offset, 0, 16), $p48, 4);
  assume {:sourceloc "driver.re.c", 193, 8} true;
  $p50 := $M.3[$p49];
  assume {:sourceloc "driver.re.c", 193, 8} true;
  $p51 := $add($p47, $p50);
  assume {:sourceloc "driver.re.c", 193, 8} true;
  $p52 := $add($p51, 1);
  assume {:sourceloc "driver.re.c", 193, 8} true;
  call $p53 := inb_p($p52);
  assume {:sourceloc "driver.re.c", 193, 8} true;
  $p54 := $p53;
  call {:cexpr "val"} boogie_si_record_int($p54);
  assume {:sourceloc "driver.re.c", 195, 2} true;
  $p55 := $M.4[pdev];
  assume {:sourceloc "driver.re.c", 195, 2} true;
  $p56 := $pa($pa($p55, 0, 168), 16, 1);
  assume {:sourceloc "driver.re.c", 195, 2} true;
  call $p57 := dev_dbg#4($p56, $pa($pa(.str108, 0, 20), 0, 1), $p46, $p54);
  assume {:sourceloc "driver.re.c", 196, 2} true;
  call mutex_lock(gpio_shadow_lock);
  assume {:sourceloc "driver.re.c", 197, 2} true;
  $p58 := $trunc($p54, 8);
  assume {:sourceloc "driver.re.c", 197, 2} true;
  $p59 := $p1;
  assume {:sourceloc "driver.re.c", 197, 2} true;
  $p60 := $pa($pa(pc8736x_gpio_shadow, 0, 4), $p59, 1);
  assume {:sourceloc "driver.re.c", 197, 2} true;
  $M.6[$p60] := $p58;
  assume {:sourceloc "driver.re.c", 198, 2} true;
  call mutex_unlock(gpio_shadow_lock);
  assume {:sourceloc "driver.re.c", 199, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} pc8736x_init_shadow()
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $b1: bool;
  var $p0: int;
  var $p10: int;
  var $p11: int;
  var $p2: int;
  var $p3: int;
  var $p4: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;
  var $p8: int;
  var $p9: int;
$bb0:
  call {:cexpr "port"} boogie_si_record_int(0);
  assume {:sourceloc "driver.re.c", 253, 7} true;
  $p0 := 0;
  goto $bb1;
$bb1:
  assume {:sourceloc "driver.re.c", 253, 7} true;
  $b1 := $slt($p0, 4);
  assume {:sourceloc "driver.re.c", 253, 7} true;
  goto $bb2, $bb3;
$bb2:
  assume $b1;
  assume {:sourceloc "driver.re.c", 255, 9} true;
  $p2 := $M.2;
  assume {:sourceloc "driver.re.c", 255, 9} true;
  $p3 := $p0;
  assume {:sourceloc "driver.re.c", 255, 9} true;
  $p4 := $pa($pa(port_offset, 0, 16), $p3, 4);
  assume {:sourceloc "driver.re.c", 255, 9} true;
  $p5 := $M.3[$p4];
  assume {:sourceloc "driver.re.c", 255, 9} true;
  $p6 := $add($p2, $p5);
  assume {:sourceloc "driver.re.c", 255, 9} true;
  $p7 := $add($p6, 0);
  assume {:sourceloc "driver.re.c", 255, 9} true;
  call $p8 := inb_p($p7);
  assume {:sourceloc "driver.re.c", 255, 9} true;
  $p9 := $p0;
  assume {:sourceloc "driver.re.c", 255, 9} true;
  $p10 := $pa($pa(pc8736x_gpio_shadow, 0, 4), $p9, 1);
  assume {:sourceloc "driver.re.c", 255, 9} true;
  $M.6[$p10] := $p8;
  assume {:sourceloc "driver.re.c", 253, 27} true;
  $p11 := $add($p0, 1);
  call {:cexpr "port"} boogie_si_record_int($p11);
  assume {:sourceloc "driver.re.c", 253, 27} true;
  $p0 := $p11;
  goto $bb1;
$bb3:
  assume !($b1);
  assume {:sourceloc "driver.re.c", 258, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} pc8736x_superio_present()
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $b10: bool;
  var $b22: bool;
  var $b23: bool;
  var $b24: bool;
  var $b8: bool;
  var $b9: bool;
  var $p0: int;
  var $p1: int;
  var $p11: int;
  var $p12: int;
  var $p13: int;
  var $p14: int;
  var $p15: int;
  var $p16: int;
  var $p17: int;
  var $p18: int;
  var $p19: int;
  var $p2: int;
  var $p20: int;
  var $p21: int;
  var $p25: int;
  var $p26: int;
  var $p3: int;
  var $p4: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;
$bb0:
  assume {:sourceloc "driver.re.c", 100, 2} true;
  $M.12 := 46;
  call {:cexpr "superio_cmd"} boogie_si_record_int(46);
  call {:cexpr "addr"} boogie_si_record_int(32);
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p0 := $trunc(32, 8);
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p1 := $M.12;
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p2 := $p1;
  assume {:sourceloc "driver.re.c", 91, 2} true;
  call outb_p($p0, $p2);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p3 := $M.12;
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p4 := $p3;
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p5 := $add($p4, 1);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  call $p6 := inb_p($p5);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p7 := $p6;
  call {:cexpr "id"} boogie_si_record_int($p7);
  assume {:sourceloc "driver.re.c", 102, 6} true;
  $b8 := ($p7 == 229);
  assume {:sourceloc "driver.re.c", 102, 6} true;
  $b9 := ($p7 == 233);
  assume {:sourceloc "driver.re.c", 102, 6} true;
  $b10 := $i2b($or($b2i($b8), $b2i($b9)));
  assume {:sourceloc "driver.re.c", 102, 6} true;
  goto $bb1, $bb2;
$bb1:
  assume $b10;
  assume {:sourceloc "driver.re.c", 103, 3} true;
  $p11 := $M.12;
  assume {:sourceloc "driver.re.c", 103, 3} true;
  $p12 := $p11;
  assume {:sourceloc "driver.re.c", 103, 3} true;
  $p13 := $p12;
  goto $bb3;
$bb2:
  assume !($b10);
  assume {:sourceloc "driver.re.c", 105, 2} true;
  $M.12 := 78;
  call {:cexpr "superio_cmd"} boogie_si_record_int(78);
  call {:cexpr "addr"} boogie_si_record_int(32);
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p14 := $trunc(32, 8);
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p15 := $M.12;
  assume {:sourceloc "driver.re.c", 91, 2} true;
  $p16 := $p15;
  assume {:sourceloc "driver.re.c", 91, 2} true;
  call outb_p($p14, $p16);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p17 := $M.12;
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p18 := $p17;
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p19 := $add($p18, 1);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  call $p20 := inb_p($p19);
  assume {:sourceloc "driver.re.c", 92, 9} true;
  $p21 := $p20;
  call {:cexpr "id"} boogie_si_record_int($p21);
  assume {:sourceloc "driver.re.c", 107, 6} true;
  $b22 := ($p21 == 229);
  assume {:sourceloc "driver.re.c", 107, 6} true;
  $b23 := ($p21 == 233);
  assume {:sourceloc "driver.re.c", 107, 6} true;
  $b24 := $i2b($or($b2i($b22), $b2i($b23)));
  assume {:sourceloc "driver.re.c", 107, 6} true;
  goto $bb4, $bb5;
$bb3:
  assume {:sourceloc "driver.re.c", 111, 1} true;
  $r := $p13;
  $exn := false;
  return;
$bb4:
  assume $b24;
  assume {:sourceloc "driver.re.c", 108, 3} true;
  $p25 := $M.12;
  assume {:sourceloc "driver.re.c", 108, 3} true;
  $p26 := $p25;
  assume {:sourceloc "driver.re.c", 108, 3} true;
  $p13 := $p26;
  goto $bb3;
$bb5:
  assume !($b24);
  assume {:sourceloc "driver.re.c", 110, 2} true;
  $p13 := 0;
  goto $bb3;
}
procedure platform_device_add#0()
  returns ($r: int);
procedure platform_device_add#1(p#0: int)
  returns ($r: int);
procedure platform_device_alloc#0()
  returns ($r: int);
procedure platform_device_alloc#2(p#0: int, p#1: int)
  returns ($r: int);
procedure platform_device_del#0()
  returns ($r: int);
procedure platform_device_del#1(p#0: int)
  returns ($r: int);
procedure platform_device_put#0()
  returns ($r: int);
procedure platform_device_put#1(p#0: int)
  returns ($r: int);
procedure platform_device_unregister#0()
  returns ($r: int);
procedure platform_device_unregister#1(p#0: int)
  returns ($r: int);
procedure {:inline 1} readb(addr: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
$bb0:
  call {:cexpr "addr"} boogie_si_record_int(addr);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 42, 2} true;
  $p0 := $M.25[addr];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 42, 2} true;
  $r := $p0;
  $exn := false;
  return;
}
procedure {:inline 1} readl(addr: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "addr"} boogie_si_record_int(addr);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 52, 2} true;
  $p0 := addr;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 52, 2} true;
  $p1 := $M.27[$p0];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 52, 2} true;
  $r := $p1;
  $exn := false;
  return;
}
procedure {:inline 1} readw(addr: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "addr"} boogie_si_record_int(addr);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 47, 2} true;
  $p0 := addr;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 47, 2} true;
  $p1 := $M.26[$p0];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 47, 2} true;
  $r := $p1;
  $exn := false;
  return;
}
procedure {:inline 1} register_chrdev_region(p#0: int, p#1: int, p#2: int)
  returns ($r: int);
procedure release_region#0()
  returns ($r: int);
procedure release_region#2(p#0: int, p#1: int)
  returns ($r: int);
procedure request_region#0()
  returns ($r: int);
procedure request_region#3(p#0: int, p#1: int, p#2: int)
  returns ($r: int);
procedure {:inline 1} select_pin(iminor: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
  var $p10: int;
  var $p2: int;
  var $p3: int;
  var $p4: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;
  var $p8: int;
  var $p9: int;
$bb0:
  call {:cexpr "iminor"} boogie_si_record_int(iminor);
  assume {:sourceloc "driver.re.c", 122, 2} true;
  call device_select(7);
  assume {:sourceloc "driver.re.c", 123, 2} true;
  $p0 := $shl(iminor, 1);
  assume {:sourceloc "driver.re.c", 123, 2} true;
  $p1 := $and($p0, 240);
  assume {:sourceloc "driver.re.c", 123, 2} true;
  $p2 := $and(iminor, 7);
  assume {:sourceloc "driver.re.c", 123, 2} true;
  $p3 := $or($p1, $p2);
  call {:cexpr "addr"} boogie_si_record_int(240);
  call {:cexpr "val"} boogie_si_record_int($p3);
  assume {:sourceloc "driver.re.c", 85, 2} true;
  $p4 := $trunc(240, 8);
  assume {:sourceloc "driver.re.c", 85, 2} true;
  $p5 := $M.12;
  assume {:sourceloc "driver.re.c", 85, 2} true;
  $p6 := $p5;
  assume {:sourceloc "driver.re.c", 85, 2} true;
  call outb_p($p4, $p6);
  assume {:sourceloc "driver.re.c", 86, 2} true;
  $p7 := $trunc($p3, 8);
  assume {:sourceloc "driver.re.c", 86, 2} true;
  $p8 := $M.12;
  assume {:sourceloc "driver.re.c", 86, 2} true;
  $p9 := $p8;
  assume {:sourceloc "driver.re.c", 86, 2} true;
  $p10 := $add($p9, 1);
  assume {:sourceloc "driver.re.c", 86, 2} true;
  call outb_p($p7, $p10);
  assume {:sourceloc "driver.re.c", 125, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_lock(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 34, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 35, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 37, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 38, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 38, 3} true;
  $p2 := $M.14[$p1];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 38, 3} true;
  assume $p2 == 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 39, 3} true;
  $p3 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 39, 3} true;
  $M.14[$p3] := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 40, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 41, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_lock_bh(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 67, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 68, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 70, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 71, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 71, 3} true;
  $p2 := $M.17[$p1];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 71, 3} true;
  assume $p2 == 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 72, 3} true;
  $p3 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 72, 3} true;
  $M.17[$p3] := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 73, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 74, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_lock_init(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 28, 3} true;
  $p0 := $pa($pa(lock, 0, 8), 0, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 28, 3} true;
  $M.13[$p0] := 1;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 29, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 29, 3} true;
  $M.13[$p1] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 30, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_lock_irq(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 56, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 57, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 59, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 60, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 60, 3} true;
  $p2 := $M.16[$p1];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 60, 3} true;
  assume $p2 == 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 61, 3} true;
  $p3 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 61, 3} true;
  $M.16[$p3] := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 62, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 63, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_lock_irqsave(lock: int, value: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  call {:cexpr "value"} boogie_si_record_int(value);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 45, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 46, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 48, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 49, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 49, 3} true;
  $p2 := $M.15[$p1];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 49, 3} true;
  assume $p2 == 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 50, 3} true;
  $p3 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 50, 3} true;
  $M.15[$p3] := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 51, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 52, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_unlock(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 78, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 79, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 81, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 82, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 82, 3} true;
  $M.18[$p1] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 83, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 84, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_unlock_bh(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 108, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 109, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 111, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 112, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 112, 3} true;
  $M.21[$p1] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 113, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 114, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_unlock_irq(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 98, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 99, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 101, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 102, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 102, 3} true;
  $M.20[$p1] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 103, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 104, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_unlock_irqrestore(lock: int, value: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  call {:cexpr "value"} boogie_si_record_int(value);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 88, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 89, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 91, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 92, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 92, 3} true;
  $M.19[$p1] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 93, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 94, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} timespec_trunc1(ret: int, p#1: int, p#2: int, p#3: int)
  returns ($r: int);
procedure {:inline 1} unregister_chrdev_region(p#0: int, p#1: int);
procedure {:inline 1} usb_register(driver: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
$bb0:
  call {:cexpr "driver"} boogie_si_record_int(driver);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/usb.h", 1146, 9} true;
  call $p0 := __SMACK_nondet();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/usb.h", 1146, 9} true;
  $r := $p0;
  $exn := false;
  return;
}
procedure {:inline 1} whoop$checker()
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
  var $p1: int;
  var $p10: int;
  var $p11: int;
  var $p12: int;
  var $p13: int;
  var $p14: int;
  var $p15: int;
  var $p16: int;
  var $p17: int;
  var $p18: int;
  var $p19: int;
  var $p2: int;
  var $p20: int;
  var $p21: int;
  var $p22: int;
  var $p23: int;
  var $p24: int;
  var $p25: int;
  var $p26: int;
  var $p27: int;
  var $p28: int;
  var $p29: int;
  var $p3: int;
  var $p30: int;
  var $p31: int;
  var $p32: int;
  var $p33: int;
  var $p34: int;
  var $p35: int;
  var $p36: int;
  var $p37: int;
  var $p38: int;
  var $p39: int;
  var $p4: int;
  var $p40: int;
  var $p41: int;
  var $p42: int;
  var $p43: int;
  var $p44: int;
  var $p45: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;
  var $p8: int;
  var $p9: int;
$bb0:
  assume {:sourceloc "driver.re.c", 364, 49} true;
  call $p0 := $malloc(280);
  assume {:sourceloc "driver.re.c", 364, 49} true;
  $p1 := $p0;
  call {:cexpr "whoop_inode$0"} boogie_si_record_int($p1);
  assume {:sourceloc "driver.re.c", 365, 46} true;
  call $p2 := $malloc(56);
  assume {:sourceloc "driver.re.c", 365, 46} true;
  $p3 := $p2;
  call {:cexpr "whoop_file$0"} boogie_si_record_int($p3);
  assume {:sourceloc "driver.re.c", 366, 49} true;
  call $p4 := $malloc(280);
  assume {:sourceloc "driver.re.c", 366, 49} true;
  $p5 := $p4;
  call {:cexpr "whoop_inode$1"} boogie_si_record_int($p5);
  assume {:sourceloc "driver.re.c", 367, 46} true;
  call $p6 := $malloc(56);
  assume {:sourceloc "driver.re.c", 367, 46} true;
  $p7 := $p6;
  call {:cexpr "whoop_file$1"} boogie_si_record_int($p7);
  assume {:sourceloc "driver.re.c", 368, 49} true;
  call $p8 := $malloc(280);
  assume {:sourceloc "driver.re.c", 368, 49} true;
  $p9 := $p8;
  call {:cexpr "whoop_inode$2"} boogie_si_record_int($p9);
  assume {:sourceloc "driver.re.c", 369, 46} true;
  call $p10 := $malloc(56);
  assume {:sourceloc "driver.re.c", 369, 46} true;
  $p11 := $p10;
  call {:cexpr "whoop_file$2"} boogie_si_record_int($p11);
  assume {:sourceloc "driver.re.c", 370, 49} true;
  call $p12 := $malloc(280);
  assume {:sourceloc "driver.re.c", 370, 49} true;
  $p13 := $p12;
  call {:cexpr "whoop_inode$3"} boogie_si_record_int($p13);
  assume {:sourceloc "driver.re.c", 371, 46} true;
  call $p14 := $malloc(56);
  assume {:sourceloc "driver.re.c", 371, 46} true;
  $p15 := $p14;
  call {:cexpr "whoop_file$3"} boogie_si_record_int($p15);
  assume {:sourceloc "driver.re.c", 372, 49} true;
  call $p16 := $malloc(280);
  assume {:sourceloc "driver.re.c", 372, 49} true;
  $p17 := $p16;
  call {:cexpr "whoop_inode$4"} boogie_si_record_int($p17);
  assume {:sourceloc "driver.re.c", 373, 46} true;
  call $p18 := $malloc(56);
  assume {:sourceloc "driver.re.c", 373, 46} true;
  $p19 := $p18;
  call {:cexpr "whoop_file$4"} boogie_si_record_int($p19);
  assume {:sourceloc "driver.re.c", 374, 49} true;
  call $p20 := $malloc(280);
  assume {:sourceloc "driver.re.c", 374, 49} true;
  $p21 := $p20;
  call {:cexpr "whoop_inode$5"} boogie_si_record_int($p21);
  assume {:sourceloc "driver.re.c", 375, 46} true;
  call $p22 := $malloc(56);
  assume {:sourceloc "driver.re.c", 375, 46} true;
  $p23 := $p22;
  call {:cexpr "whoop_file$5"} boogie_si_record_int($p23);
  assume {:sourceloc "driver.re.c", 376, 49} true;
  call $p24 := $malloc(280);
  assume {:sourceloc "driver.re.c", 376, 49} true;
  $p25 := $p24;
  call {:cexpr "whoop_inode$6"} boogie_si_record_int($p25);
  assume {:sourceloc "driver.re.c", 377, 46} true;
  call $p26 := $malloc(56);
  assume {:sourceloc "driver.re.c", 377, 46} true;
  $p27 := $p26;
  call {:cexpr "whoop_file$6"} boogie_si_record_int($p27);
  assume {:sourceloc "driver.re.c", 378, 53} true;
  call $p28 := $malloc(512);
  assume {:sourceloc "driver.re.c", 378, 53} true;
  $p29 := $p28;
  call {:cexpr "whoop_pci_dev"} boogie_si_record_int($p29);
  assume {:sourceloc "driver.re.c", 379, 35} true;
  call $p30 := $malloc(1);
  call {:cexpr "whoop_buf"} boogie_si_record_int($p30);
  assume {:sourceloc "driver.re.c", 380, 77} true;
  call $p31 := $malloc(168);
  assume {:sourceloc "driver.re.c", 380, 77} true;
  $p32 := $p31;
  call {:cexpr "whoop_platform_device"} boogie_si_record_int($p32);
  assume {:sourceloc "driver.re.c", 381, 74} true;
  call $p33 := $malloc(32);
  assume {:sourceloc "driver.re.c", 381, 74} true;
  $p34 := $p33;
  call {:cexpr "whoop_vm_area_struct"} boogie_si_record_int($p34);
  assume {:sourceloc "driver.re.c", 382, 50} true;
  call $p35 := $malloc(152);
  assume {:sourceloc "driver.re.c", 382, 50} true;
  $p36 := $p35;
  call {:cexpr "whoop_cx_dev"} boogie_si_record_int($p36);
  assume {:sourceloc "driver.re.c", 384, 48} true;
  call $p37 := $malloc(4);
  assume {:sourceloc "driver.re.c", 384, 48} true;
  $p38 := $p37;
  call {:cexpr "whoop_poll_table"} boogie_si_record_int($p38);
  assume {:sourceloc "driver.re.c", 386, 36} true;
  call $p39 := $malloc(8);
  assume {:sourceloc "driver.re.c", 386, 36} true;
  $p40 := $p39;
  call {:cexpr "whoop_loff_t"} boogie_si_record_int($p40);
  assume {:sourceloc "driver.re.c", 387, 18} true;
  call $p41 := __SMACK_nondet();
  call {:cexpr "whoop_int"} boogie_si_record_int($p41);
  assume {:sourceloc "driver.re.c", 388, 2} true;
  assume $p41 >= 0;
  assume {:sourceloc "driver.re.c", 390, 2} true;
  call pc8736x_gpio_set($p41, $p41);
  assume {:sourceloc "driver.re.c", 391, 2} true;
  call $p42 := pc8736x_gpio_open($p5, $p7);
  assume {:sourceloc "driver.re.c", 392, 2} true;
  call $p43 := pc8736x_gpio_get($p41);
  assume {:sourceloc "driver.re.c", 393, 2} true;
  call $p44 := pc8736x_gpio_current($p41);
  assume {:sourceloc "driver.re.c", 394, 2} true;
  call $p45 := pc8736x_gpio_configure($p41, $p41, $p41);
  assume {:sourceloc "driver.re.c", 395, 2} true;
  call pc8736x_gpio_cleanup();
  assume {:sourceloc "driver.re.c", 396, 2} true;
  call pc8736x_gpio_change($p41);
  assume {:sourceloc "driver.re.c", 397, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} writeb(value: int, addr: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
$bb0:
  call {:cexpr "value"} boogie_si_record_int(value);
  call {:cexpr "addr"} boogie_si_record_int(addr);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 57, 2} true;
  $M.28[addr] := value;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 58, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} writel(value: int, addr: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
$bb0:
  call {:cexpr "value"} boogie_si_record_int(value);
  call {:cexpr "addr"} boogie_si_record_int(addr);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 67, 2} true;
  $p0 := addr;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 67, 2} true;
  $M.30[$p0] := value;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 68, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} writew(value: int, addr: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;
{
  var $p0: int;
$bb0:
  call {:cexpr "value"} boogie_si_record_int(value);
  call {:cexpr "addr"} boogie_si_record_int(addr);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 62, 2} true;
  $p0 := addr;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 62, 2} true;
  $M.29[$p0] := value;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/asm/io.h", 63, 1} true;
  $exn := false;
  return;
}
axiom (__SMACK_nondet.XXX == -34);
axiom (pc8736x_gpio_base == -5176);
axiom (port_offset == -5192);
axiom (pdev == -5200);
axiom (gpio_shadow_lock == -5375);
axiom (pc8736x_gpio_shadow == -5379);
axiom (pc8736x_gpio_ops == -5443);
axiom (major == -5617);
axiom (pc8736x_gpio_cdev == -5691);
axiom (pc8736x_gpio_fileops == -5891);
axiom (_whoop_init == -5908);
axiom (_whoop_exit == -5916);
axiom (jiffies == -5939);
axiom (selected_device == -5940);
axiom (superio_cmd == -5941);
axiom (pc8736x_gpio_config_lock == -5949);
axiom $NULL == 0;
axiom $and(0,0) == 0;
axiom $and(0,1) == 0;
axiom $and(1,0) == 0;
axiom $and(1,1) == 1;
axiom $or(0,0) == 0;
axiom $or(0,1) == 1;
axiom $or(1,0) == 1;
axiom $or(1,1) == 1;
axiom $xor(0,0) == 0;
axiom $xor(0,1) == 1;
axiom $xor(1,0) == 1;
axiom $xor(1,1) == 0;
axiom (forall f1, f2: float :: f1 != f2 || $foeq(f1,f2));
axiom (forall f: float :: $si2fp($fp2si(f)) == f);
axiom (forall f: float :: $ui2fp($fp2ui(f)) == f);
axiom (forall i: int :: $fp2si($si2fp(i)) == i);
axiom (forall i: int :: $fp2ui($ui2fp(i)) == i);
const $GLOBALS_BOTTOM: int;
const $MOP: $mop;
const $UNDEF: int;
const unique $NULL: int;
function $and(p1:int, p2:int) returns (int);
function $ashr(p1:int, p2:int) returns (int);
function $base(int) returns (int);
function $extractvalue(p: int, i: int) returns (int);
function $fadd(f1:float, f2:float) returns (float);
function $fdiv(f1:float, f2:float) returns (float);
function $ffalse(f1:float, f2:float) returns (bool);
function $fmul(f1:float, f2:float) returns (float);
function $foeq(f1:float, f2:float) returns (bool);
function $foge(f1:float, f2:float) returns (bool);
function $fogt(f1:float, f2:float) returns (bool);
function $fole(f1:float, f2:float) returns (bool);
function $folt(f1:float, f2:float) returns (bool);
function $fone(f1:float, f2:float) returns (bool);
function $ford(f1:float, f2:float) returns (bool);
function $fp(ipart:int, fpart:int, epart:int) returns (float);
function $fp2si(f:float) returns (int);
function $fp2ui(f:float) returns (int);
function $frem(f1:float, f2:float) returns (float);
function $fsub(f1:float, f2:float) returns (float);
function $ftrue(f1:float, f2:float) returns (bool);
function $fueq(f1:float, f2:float) returns (bool);
function $fuge(f1:float, f2:float) returns (bool);
function $fugt(f1:float, f2:float) returns (bool);
function $fule(f1:float, f2:float) returns (bool);
function $fult(f1:float, f2:float) returns (bool);
function $fune(f1:float, f2:float) returns (bool);
function $funo(f1:float, f2:float) returns (bool);
function $lshr(p1:int, p2:int) returns (int);
function $nand(p1:int, p2:int) returns (int);
function $or(p1:int, p2:int) returns (int);
function $shl(p1:int, p2:int) returns (int);
function $si2fp(i:int) returns (float);
function $ui2fp(i:int) returns (float);
function $xor(p1:int, p2:int) returns (int);
function {:builtin "div"} $sdiv(p1:int, p2:int) returns (int);
function {:builtin "div"} $udiv(p1:int, p2:int) returns (int);
function {:builtin "rem"} $srem(p1:int, p2:int) returns (int);
function {:builtin "rem"} $urem(p1:int, p2:int) returns (int);
function {:inline} $add(p1:int, p2:int) returns (int) {p1 + p2}
function {:inline} $b2i(b: bool) returns (int) {if b then 1 else 0}
function {:inline} $b2p(b: bool) returns (int) {if b then 1 else 0}
function {:inline} $i2b(i: int) returns (bool) {i != 0}
function {:inline} $i2p(p: int) returns (int) {p}
function {:inline} $isExternal(p: int) returns (bool) { p < $GLOBALS_BOTTOM - 32768 }
function {:inline} $max(p1:int, p2:int) returns (int) {if p1 > p2 then p1 else p2}
function {:inline} $min(p1:int, p2:int) returns (int) {if p1 > p2 then p2 else p1}
function {:inline} $mul(p1:int, p2:int) returns (int) {p1 * p2}
function {:inline} $p2b(p: int) returns (bool) {p != 0}
function {:inline} $p2i(p: int) returns (int) {p}
function {:inline} $pa(pointer: int, index: int, size: int) returns (int) {pointer + index * size}
function {:inline} $sge(p1:int, p2:int) returns (bool) {p1 >= p2}
function {:inline} $sgt(p1:int, p2:int) returns (bool) {p1 > p2}
function {:inline} $sle(p1:int, p2:int) returns (bool) {p1 <= p2}
function {:inline} $slt(p1:int, p2:int) returns (bool) {p1 < p2}
function {:inline} $sub(p1:int, p2:int) returns (int) {p1 - p2}
function {:inline} $trunc(p: int, size: int) returns (int) {p}
function {:inline} $uge(p1:int, p2:int) returns (bool) {p1 >= p2}
function {:inline} $ugt(p1:int, p2:int) returns (bool) {p1 > p2}
function {:inline} $ule(p1:int, p2:int) returns (bool) {p1 <= p2}
function {:inline} $ult(p1:int, p2:int) returns (bool) {p1 < p2}
function {:inline} $umax(p1:int, p2:int) returns (int) {if p1 > p2 then p1 else p2}
function {:inline} $umin(p1:int, p2:int) returns (int) {if p1 > p2 then p2 else p1}
procedure {:inline 1} $alloca(n: int) returns (p: int)
modifies $CurrAddr, $Alloc;
{
  assume $CurrAddr > 0;
  p := $CurrAddr;
  if (n > 0) {
    $CurrAddr := $CurrAddr + n;
  } else {
    $CurrAddr := $CurrAddr + 1;
  }
  $Alloc[p] := true;
}
procedure {:inline 1} $free(p: int)
modifies $Alloc;
{
  $Alloc[p] := false;
}
procedure {:inline 1} $malloc(n: int) returns (p: int)
modifies $CurrAddr, $Alloc;
{
  assume $CurrAddr > 0;
  p := $CurrAddr;
  if (n > 0) {
    $CurrAddr := $CurrAddr + n;
  } else {
    $CurrAddr := $CurrAddr + 1;
  }
  $Alloc[p] := true;
}
procedure $memcpy.51.51(dest: int, src: int, len: int, align: int, isvolatile: bool);
modifies $M.51;
ensures (forall x:int :: dest <= x && x < dest + len ==> $M.51[x] == old($M.51)[src - dest + x]);
ensures (forall x:int :: !(dest <= x && x < dest + len) ==> $M.51[x] == old($M.51)[x]);

procedure $memcpy.54.54(dest: int, src: int, len: int, align: int, isvolatile: bool);
modifies $M.54;
ensures (forall x:int :: dest <= x && x < dest + len ==> $M.54[x] == old($M.54)[src - dest + x]);
ensures (forall x:int :: !(dest <= x && x < dest + len) ==> $M.54[x] == old($M.54)[x]);

procedure {:inline 1} boogie_si_record_bool(b: bool);
procedure {:inline 1} boogie_si_record_float(f: float);
procedure {:inline 1} boogie_si_record_int(i: int);
procedure {:inline 1} boogie_si_record_mop(m: $mop);
type $mop;
type float;
var $Alloc: [int] bool;
var $CurrAddr:int;
var $exn: bool;
var $exnv: int;

// END SMACK-GENERATED CODE
