procedure corral_atomic_begin();



procedure corral_atomic_end();



procedure corral_getThreadID() returns (t: int);



var $M.0: [int]int;

var $M.1: int;

var $M.2: int;

var $M.3: [int]int;

var $M.4: [int]int;

var $M.5: [int]int;

var $M.6: [int]int;

var $M.7: [int]int;

var $M.8: [int]int;

var $M.9: [int]int;

var $M.10: [int]int;

var $M.11: [int]int;

var $M.12: [int]int;

var $M.13: [int]int;

var $M.14: [int]int;

var $M.15: [int]int;

var $M.16: [int]int;

var $M.17: [int]int;

var $M.18: [int]int;

var $M.19: [int]int;

var $M.20: [int]int;

var $M.21: [int]int;

var $M.22: [int]int;

var $M.23: [int]int;

var $M.24: [int]int;

var $M.25: [int]int;

var $M.26: [int]int;

var $M.27: [int]int;

var $M.28: [int]int;

var $M.29: [int]int;

var $M.30: [int]int;

var $M.31: [int]int;

var $M.32: [int]int;

var $M.33: [int]int;

var $M.34: [int]int;

var $M.35: [int]int;

var $M.36: [int]int;

var $M.37: [int]int;

var $M.38: [int]int;

axiom $GLOBALS_BOTTOM == -5503;

const $u16: int;

const $u19: int;

const unique .str: int;

const unique .str1: int;

const unique .str10: int;

const unique .str100: int;

const unique .str101: int;

const unique .str102: int;

const unique .str103: int;

const unique .str104: int;

const unique .str105: int;

const unique .str106: int;

const unique .str107: int;

const unique .str108: int;

const unique .str11: int;

const unique .str12: int;

const unique .str13: int;

const unique .str14: int;

const unique .str15: int;

const unique .str16: int;

const unique .str17: int;

const unique .str18: int;

const unique .str19: int;

const unique .str2: int;

const unique .str20: int;

const unique .str21: int;

const unique .str22: int;

const unique .str23: int;

const unique .str24: int;

const unique .str25: int;

const unique .str26: int;

const unique .str27: int;

const unique .str28: int;

const unique .str29: int;

const unique .str3: int;

const unique .str30: int;

const unique .str31: int;

const unique .str32: int;

const unique .str33: int;

const unique .str34: int;

const unique .str35: int;

const unique .str36: int;

const unique .str37: int;

const unique .str38: int;

const unique .str39: int;

const unique .str4: int;

const unique .str40: int;

const unique .str41: int;

const unique .str42: int;

const unique .str43: int;

const unique .str44: int;

const unique .str45: int;

const unique .str46: int;

const unique .str47: int;

const unique .str48: int;

const unique .str49: int;

const unique .str5: int;

const unique .str50: int;

const unique .str51: int;

const unique .str52: int;

const unique .str53: int;

const unique .str54: int;

const unique .str55: int;

const unique .str56: int;

const unique .str57: int;

const unique .str58: int;

const unique .str59: int;

const unique .str6: int;

const unique .str60: int;

const unique .str61: int;

const unique .str62: int;

const unique .str63: int;

const unique .str64: int;

const unique .str65: int;

const unique .str66: int;

const unique .str67: int;

const unique .str68: int;

const unique .str69: int;

const unique .str7: int;

const unique .str70: int;

const unique .str71: int;

const unique .str72: int;

const unique .str73: int;

const unique .str74: int;

const unique .str75: int;

const unique .str76: int;

const unique .str77: int;

const unique .str78: int;

const unique .str79: int;

const unique .str8: int;

const unique .str80: int;

const unique .str81: int;

const unique .str82: int;

const unique .str83: int;

const unique .str84: int;

const unique .str85: int;

const unique .str86: int;

const unique .str87: int;

const unique .str88: int;

const unique .str89: int;

const unique .str9: int;

const unique .str90: int;

const unique .str91: int;

const unique .str92: int;

const unique .str93: int;

const unique .str94: int;

const unique .str95: int;

const unique .str96: int;

const unique .str97: int;

const unique .str98: int;

const unique .str99: int;

const unique __SMACK_decls: int;

const unique __SMACK_nondet: int;

const unique __SMACK_nondet.XXX: int;

const unique __get_user: int;

const unique __put_user: int;

const unique _whoop_exit: int;

const unique _whoop_init: int;

const unique access_ok: int;

const unique current_kernel_time2: int;

const unique jiffies: int;

const unique malloc: int;

const unique misc_deregister: int;

const unique misc_register: int;

const unique mutex_lock: int;

const unique mutex_unlock: int;

const unique nvram_dev: int;

const unique nvram_fops: int;

const unique nvram_get_size: int;

const unique nvram_init: int;

const unique nvram_ioctl: int;

const unique nvram_len: int;

const unique nvram_mutex: int;

const unique nvram_read_byte: int;

const unique nvram_sync: int;

const unique nvram_unlocked_ioctl: int;

const unique nvram_write_byte: int;

const unique printk: int;

const unique timespec_trunc1: int;

const unique whoop$checker: int;

const unique write_nvram: int;

procedure {:inline 1} __SMACK_nondet() returns ($r: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;



implementation {:inline 1} __SMACK_nondet() returns ($r: int)
{
  var $p0: int;

  $bb0:
    assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 53, 3} true;
    $p0 := $M.1;
    assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 54, 3} true;
    havoc $p0;
    assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 55, 3} true;
    $r := $p0;
    return;
}



procedure {:inline 1} __get_user(p#0: int, p#1: int) returns ($r: int);



procedure {:inline 1} __put_user(p#0: int, p#1: int) returns ($r: int);



procedure {:inline 1} access_ok(p#0: int, p#1: int, p#2: int) returns ($r: int);



procedure {:inline 1} current_kernel_time2(ret: int) returns ($r: int);



procedure {:inline 1} misc_deregister(p#0: int) returns ($r: int);



procedure {:inline 1} misc_register(p#0: int) returns ($r: int);



procedure {:inline 1} mutex_lock(lock: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;



implementation {:inline 1} mutex_lock(lock: int)
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;

  $bb0:
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 35, 12} true;
    call $p0 := __SMACK_nondet();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 36, 2} true;
    call $p0 := corral_getThreadID();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 38, 2} true;
    call corral_atomic_begin();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 39, 2} true;
    $p1 := $pa($pa(lock, 0, 8), 4, 1);
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 39, 2} true;
    $p2 := $M.3[$p1];
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 39, 2} true;
    assume $p2 == 0;
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 40, 2} true;
    $p3 := $pa($pa(lock, 0, 8), 4, 1);
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 40, 2} true;
    $M.3[$p3] := $p0;
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 41, 2} true;
    call corral_atomic_end();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 42, 1} true;
    return;
}



procedure {:inline 1} mutex_unlock(lock: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;



implementation {:inline 1} mutex_unlock(lock: int)
{
  var $p0: int;
  var $p1: int;

  $bb0:
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 61, 12} true;
    call $p0 := __SMACK_nondet();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 62, 2} true;
    call $p0 := corral_getThreadID();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 64, 2} true;
    call corral_atomic_begin();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 65, 2} true;
    $p1 := $pa($pa(lock, 0, 8), 4, 1);
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 65, 2} true;
    $M.3[$p1] := 0;
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 66, 2} true;
    call corral_atomic_end();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 67, 1} true;
    return;
}



procedure {:inline 1} nvram_get_size() returns ($r: int);



procedure {:entrypoint} nvram_init() returns ($r: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;



implementation {:entrypoint} nvram_init() returns ($r: int)
{
  var $b2: bool;
  var $b5: bool;
  var $p0: int;
  var $p1: int;
  var $p3: int;
  var $p4: int;
  var $p6: int;

  $bb0:
    assume {:sourceloc "driver.re.c", 155, 2} true;
    call $p0 := printk#2($pa($pa(.str105, 0, 42), 0, 1), $pa($pa(.str106, 0, 4), 0, 1));
    assume {:sourceloc "driver.re.c", 157, 8} true;
    call $p1 := misc_register(nvram_dev);
    call whoop$checker();
    goto $bb1, $bb3;

  $bb1:
    goto $bb2;

  $bb2:
    return;

  $bb3:
    goto $bb2;
}



procedure {:inline 1} nvram_ioctl(file: int, cmd: int, arg: int) returns ($r: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;



implementation {:inline 1} nvram_ioctl(file: int, cmd: int, arg: int) returns ($r: int)
{
  var $b0: bool;
  var $p1: int;

  $bb0:
    $b0 := cmd == 28739;
    goto $bb1, $bb2;

  $bb1:
    assume $b0;
    assume {:sourceloc "driver.re.c", 117, 3} true;
    call nvram_sync();
    assume {:sourceloc "driver.re.c", 123, 2} true;
    $p1 := 0;
    goto $bb3;

  $bb2:
    assume !$b0;
    assume {:sourceloc "driver.re.c", 120, 3} true;
    $p1 := -22;
    goto $bb3;

  $bb3:
    assume {:sourceloc "driver.re.c", 124, 1} true;
    $r := $p1;
    return;
}



procedure {:inline 1} nvram_read_byte(p#0: int) returns ($r: int);



procedure {:inline 1} nvram_sync();



procedure nvram_unlocked_ioctl(file: int, cmd: int, arg: int) returns ($r: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;



implementation nvram_unlocked_ioctl(file: int, cmd: int, arg: int) returns ($r: int)
{
  var $p0: int;
  var $p1: int;

  $bb0:
    assume {:sourceloc "driver.re.c", 130, 2} true;
    yield;
    call mutex_lock(nvram_mutex);
    assume {:sourceloc "driver.re.c", 131, 8} true;
    call $p0 := nvram_ioctl(file, cmd, arg);
    assume {:sourceloc "driver.re.c", 132, 2} true;
    yield;
    call mutex_unlock(nvram_mutex);
    assume {:sourceloc "driver.re.c", 134, 2} true;
    $p1 := $p0;
    assume {:sourceloc "driver.re.c", 134, 2} true;
    $r := $p1;
    return;
}



procedure {:inline 1} nvram_write_byte(p#0: int, p#1: int);



procedure printk#0(p#0: int) returns ($r: int);



procedure printk#2(p#0: int, p#1: int) returns ($r: int);



procedure {:inline 1} timespec_trunc1(ret: int, p#1: int, p#2: int, p#3: int) returns ($r: int);



procedure {:inline 1} whoop$checker();
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;



implementation {:inline 1} whoop$checker()
{
  var $p0: int;
  var $p1: int;
  var $p10: int;
  var $p11: int;
  var $p12: int;
  var $p13: int;
  var $p14: int;
  var $p15: int;
  var $p16: int;
  var $p17: int;
  var $p18: int;
  var $p19: int;
  var $p2: int;
  var $p20: int;
  var $p21: int;
  var $p22: int;
  var $p23: int;
  var $p24: int;
  var $p25: int;
  var $p26: int;
  var $p27: int;
  var $p28: int;
  var $p29: int;
  var $p3: int;
  var $p30: int;
  var $p31: int;
  var $p32: int;
  var $p33: int;
  var $p34: int;
  var $p35: int;
  var $p36: int;
  var $p37: int;
  var $p38: int;
  var $p39: int;
  var $p4: int;
  var $p40: int;
  var $p41: int;
  var $p42: int;
  var $p43: int;
  var $p44: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;
  var $p8: int;
  var $p9: int;

  $bb0:
    assume {:sourceloc "driver.re.c", 180, 49} true;
    call $p1 := $malloc(280);
    assume {:sourceloc "driver.re.c", 180, 49} true;
    $p2 := $p1;
    assume {:sourceloc "driver.re.c", 181, 46} true;
    call $p3 := $malloc(56);
    assume {:sourceloc "driver.re.c", 181, 46} true;
    $p4 := $p3;
    assume {:sourceloc "driver.re.c", 182, 49} true;
    call $p5 := $malloc(280);
    assume {:sourceloc "driver.re.c", 182, 49} true;
    $p6 := $p5;
    assume {:sourceloc "driver.re.c", 183, 46} true;
    call $p7 := $malloc(56);
    assume {:sourceloc "driver.re.c", 183, 46} true;
    $p8 := $p7;
    assume {:sourceloc "driver.re.c", 184, 49} true;
    call $p9 := $malloc(280);
    assume {:sourceloc "driver.re.c", 184, 49} true;
    $p10 := $p9;
    assume {:sourceloc "driver.re.c", 185, 46} true;
    call $p11 := $malloc(56);
    assume {:sourceloc "driver.re.c", 185, 46} true;
    $p12 := $p11;
    assume {:sourceloc "driver.re.c", 186, 49} true;
    call $p13 := $malloc(280);
    assume {:sourceloc "driver.re.c", 186, 49} true;
    $p14 := $p13;
    assume {:sourceloc "driver.re.c", 187, 46} true;
    call $p15 := $malloc(56);
    assume {:sourceloc "driver.re.c", 187, 46} true;
    $p16 := $p15;
    assume {:sourceloc "driver.re.c", 188, 49} true;
    call $p17 := $malloc(280);
    assume {:sourceloc "driver.re.c", 188, 49} true;
    $p18 := $p17;
    assume {:sourceloc "driver.re.c", 189, 46} true;
    call $p19 := $malloc(56);
    assume {:sourceloc "driver.re.c", 189, 46} true;
    $p20 := $p19;
    assume {:sourceloc "driver.re.c", 190, 53} true;
    call $p21 := $malloc(512);
    assume {:sourceloc "driver.re.c", 190, 53} true;
    $p22 := $p21;
    assume {:sourceloc "driver.re.c", 191, 35} true;
    call $p23 := $malloc(1);
    assume {:sourceloc "driver.re.c", 192, 77} true;
    call $p24 := $malloc(168);
    assume {:sourceloc "driver.re.c", 192, 77} true;
    $p25 := $p24;
    assume {:sourceloc "driver.re.c", 193, 74} true;
    call $p26 := $malloc(32);
    assume {:sourceloc "driver.re.c", 193, 74} true;
    $p27 := $p26;
    assume {:sourceloc "driver.re.c", 194, 50} true;
    call $p28 := $malloc(152);
    assume {:sourceloc "driver.re.c", 194, 50} true;
    $p29 := $p28;
    assume {:sourceloc "driver.re.c", 196, 48} true;
    call $p30 := $malloc(4);
    assume {:sourceloc "driver.re.c", 196, 48} true;
    $p31 := $p30;
    assume {:sourceloc "driver.re.c", 198, 36} true;
    call $p32 := $malloc(8);
    assume {:sourceloc "driver.re.c", 198, 36} true;
    $p33 := $p32;
    assume {:sourceloc "driver.re.c", 198, 36} true;
    $M.19[$p0] := $p33;
    assume {:sourceloc "driver.re.c", 199, 18} true;
    call $p34 := __SMACK_nondet();
    assume {:sourceloc "driver.re.c", 200, 2} true;
    assume $p34 >= 0;
    assume {:sourceloc "driver.re.c", 202, 2} true;
    $p35 := $p34;
    assume {:sourceloc "driver.re.c", 202, 2} true;
    $p36 := $M.19[$p0];
    assume {:sourceloc "driver.re.c", 202, 2} true;
    async call write_nvram$ep($p4, $p23, $p35, $p36);
    assume {:sourceloc "driver.re.c", 203, 2} true;
    $p38 := $p34;
    assume {:sourceloc "driver.re.c", 203, 2} true;
    $p39 := $M.19[$p0];
    assume {:sourceloc "driver.re.c", 203, 2} true;
    assume {:sourceloc "driver.re.c", 204, 2} true;
    $p41 := $p34;
    assume {:sourceloc "driver.re.c", 204, 2} true;
    async call nvram_unlocked_ioctl$ep($p12, $p34, $p41);
    assume {:sourceloc "driver.re.c", 205, 2} true;
    $p43 := $p2i($p0);
    assume {:sourceloc "driver.re.c", 205, 2} true;
    assume {:sourceloc "driver.re.c", 206, 2} true;
    assume {:sourceloc "driver.re.c", 207, 1} true;
    return;
}



procedure write_nvram(file: int, buf: int, count: int, ppos: int) returns ($r: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;



implementation write_nvram(file: int, buf: int, count: int, ppos: int) returns ($r: int)
{
  var $b1: bool;
  var $b11: bool;
  var $b14: bool;
  var $b18: bool;
  var $b5: bool;
  var $p0: int;
  var $p10: int;
  var $p12: int;
  var $p13: int;
  var $p15: int;
  var $p17: int;
  var $p2: int;
  var $p20: int;
  var $p21: int;
  var $p22: int;
  var $p23: int;
  var $p24: int;
  var $p25: int;
  var $p26: int;
  var $p3: int;
  var $p4: int;
  var $p6: int;
  var $p7: int;
  var $p8: int;
  var $p9: int;

  $bb0:
    assume {:sourceloc "driver.re.c", 82, 7} true;
    call $p0 := access_ok(0, buf, count);
    assume {:sourceloc "driver.re.c", 82, 7} true;
    $b1 := $p0 != 0;
    assume {:sourceloc "driver.re.c", 82, 7} true;
    goto $bb1, $bb2;

  $bb1:
    assume $b1;
    assume {:sourceloc "driver.re.c", 84, 6} true;
    $p3 := $M.0[ppos];
    assume {:sourceloc "driver.re.c", 84, 6} true;
    $p4 := $M.2;
    assume {:sourceloc "driver.re.c", 84, 6} true;
    $b5 := $sge($p3, $p4);
    assume {:sourceloc "driver.re.c", 84, 6} true;
    goto $bb4, $bb5;

  $bb2:
    assume !$b1;
    assume {:sourceloc "driver.re.c", 83, 3} true;
    $p2 := -14;
    goto $bb3;

  $bb3:
    assume {:sourceloc "driver.re.c", 93, 1} true;
    $r := $p2;
    return;

  $bb4:
    assume $b5;
    assume {:sourceloc "driver.re.c", 85, 3} true;
    $p2 := 0;
    goto $bb3;

  $bb5:
    assume !$b5;
    assume {:sourceloc "driver.re.c", 86, 7} true;
    $p6 := $M.0[ppos];
    assume {:sourceloc "driver.re.c", 86, 7} true;
    $p7 := $trunc($p6, 32);
    assume {:sourceloc "driver.re.c", 86, 7} true;
    $p8 := $p7;
    $p9 := count;
    $p10 := buf;
    goto $bb6;

  $bb6:
    assume {:sourceloc "driver.re.c", 86, 7} true;
    $b11 := $ugt($p9, 0);
    assume {:sourceloc "driver.re.c", 86, 7} true;
    goto $bb7, $bb8;

  $bb7:
    assume $b11;
    assume {:sourceloc "driver.re.c", 86, 7} true;
    $p12 := $p8;
    assume {:sourceloc "driver.re.c", 86, 7} true;
    $p13 := $M.2;
    assume {:sourceloc "driver.re.c", 86, 7} true;
    $b14 := $slt($p12, $p13);
    assume {:sourceloc "driver.re.c", 86, 7} true;
    goto $bb10, $bb11;

  $bb8:
    assume {:sourceloc "driver.re.c", 86, 7} true;
    assume !$b11;
    goto $bb9;

  $bb9:
    assume {:sourceloc "driver.re.c", 91, 2} true;
    $p23 := $p8;
    assume {:sourceloc "driver.re.c", 91, 2} true;
    $M.0[ppos] := $p23;
    assume {:sourceloc "driver.re.c", 92, 2} true;
    $p24 := $p2i($p10);
    assume {:sourceloc "driver.re.c", 92, 2} true;
    $p25 := $p2i(buf);
    assume {:sourceloc "driver.re.c", 92, 2} true;
    $p26 := $sub($p24, $p25);
    assume {:sourceloc "driver.re.c", 92, 2} true;
    $p2 := $p26;
    goto $bb3;

  $bb10:
    assume $b14;
    assume {:sourceloc "driver.re.c", 87, 7} true;
    $p15 := $u16;
    assume {:sourceloc "driver.re.c", 87, 7} true;
    call $p17 := __get_user($p15, $p10);
    assume {:sourceloc "driver.re.c", 87, 7} true;
    $b18 := $p17 != 0;
    assume {:sourceloc "driver.re.c", 87, 7} true;
    goto $bb12, $bb13;

  $bb11:
    assume {:sourceloc "driver.re.c", 86, 7} true;
    assume !$b14;
    goto $bb9;

  $bb12:
    assume $b18;
    assume {:sourceloc "driver.re.c", 88, 4} true;
    $p2 := -14;
    goto $bb3;

  $bb13:
    assume !$b18;
    assume {:sourceloc "driver.re.c", 89, 3} true;
    call nvram_write_byte($u19, $p8);
    assume {:sourceloc "driver.re.c", 86, 46} true;
    $p20 := $add($p8, 1);
    assume {:sourceloc "driver.re.c", 86, 46} true;
    $p21 := $pa($p10, 1, 1);
    assume {:sourceloc "driver.re.c", 86, 46} true;
    $p22 := $add($p9, -1);
    assume {:sourceloc "driver.re.c", 86, 46} true;
    $p8 := $p20;
    $p9 := $p22;
    $p10 := $p21;
    goto $bb6;
}



axiom __SMACK_nondet.XXX == -34;

axiom nvram_len == -5180;

axiom nvram_mutex == -5188;

axiom nvram_fops == -5388;

axiom nvram_dev == -5458;

axiom _whoop_init == -5466;

axiom _whoop_exit == -5474;

axiom jiffies == -5497;

axiom $NULL == 0;

axiom $and(0, 0) == 0;

axiom $and(0, 1) == 0;

axiom $and(1, 0) == 0;

axiom $and(1, 1) == 1;

axiom $or(0, 0) == 0;

axiom $or(0, 1) == 1;

axiom $or(1, 0) == 1;

axiom $or(1, 1) == 1;

axiom $xor(0, 0) == 0;

axiom $xor(0, 1) == 1;

axiom $xor(1, 0) == 1;

axiom $xor(1, 1) == 0;

axiom (forall f1: float, f2: float :: f1 != f2 || $foeq(f1, f2));

axiom (forall f: float :: $si2fp($fp2si(f)) == f);

axiom (forall f: float :: $ui2fp($fp2ui(f)) == f);

axiom (forall i: int :: $fp2si($si2fp(i)) == i);

axiom (forall i: int :: $fp2ui($ui2fp(i)) == i);

const $GLOBALS_BOTTOM: int;

const $MOP: $mop;

const $UNDEF: int;

const unique $NULL: int;

function $and(p1: int, p2: int) : int;

function $ashr(p1: int, p2: int) : int;

function $base(int) : int;

function $extractvalue(p: int, i: int) : int;

function $fadd(f1: float, f2: float) : float;

function $fdiv(f1: float, f2: float) : float;

function $ffalse(f1: float, f2: float) : bool;

function $fmul(f1: float, f2: float) : float;

function $foeq(f1: float, f2: float) : bool;

function $foge(f1: float, f2: float) : bool;

function $fogt(f1: float, f2: float) : bool;

function $fole(f1: float, f2: float) : bool;

function $folt(f1: float, f2: float) : bool;

function $fone(f1: float, f2: float) : bool;

function $ford(f1: float, f2: float) : bool;

function $fp(ipart: int, fpart: int, epart: int) : float;

function $fp2si(f: float) : int;

function $fp2ui(f: float) : int;

function $frem(f1: float, f2: float) : float;

function $fsub(f1: float, f2: float) : float;

function $ftrue(f1: float, f2: float) : bool;

function $fueq(f1: float, f2: float) : bool;

function $fuge(f1: float, f2: float) : bool;

function $fugt(f1: float, f2: float) : bool;

function $fule(f1: float, f2: float) : bool;

function $fult(f1: float, f2: float) : bool;

function $fune(f1: float, f2: float) : bool;

function $funo(f1: float, f2: float) : bool;

function $lshr(p1: int, p2: int) : int;

function $nand(p1: int, p2: int) : int;

function $or(p1: int, p2: int) : int;

function $shl(p1: int, p2: int) : int;

function $si2fp(i: int) : float;

function $ui2fp(i: int) : float;

function $xor(p1: int, p2: int) : int;

function {:builtin "div"} $sdiv(p1: int, p2: int) : int;

function {:builtin "div"} $udiv(p1: int, p2: int) : int;

function {:builtin "rem"} $srem(p1: int, p2: int) : int;

function {:builtin "rem"} $urem(p1: int, p2: int) : int;

function {:inline} $add(p1: int, p2: int) : int
{
  p1 + p2
}

function {:inline} $b2i(b: bool) : int
{
  (if b then 1 else 0)
}

function {:inline} $b2p(b: bool) : int
{
  (if b then 1 else 0)
}

function {:inline} $i2b(i: int) : bool
{
  i != 0
}

function {:inline} $i2p(p: int) : int
{
  p
}

function {:inline} $isExternal(p: int) : bool
{
  p < $GLOBALS_BOTTOM - 32768
}

function {:inline} $max(p1: int, p2: int) : int
{
  (if p1 > p2 then p1 else p2)
}

function {:inline} $min(p1: int, p2: int) : int
{
  (if p1 > p2 then p2 else p1)
}

function {:inline} $mul(p1: int, p2: int) : int
{
  p1 * p2
}

function {:inline} $p2b(p: int) : bool
{
  p != 0
}

function {:inline} $p2i(p: int) : int
{
  p
}

function {:inline} $pa(pointer: int, index: int, size: int) : int
{
  pointer + index * size
}

function {:inline} $sge(p1: int, p2: int) : bool
{
  p1 >= p2
}

function {:inline} $sgt(p1: int, p2: int) : bool
{
  p1 > p2
}

function {:inline} $sle(p1: int, p2: int) : bool
{
  p1 <= p2
}

function {:inline} $slt(p1: int, p2: int) : bool
{
  p1 < p2
}

function {:inline} $sub(p1: int, p2: int) : int
{
  p1 - p2
}

function {:inline} $trunc(p: int, size: int) : int
{
  p
}

function {:inline} $uge(p1: int, p2: int) : bool
{
  p1 >= p2
}

function {:inline} $ugt(p1: int, p2: int) : bool
{
  p1 > p2
}

function {:inline} $ule(p1: int, p2: int) : bool
{
  p1 <= p2
}

function {:inline} $ult(p1: int, p2: int) : bool
{
  p1 < p2
}

function {:inline} $umax(p1: int, p2: int) : int
{
  (if p1 > p2 then p1 else p2)
}

function {:inline} $umin(p1: int, p2: int) : int
{
  (if p1 > p2 then p2 else p1)
}

procedure {:inline 1} $malloc(n: int) returns (p: int);
  modifies $CurrAddr, $Alloc;



implementation {:inline 1} $malloc(n: int) returns (p: int)
{
  anon0:
    assume $CurrAddr > 0;
    p := $CurrAddr;
    goto anon4_Then, anon4_Else;

  anon4_Then:
    assume {:partition} n > 0;
    $CurrAddr := $CurrAddr + n;
    goto anon3;

  anon4_Else:
    assume {:partition} 0 >= n;
    $CurrAddr := $CurrAddr + 1;
    goto anon3;

  anon3:
    $Alloc[p] := true;
    return;
}



procedure $memcpy.36.36(dest: int, src: int, len: int, align: int, isvolatile: bool);
  modifies $M.36;



procedure {:inline 1} boogie_si_record_bool(b: bool);



procedure {:inline 1} boogie_si_record_float(f: float);



procedure {:inline 1} boogie_si_record_int(i: int);



procedure {:inline 1} boogie_si_record_mop(m: $mop);



type $mop;

type float;

var $Alloc: [int]bool;

var $CurrAddr: int;

var $exn: bool;

var $exnv: int;

procedure write_nvram$ep($p4: int, $p23: int, $p35: int, $p36: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;



implementation write_nvram$ep($p4: int, $p23: int, $p35: int, $p36: int)
{
  var $p37: int;

  _EP:
    call $p37 := write_nvram($p4, $p23, $p35, $p36);
    return;
}



procedure nvram_unlocked_ioctl$ep($p12: int, $p34: int, $p41: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;



implementation nvram_unlocked_ioctl$ep($p12: int, $p34: int, $p41: int)
{
  var $p42: int;

  _EP:
    call $p42 := nvram_unlocked_ioctl($p12, $p34, $p41);
    return;
}


