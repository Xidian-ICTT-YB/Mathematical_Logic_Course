procedure corral_atomic_begin();



procedure corral_atomic_end();



procedure corral_getThreadID() returns (t: int);



var $M.0: [int]int;

var $M.1: int;

var $M.2: int;

var $M.3: [int]int;

var $M.4: [int]int;

var $M.5: [int]int;

var $M.6: [int]int;

var $M.7: int;

var $M.8: [int]int;

var $M.9: [int]int;

var $M.10: [int]int;

var $M.11: int;

var $M.12: int;

var $M.13: [int]int;

var $M.14: [int]int;

var $M.15: [int]int;

var $M.16: [int]int;

var $M.17: [int]int;

var $M.18: [int]int;

var $M.19: [int]int;

var $M.20: [int]int;

var $M.21: [int]int;

var $M.22: [int]int;

var $M.23: [int]int;

var $M.24: [int]int;

var $M.25: [int]int;

var $M.26: [int]int;

var $M.27: [int]int;

var $M.28: [int]int;

var $M.29: [int]int;

var $M.30: [int]int;

var $M.31: [int]int;

var $M.32: [int]int;

var $M.33: [int]int;

var $M.34: [int]int;

var $M.35: [int]int;

var $M.36: [int]int;

var $M.37: [int]int;

var $M.38: [int]int;

var $M.39: [int]int;

var $M.40: [int]int;

var $M.41: [int]int;

var $M.42: [int]int;

var $M.43: [int]int;

var $M.44: [int]int;

var $M.45: [int]int;

var $M.46: [int]int;

var $M.47: [int]int;

var $M.48: [int]int;

var $M.49: [int]int;

var $M.50: [int]int;

var $M.51: [int]int;

var $M.52: [int]int;

var $M.53: [int]int;

var $M.54: [int]int;

axiom $GLOBALS_BOTTOM == -5949;

const unique .str: int;

const unique .str1: int;

const unique .str10: int;

const unique .str100: int;

const unique .str101: int;

const unique .str102: int;

const unique .str103: int;

const unique .str104: int;

const unique .str105: int;

const unique .str106: int;

const unique .str107: int;

const unique .str108: int;

const unique .str109: int;

const unique .str11: int;

const unique .str110: int;

const unique .str111: int;

const unique .str112: int;

const unique .str113: int;

const unique .str114: int;

const unique .str115: int;

const unique .str116: int;

const unique .str117: int;

const unique .str118: int;

const unique .str119: int;

const unique .str12: int;

const unique .str120: int;

const unique .str13: int;

const unique .str14: int;

const unique .str15: int;

const unique .str16: int;

const unique .str17: int;

const unique .str18: int;

const unique .str19: int;

const unique .str2: int;

const unique .str20: int;

const unique .str21: int;

const unique .str22: int;

const unique .str23: int;

const unique .str24: int;

const unique .str25: int;

const unique .str26: int;

const unique .str27: int;

const unique .str28: int;

const unique .str29: int;

const unique .str3: int;

const unique .str30: int;

const unique .str31: int;

const unique .str32: int;

const unique .str33: int;

const unique .str34: int;

const unique .str35: int;

const unique .str36: int;

const unique .str37: int;

const unique .str38: int;

const unique .str39: int;

const unique .str4: int;

const unique .str40: int;

const unique .str41: int;

const unique .str42: int;

const unique .str43: int;

const unique .str44: int;

const unique .str45: int;

const unique .str46: int;

const unique .str47: int;

const unique .str48: int;

const unique .str49: int;

const unique .str5: int;

const unique .str50: int;

const unique .str51: int;

const unique .str52: int;

const unique .str53: int;

const unique .str54: int;

const unique .str55: int;

const unique .str56: int;

const unique .str57: int;

const unique .str58: int;

const unique .str59: int;

const unique .str6: int;

const unique .str60: int;

const unique .str61: int;

const unique .str62: int;

const unique .str63: int;

const unique .str64: int;

const unique .str65: int;

const unique .str66: int;

const unique .str67: int;

const unique .str68: int;

const unique .str69: int;

const unique .str7: int;

const unique .str70: int;

const unique .str71: int;

const unique .str72: int;

const unique .str73: int;

const unique .str74: int;

const unique .str75: int;

const unique .str76: int;

const unique .str77: int;

const unique .str78: int;

const unique .str79: int;

const unique .str8: int;

const unique .str80: int;

const unique .str81: int;

const unique .str82: int;

const unique .str83: int;

const unique .str84: int;

const unique .str85: int;

const unique .str86: int;

const unique .str87: int;

const unique .str88: int;

const unique .str89: int;

const unique .str9: int;

const unique .str90: int;

const unique .str91: int;

const unique .str92: int;

const unique .str93: int;

const unique .str94: int;

const unique .str95: int;

const unique .str96: int;

const unique .str97: int;

const unique .str98: int;

const unique .str99: int;

const unique MAJOR: int;

const unique MINOR: int;

const unique MKDEV: int;

const unique __SMACK_decls: int;

const unique __SMACK_nondet: int;

const unique __SMACK_nondet.XXX: int;

const unique _whoop_exit: int;

const unique _whoop_init: int;

const unique alloc_chrdev_region: int;

const unique cdev_add: int;

const unique cdev_del: int;

const unique cdev_init: int;

const unique current_kernel_time2: int;

const unique dev_dbg: int;

const unique dev_err: int;

const unique dev_info: int;

const unique device_select: int;

const unique gpio_shadow_lock: int;

const unique inb_p: int;

const unique jiffies: int;

const unique major: int;

const unique malloc: int;

const unique mutex_lock: int;

const unique mutex_unlock: int;

const unique no_llseek: int;

const unique nonseekable_open: int;

const unique nsc_gpio_dump: int;

const unique nsc_gpio_read: int;

const unique nsc_gpio_write: int;

const unique outb_p: int;

const unique pc8736x_gpio_base: int;

const unique pc8736x_gpio_cdev: int;

const unique pc8736x_gpio_change: int;

const unique pc8736x_gpio_config_lock: int;

const unique pc8736x_gpio_current: int;

const unique pc8736x_gpio_fileops: int;

const unique pc8736x_gpio_init: int;

const unique pc8736x_gpio_ops: int;

const unique pc8736x_gpio_set: int;

const {:count 4} unique pc8736x_gpio_shadow: int;

const unique pc8736x_init_shadow: int;

const unique pc8736x_superio_present: int;

const unique pdev: int;

const unique platform_device_add: int;

const unique platform_device_alloc: int;

const unique platform_device_del: int;

const unique platform_device_put: int;

const unique platform_device_unregister: int;

const {:count 4} unique port_offset: int;

const unique register_chrdev_region: int;

const unique release_region: int;

const unique request_region: int;

const unique selected_device: int;

const unique superio_cmd: int;

const unique timespec_trunc1: int;

const unique unregister_chrdev_region: int;

const unique whoop$checker: int;

procedure MAJOR#0() returns ($r: int);



procedure MAJOR#1(p#0: int) returns ($r: int);



procedure MINOR#0() returns ($r: int);



procedure MINOR#1(p#0: int) returns ($r: int);



procedure MKDEV#0() returns ($r: int);



procedure MKDEV#2(p#0: int, p#1: int) returns ($r: int);



procedure {:inline 1} __SMACK_nondet() returns ($r: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;



implementation {:inline 1} __SMACK_nondet() returns ($r: int)
{
  var $p0: int;

  $bb0:
    assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 53, 3} true;
    $p0 := $M.1;
    assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 54, 3} true;
    havoc $p0;
    assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 55, 3} true;
    $r := $p0;
    return;
}



procedure {:inline 1} alloc_chrdev_region(p#0: int, p#1: int, p#2: int, p#3: int) returns ($r: int);



procedure {:inline 1} cdev_add(p#0: int, p#1: int, p#2: int) returns ($r: int);



procedure {:inline 1} cdev_del(p#0: int);



procedure {:inline 1} cdev_init(p#0: int, p#1: int);



procedure {:inline 1} current_kernel_time2(ret: int) returns ($r: int);



procedure dev_dbg#0() returns ($r: int);



procedure dev_dbg#2(p#0: int, p#1: int) returns ($r: int);



procedure dev_dbg#3(p#0: int, p#1: int, p#2: int) returns ($r: int);



procedure dev_dbg#4(p#0: int, p#1: int, p#2: int, p#3: int) returns ($r: int);



procedure dev_dbg#6(p#0: int, p#1: int, p#2: int, p#3: int, p#4: int, p#5: int) returns ($r: int);



procedure dev_dbg#7(p#0: int, p#1: int, p#2: int, p#3: int, p#4: int, p#5: int, p#6: int)
   returns ($r: int);



procedure dev_dbg#8(p#0: int, p#1: int, p#2: int, p#3: int, p#4: int, p#5: int, p#6: int, p#7: int)
   returns ($r: int);



procedure dev_err#0() returns ($r: int);



procedure dev_err#2(p#0: int, p#1: int) returns ($r: int);



procedure dev_err#3(p#0: int, p#1: int, p#2: int) returns ($r: int);



procedure dev_info#0() returns ($r: int);



procedure dev_info#2(p#0: int, p#1: int) returns ($r: int);



procedure dev_info#3(p#0: int, p#1: int, p#2: int) returns ($r: int);



procedure {:inline 1} device_select(devldn: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;



implementation {:inline 1} device_select(devldn: int)
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
  var $p4: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;

  $bb0:
    assume {:sourceloc "driver.re.c", 85, 2} true;
    $p0 := $trunc(7, 8);
    assume {:sourceloc "driver.re.c", 85, 2} true;
    $p1 := $M.12;
    assume {:sourceloc "driver.re.c", 85, 2} true;
    $p2 := $p1;
    assume {:sourceloc "driver.re.c", 85, 2} true;
    call outb_p($p0, $p2);
    assume {:sourceloc "driver.re.c", 86, 2} true;
    $p3 := $trunc(devldn, 8);
    assume {:sourceloc "driver.re.c", 86, 2} true;
    $p4 := $M.12;
    assume {:sourceloc "driver.re.c", 86, 2} true;
    $p5 := $p4;
    assume {:sourceloc "driver.re.c", 86, 2} true;
    $p6 := $add($p5, 1);
    assume {:sourceloc "driver.re.c", 86, 2} true;
    call outb_p($p3, $p6);
    assume {:sourceloc "driver.re.c", 116, 2} true;
    $p7 := $trunc(devldn, 8);
    assume {:sourceloc "driver.re.c", 116, 2} true;
    $M.11 := $p7;
    assume {:sourceloc "driver.re.c", 117, 1} true;
    return;
}



procedure {:inline 1} inb_p(p#0: int) returns ($r: int);



procedure {:inline 1} mutex_lock(lock: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;



implementation {:inline 1} mutex_lock(lock: int)
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;

  $bb0:
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 35, 12} true;
    call $p0 := __SMACK_nondet();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 36, 2} true;
    call $p0 := corral_getThreadID();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 38, 2} true;
    call corral_atomic_begin();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 39, 2} true;
    $p1 := $pa($pa(lock, 0, 8), 4, 1);
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 39, 2} true;
    $p2 := $M.5[$p1];
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 39, 2} true;
    assume $p2 == 0;
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 40, 2} true;
    $p3 := $pa($pa(lock, 0, 8), 4, 1);
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 40, 2} true;
    $M.5[$p3] := $p0;
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 41, 2} true;
    call corral_atomic_end();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 42, 1} true;
    return;
}



procedure {:inline 1} mutex_unlock(lock: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;



implementation {:inline 1} mutex_unlock(lock: int)
{
  var $p0: int;
  var $p1: int;

  $bb0:
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 61, 12} true;
    call $p0 := __SMACK_nondet();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 62, 2} true;
    call $p0 := corral_getThreadID();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 64, 2} true;
    call corral_atomic_begin();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 65, 2} true;
    $p1 := $pa($pa(lock, 0, 8), 4, 1);
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 65, 2} true;
    $M.5[$p1] := 0;
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 66, 2} true;
    call corral_atomic_end();
    assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 67, 1} true;
    return;
}



procedure {:inline 1} no_llseek(p#0: int, p#1: int, p#2: int) returns ($r: int);



procedure {:inline 1} nonseekable_open(p#0: int, p#1: int) returns ($r: int);



procedure {:inline 1} nsc_gpio_dump(p#0: int, p#1: int);



procedure {:inline 1} nsc_gpio_read(p#0: int, p#1: int, p#2: int, p#3: int) returns ($r: int);



procedure {:inline 1} nsc_gpio_write(p#0: int, p#1: int, p#2: int, p#3: int) returns ($r: int);



procedure {:inline 1} outb_p(p#0: int, p#1: int);



procedure pc8736x_gpio_change(index: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;



implementation pc8736x_gpio_change(index: int)
{
  var $b1: bool;
  var $b2: bool;
  var $p0: int;
  var $p3: int;

  $bb0:
    assume {:sourceloc "driver.re.c", 212, 27} true;
    call $p0 := pc8736x_gpio_current(index);
    assume {:sourceloc "driver.re.c", 212, 27} true;
    $b1 := $p0 != 0;
    assume {:sourceloc "driver.re.c", 212, 27} true;
    $b2 := $i2b($xor($b2i($b1), $b2i(true)));
    assume {:sourceloc "driver.re.c", 212, 27} true;
    $p3 := $b2p($b2);
    assume {:sourceloc "driver.re.c", 212, 2} true;
    call pc8736x_gpio_set(index, $p3);
    assume {:sourceloc "driver.re.c", 213, 1} true;
    return;
}



procedure pc8736x_gpio_current(minor: int) returns ($r: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;



implementation pc8736x_gpio_current(minor: int) returns ($r: int)
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
  var $p4: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;
  var $p8: int;

  $bb0:
    assume {:sourceloc "driver.re.c", 204, 2} true;
    $p0 := $and(minor, 31);
    assume {:sourceloc "driver.re.c", 205, 2} true;
    $p1 := $lshr($p0, 3);
    assume {:sourceloc "driver.re.c", 206, 2} true;
    $p2 := $and($p0, 7);
    assume {:sourceloc "driver.re.c", 207, 2} true;
    $p3 := $p1;
    assume {:sourceloc "driver.re.c", 207, 2} true;
    $p4 := $pa($pa(pc8736x_gpio_shadow, 0, 4), $p3, 1);
    assume {:sourceloc "driver.re.c", 207, 2} true;
    $p5 := $M.6[$p4];
    yield;
    assert $p5 == $M.6[$p4];
    assume {:sourceloc "driver.re.c", 207, 2} true;
    $p6 := $p5;
    assume {:sourceloc "driver.re.c", 207, 2} true;
    $p7 := $ashr($p6, $p2);
    assume {:sourceloc "driver.re.c", 207, 2} true;
    $p8 := $and($p7, 1);
    assume {:sourceloc "driver.re.c", 207, 2} true;
    $r := $p8;
    return;
}



procedure {:entrypoint} pc8736x_gpio_init() returns ($r: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;



implementation {:entrypoint} pc8736x_gpio_init() returns ($r: int)
{
  var $b15: bool;
  var $b31: bool;
  var $b43: bool;
  var $b5: bool;
  var $b67: bool;
  var $b77: bool;
  var $b86: bool;
  var $b9: bool;
  var $b93: bool;
  var $p0: int;
  var $p1: int;
  var $p10: int;
  var $p100: int;
  var $p101: int;
  var $p102: int;
  var $p103: int;
  var $p11: int;
  var $p12: int;
  var $p13: int;
  var $p14: int;
  var $p16: int;
  var $p17: int;
  var $p18: int;
  var $p19: int;
  var $p2: int;
  var $p20: int;
  var $p21: int;
  var $p22: int;
  var $p23: int;
  var $p24: int;
  var $p25: int;
  var $p26: int;
  var $p27: int;
  var $p28: int;
  var $p29: int;
  var $p3: int;
  var $p30: int;
  var $p32: int;
  var $p33: int;
  var $p34: int;
  var $p35: int;
  var $p36: int;
  var $p37: int;
  var $p38: int;
  var $p39: int;
  var $p4: int;
  var $p40: int;
  var $p41: int;
  var $p42: int;
  var $p44: int;
  var $p45: int;
  var $p46: int;
  var $p47: int;
  var $p48: int;
  var $p49: int;
  var $p50: int;
  var $p51: int;
  var $p52: int;
  var $p53: int;
  var $p54: int;
  var $p55: int;
  var $p56: int;
  var $p57: int;
  var $p58: int;
  var $p59: int;
  var $p6: int;
  var $p60: int;
  var $p61: int;
  var $p62: int;
  var $p63: int;
  var $p64: int;
  var $p65: int;
  var $p66: int;
  var $p68: int;
  var $p69: int;
  var $p7: int;
  var $p70: int;
  var $p71: int;
  var $p72: int;
  var $p73: int;
  var $p74: int;
  var $p75: int;
  var $p76: int;
  var $p78: int;
  var $p79: int;
  var $p8: int;
  var $p80: int;
  var $p81: int;
  var $p82: int;
  var $p83: int;
  var $p84: int;
  var $p85: int;
  var $p87: int;
  var $p88: int;
  var $p89: int;
  var $p90: int;
  var $p91: int;
  var $p92: int;
  var $p94: int;
  var $p95: int;
  var $p96: int;
  var $p97: int;
  var $p98: int;
  var $p99: int;

  $bb0:
    call $p0 := $alloca($mul(4, 1));
    assume {:sourceloc "driver.re.c", 264, 9} true;
    call $p1 := platform_device_alloc#2($pa($pa(.str110, 0, 13), 0, 1), 0);
    assume {:sourceloc "driver.re.c", 264, 9} true;
    $p2 := $p1;
    assume {:sourceloc "driver.re.c", 264, 9} true;
    $p3 := $i2p($p2);
    assume {:sourceloc "driver.re.c", 264, 9} true;
    $M.4[pdev] := $p3;
    yield;
    assert $M.4[pdev] == $p3;
    assume {:sourceloc "driver.re.c", 265, 6} true;
    $p4 := $M.4[pdev];
    yield;
    assert $p4 == $M.4[pdev];
    assume {:sourceloc "driver.re.c", 265, 6} true;
    $b5 := $p4 != 0;
    assume {:sourceloc "driver.re.c", 265, 6} true;
    goto $bb1, $bb2;

  $bb1:
    assume $b5;
    assume {:sourceloc "driver.re.c", 268, 7} true;
    $p7 := $M.4[pdev];
    yield;
    assert $p7 == $M.4[pdev];
    assume {:sourceloc "driver.re.c", 268, 7} true;
    call $p8 := platform_device_add#1($p7);
    assume {:sourceloc "driver.re.c", 269, 6} true;
    $b9 := $p8 != 0;
    assume {:sourceloc "driver.re.c", 269, 6} true;
    goto $bb4, $bb5;

  $bb2:
    assume !$b5;
    assume {:sourceloc "driver.re.c", 266, 3} true;
    $p6 := -12;
    goto $bb3;

  $bb3:
    assume {:sourceloc "driver.re.c", 343, 1} true;
    $r := $p6;
    call whoop$checker();
    return;

  $bb4:
    assume $b9;
    assume {:sourceloc "driver.re.c", 271, 3} true;
    $p10 := -19;
    goto $bb6;

  $bb5:
    assume !$b9;
    assume {:sourceloc "driver.re.c", 273, 2} true;
    $p11 := $M.4[pdev];
    yield;
    assert $p11 == $M.4[pdev];
    assume {:sourceloc "driver.re.c", 273, 2} true;
    $p12 := $pa($pa($p11, 0, 168), 16, 1);
    assume {:sourceloc "driver.re.c", 273, 2} true;
    call $p13 := dev_info#2($p12, $pa($pa(.str111, 0, 42), 0, 1));
    assume {:sourceloc "driver.re.c", 275, 7} true;
    call $p14 := pc8736x_superio_present();
    assume {:sourceloc "driver.re.c", 275, 7} true;
    $b15 := $p14 != 0;
    assume {:sourceloc "driver.re.c", 275, 7} true;
    goto $bb7, $bb8;

  $bb6:
    assume {:sourceloc "driver.re.c", 340, 2} true;
    $p102 := $M.4[pdev];
    yield;
    assert $p102 == $M.4[pdev];
    assume {:sourceloc "driver.re.c", 340, 2} true;
    call $p103 := platform_device_put#1($p102);
    assume {:sourceloc "driver.re.c", 342, 2} true;
    $p6 := $p10;
    goto $bb3;

  $bb7:
    assume $b15;
    assume {:sourceloc "driver.re.c", 280, 2} true;
    $p20 := $M.4[pdev];
    yield;
    assert $p20 == $M.4[pdev];
    assume {:sourceloc "driver.re.c", 280, 2} true;
    $p21 := $pa($pa($p20, 0, 168), 16, 1);
    assume {:sourceloc "driver.re.c", 280, 2} true;
    $M.0[$pa($pa(pc8736x_gpio_ops, 0, 64), 56, 1)] := $p21;
    assume {:sourceloc "driver.re.c", 91, 2} true;
    $p22 := $trunc(33, 8);
    assume {:sourceloc "driver.re.c", 91, 2} true;
    $p23 := $M.12;
    assume {:sourceloc "driver.re.c", 91, 2} true;
    $p24 := $p23;
    assume {:sourceloc "driver.re.c", 91, 2} true;
    call outb_p($p22, $p24);
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p25 := $M.12;
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p26 := $p25;
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p27 := $add($p26, 1);
    assume {:sourceloc "driver.re.c", 92, 9} true;
    call $p28 := inb_p($p27);
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p29 := $p28;
    assume {:sourceloc "driver.re.c", 286, 6} true;
    $p30 := $and($p29, 1);
    assume {:sourceloc "driver.re.c", 286, 6} true;
    $b31 := $p30 != 0;
    assume {:sourceloc "driver.re.c", 286, 6} true;
    goto $bb10, $bb11;

  $bb8:
    assume !$b15;
    assume {:sourceloc "driver.re.c", 277, 3} true;
    $p16 := $M.4[pdev];
    yield;
    assert $p16 == $M.4[pdev];
    assume {:sourceloc "driver.re.c", 277, 3} true;
    $p17 := $pa($pa($p16, 0, 168), 16, 1);
    assume {:sourceloc "driver.re.c", 277, 3} true;
    call $p18 := dev_err#2($p17, $pa($pa(.str112, 0, 17), 0, 1));
    assume {:sourceloc "driver.re.c", 278, 3} true;
    $p19 := -19;
    goto $bb9;

  $bb9:
    assume {:sourceloc "driver.re.c", 338, 2} true;
    $p100 := $M.4[pdev];
    yield;
    assert $p100 == $M.4[pdev];
    assume {:sourceloc "driver.re.c", 338, 2} true;
    call $p101 := platform_device_del#1($p100);
    assume {:sourceloc "driver.re.c", 338, 2} true;
    $p10 := $p19;
    goto $bb6;

  $bb10:
    assume $b31;
    assume {:sourceloc "driver.re.c", 291, 2} true;
    call device_select(7);
    assume {:sourceloc "driver.re.c", 91, 2} true;
    $p35 := $trunc(48, 8);
    assume {:sourceloc "driver.re.c", 91, 2} true;
    $p36 := $M.12;
    assume {:sourceloc "driver.re.c", 91, 2} true;
    $p37 := $p36;
    assume {:sourceloc "driver.re.c", 91, 2} true;
    call outb_p($p35, $p37);
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p38 := $M.12;
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p39 := $p38;
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p40 := $add($p39, 1);
    assume {:sourceloc "driver.re.c", 92, 9} true;
    call $p41 := inb_p($p40);
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p42 := $p41;
    assume {:sourceloc "driver.re.c", 292, 7} true;
    $b43 := $p42 != 0;
    assume {:sourceloc "driver.re.c", 292, 7} true;
    goto $bb12, $bb13;

  $bb11:
    assume !$b31;
    assume {:sourceloc "driver.re.c", 288, 3} true;
    $p32 := $M.4[pdev];
    yield;
    assert $p32 == $M.4[pdev];
    assume {:sourceloc "driver.re.c", 288, 3} true;
    $p33 := $pa($pa($p32, 0, 168), 16, 1);
    assume {:sourceloc "driver.re.c", 288, 3} true;
    call $p34 := dev_err#2($p33, $pa($pa(.str113, 0, 20), 0, 1));
    assume {:sourceloc "driver.re.c", 289, 3} true;
    $p19 := -19;
    goto $bb9;

  $bb12:
    assume $b43;
    assume {:sourceloc "driver.re.c", 91, 2} true;
    $p47 := $trunc(96, 8);
    assume {:sourceloc "driver.re.c", 91, 2} true;
    $p48 := $M.12;
    assume {:sourceloc "driver.re.c", 91, 2} true;
    $p49 := $p48;
    assume {:sourceloc "driver.re.c", 91, 2} true;
    call outb_p($p47, $p49);
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p50 := $M.12;
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p51 := $p50;
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p52 := $add($p51, 1);
    assume {:sourceloc "driver.re.c", 92, 9} true;
    call $p53 := inb_p($p52);
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p54 := $p53;
    assume {:sourceloc "driver.re.c", 299, 23} true;
    $p55 := $shl($p54, 8);
    assume {:sourceloc "driver.re.c", 91, 2} true;
    $p56 := $trunc(97, 8);
    assume {:sourceloc "driver.re.c", 91, 2} true;
    $p57 := $M.12;
    assume {:sourceloc "driver.re.c", 91, 2} true;
    $p58 := $p57;
    assume {:sourceloc "driver.re.c", 91, 2} true;
    call outb_p($p56, $p58);
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p59 := $M.12;
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p60 := $p59;
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p61 := $add($p60, 1);
    assume {:sourceloc "driver.re.c", 92, 9} true;
    call $p62 := inb_p($p61);
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p63 := $p62;
    assume {:sourceloc "driver.re.c", 300, 11} true;
    $p64 := $or($p55, $p63);
    assume {:sourceloc "driver.re.c", 300, 11} true;
    $M.2 := $p64;
    yield;
    assert $M.2 == $p64;
    assume {:sourceloc "driver.re.c", 302, 7} true;
    $p65 := $M.2;
    yield;
    assert $p65 == $M.2;
    assume {:sourceloc "driver.re.c", 302, 7} true;
    call $p66 := request_region#3($p65, 16, $pa($pa(.str110, 0, 13), 0, 1));
    assume {:sourceloc "driver.re.c", 302, 7} true;
    $b67 := $p66 != 0;
    assume {:sourceloc "driver.re.c", 302, 7} true;
    goto $bb14, $bb15;

  $bb13:
    assume !$b43;
    assume {:sourceloc "driver.re.c", 294, 3} true;
    $p44 := $M.4[pdev];
    yield;
    assert $p44 == $M.4[pdev];
    assume {:sourceloc "driver.re.c", 294, 3} true;
    $p45 := $pa($pa($p44, 0, 168), 16, 1);
    assume {:sourceloc "driver.re.c", 294, 3} true;
    call $p46 := dev_err#2($p45, $pa($pa(.str114, 0, 23), 0, 1));
    assume {:sourceloc "driver.re.c", 295, 3} true;
    $p19 := -19;
    goto $bb9;

  $bb14:
    assume $b67;
    assume {:sourceloc "driver.re.c", 308, 2} true;
    $p72 := $M.4[pdev];
    yield;
    assert $p72 == $M.4[pdev];
    assume {:sourceloc "driver.re.c", 308, 2} true;
    $p73 := $pa($pa($p72, 0, 168), 16, 1);
    assume {:sourceloc "driver.re.c", 308, 2} true;
    $p74 := $M.2;
    yield;
    assert $p74 == $M.2;
    assume {:sourceloc "driver.re.c", 308, 2} true;
    call $p75 := dev_info#3($p73, $pa($pa(.str116, 0, 25), 0, 1), $p74);
    assume {:sourceloc "driver.re.c", 310, 6} true;
    $p76 := $M.7;
    assume {:sourceloc "driver.re.c", 310, 6} true;
    $b77 := $p76 != 0;
    assume {:sourceloc "driver.re.c", 310, 6} true;
    goto $bb16, $bb17;

  $bb15:
    assume !$b67;
    assume {:sourceloc "driver.re.c", 304, 3} true;
    $p68 := $M.4[pdev];
    yield;
    assert $p68 == $M.4[pdev];
    assume {:sourceloc "driver.re.c", 304, 3} true;
    $p69 := $pa($pa($p68, 0, 168), 16, 1);
    assume {:sourceloc "driver.re.c", 304, 3} true;
    $p70 := $M.2;
    yield;
    assert $p70 == $M.2;
    assume {:sourceloc "driver.re.c", 304, 3} true;
    call $p71 := dev_err#3($p69, $pa($pa(.str115, 0, 21), 0, 1), $p70);
    assume {:sourceloc "driver.re.c", 306, 3} true;
    $p19 := -19;
    goto $bb9;

  $bb16:
    assume $b77;
    assume {:sourceloc "driver.re.c", 311, 11} true;
    $p78 := $M.7;
    assume {:sourceloc "driver.re.c", 311, 11} true;
    call $p79 := MKDEV#2($p78, 0);
    assume {:sourceloc "driver.re.c", 311, 11} true;
    $M.0[$p0] := $p79;
    assume {:sourceloc "driver.re.c", 312, 8} true;
    $p80 := $M.0[$p0];
    assume {:sourceloc "driver.re.c", 312, 8} true;
    call $p81 := register_chrdev_region($p80, 32, $pa($pa(.str110, 0, 13), 0, 1));
    assume {:sourceloc "driver.re.c", 313, 2} true;
    $p82 := $p81;
    goto $bb18;

  $bb17:
    assume !$b77;
    assume {:sourceloc "driver.re.c", 314, 8} true;
    call $p83 := alloc_chrdev_region($p0, 0, 32, $pa($pa(.str110, 0, 13), 0, 1));
    assume {:sourceloc "driver.re.c", 315, 11} true;
    $p84 := $M.0[$p0];
    assume {:sourceloc "driver.re.c", 315, 11} true;
    call $p85 := MAJOR#1($p84);
    assume {:sourceloc "driver.re.c", 315, 11} true;
    $M.7 := $p85;
    $p82 := $p83;
    goto $bb18;

  $bb18:
    assume {:sourceloc "driver.re.c", 318, 6} true;
    $b86 := $slt($p82, 0);
    assume {:sourceloc "driver.re.c", 318, 6} true;
    goto $bb19, $bb20;

  $bb19:
    assume $b86;
    assume {:sourceloc "driver.re.c", 319, 3} true;
    $p87 := $M.4[pdev];
    yield;
    assert $p87 == $M.4[pdev];
    assume {:sourceloc "driver.re.c", 319, 3} true;
    $p88 := $pa($pa($p87, 0, 168), 16, 1);
    assume {:sourceloc "driver.re.c", 319, 3} true;
    call $p89 := dev_err#3($p88, $pa($pa(.str117, 0, 28), 0, 1), $p82);
    assume {:sourceloc "driver.re.c", 336, 2} true;
    $p90 := $M.2;
    yield;
    assert $p90 == $M.2;
    assume {:sourceloc "driver.re.c", 336, 2} true;
    call $p91 := release_region#2($p90, 16);
    assume {:sourceloc "driver.re.c", 336, 2} true;
    $p19 := $p82;
    goto $bb9;

  $bb20:
    assume !$b86;
    assume {:sourceloc "driver.re.c", 322, 6} true;
    $p92 := $M.7;
    assume {:sourceloc "driver.re.c", 322, 6} true;
    $b93 := $p92 != 0;
    assume {:sourceloc "driver.re.c", 322, 6} true;
    goto $bb21, $bb23;

  $bb21:
    assume {:sourceloc "driver.re.c", 322, 6} true;
    assume $b93;
    goto $bb22;

  $bb22:
    assume {:sourceloc "driver.re.c", 327, 2} true;
    call pc8736x_init_shadow();
    assume {:sourceloc "driver.re.c", 330, 2} true;
    call cdev_init(pc8736x_gpio_cdev, pc8736x_gpio_fileops);
    assume {:sourceloc "driver.re.c", 331, 2} true;
    $p98 := $M.0[$p0];
    assume {:sourceloc "driver.re.c", 331, 2} true;
    call $p99 := cdev_add(pc8736x_gpio_cdev, $p98, 32);
    assume {:sourceloc "driver.re.c", 333, 2} true;
    $p6 := 0;
    goto $bb3;

  $bb23:
    assume !$b93;
    assume {:sourceloc "driver.re.c", 323, 3} true;
    $M.7 := $p82;
    assume {:sourceloc "driver.re.c", 324, 3} true;
    $p94 := $M.4[pdev];
    yield;
    assert $p94 == $M.4[pdev];
    assume {:sourceloc "driver.re.c", 324, 3} true;
    $p95 := $pa($pa($p94, 0, 168), 16, 1);
    assume {:sourceloc "driver.re.c", 324, 3} true;
    $p96 := $M.7;
    assume {:sourceloc "driver.re.c", 324, 3} true;
    call $p97 := dev_dbg#3($p95, $pa($pa(.str118, 0, 22), 0, 1), $p96);
    assume {:sourceloc "driver.re.c", 325, 2} true;
    goto $bb22;
}



procedure pc8736x_gpio_set(minor: int, val: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;



implementation pc8736x_gpio_set(minor: int, val: int)
{
  var $p0: int;
  var $p1: int;
  var $p10: int;
  var $p11: int;
  var $p12: int;
  var $p13: int;
  var $p14: int;
  var $p15: int;
  var $p16: int;
  var $p17: int;
  var $p18: int;
  var $p19: int;
  var $p2: int;
  var $p20: int;
  var $p21: int;
  var $p22: int;
  var $p23: int;
  var $p24: int;
  var $p25: int;
  var $p26: int;
  var $p27: int;
  var $p28: int;
  var $p29: int;
  var $p3: int;
  var $p30: int;
  var $p31: int;
  var $p32: int;
  var $p33: int;
  var $p34: int;
  var $p35: int;
  var $p36: int;
  var $p37: int;
  var $p38: int;
  var $p39: int;
  var $p4: int;
  var $p40: int;
  var $p41: int;
  var $p42: int;
  var $p43: int;
  var $p44: int;
  var $p45: int;
  var $p46: int;
  var $p47: int;
  var $p48: int;
  var $p49: int;
  var $p5: int;
  var $p50: int;
  var $p51: int;
  var $p52: int;
  var $p53: int;
  var $p54: int;
  var $p55: int;
  var $p56: int;
  var $p57: int;
  var $p58: int;
  var $p59: int;
  var $p6: int;
  var $p60: int;
  var $p7: int;
  var $p8: int;
  var $p9: int;

  $bb0:
    assume {:sourceloc "driver.re.c", 176, 2} true;
    $p0 := $and(minor, 31);
    assume {:sourceloc "driver.re.c", 177, 2} true;
    $p1 := $lshr($p0, 3);
    assume {:sourceloc "driver.re.c", 178, 2} true;
    $p2 := $and($p0, 7);
    assume {:sourceloc "driver.re.c", 179, 11} true;
    $p3 := $M.2;
    yield;
    assert $p3 == $M.2;
    assume {:sourceloc "driver.re.c", 179, 11} true;
    $p4 := $p1;
    assume {:sourceloc "driver.re.c", 179, 11} true;
    $p5 := $pa($pa(port_offset, 0, 16), $p4, 4);
    assume {:sourceloc "driver.re.c", 179, 11} true;
    $p6 := $M.3[$p5];
    assume {:sourceloc "driver.re.c", 179, 11} true;
    $p7 := $add($p3, $p6);
    assume {:sourceloc "driver.re.c", 179, 11} true;
    $p8 := $add($p7, 0);
    assume {:sourceloc "driver.re.c", 179, 11} true;
    call $p9 := inb_p($p8);
    assume {:sourceloc "driver.re.c", 179, 11} true;
    $p10 := $p9;
    assume {:sourceloc "driver.re.c", 181, 2} true;
    $p11 := $M.4[pdev];
    yield;
    assert $p11 == $M.4[pdev];
    assume {:sourceloc "driver.re.c", 181, 2} true;
    $p12 := $pa($pa($p11, 0, 168), 16, 1);
    assume {:sourceloc "driver.re.c", 181, 2} true;
    $p13 := $M.2;
    yield;
    assert $p13 == $M.2;
    assume {:sourceloc "driver.re.c", 181, 2} true;
    $p14 := $p1;
    assume {:sourceloc "driver.re.c", 181, 2} true;
    $p15 := $pa($pa(port_offset, 0, 16), $p14, 4);
    assume {:sourceloc "driver.re.c", 181, 2} true;
    $p16 := $M.3[$p15];
    assume {:sourceloc "driver.re.c", 181, 2} true;
    $p17 := $add($p13, $p16);
    assume {:sourceloc "driver.re.c", 181, 2} true;
    $p18 := $add($p17, 0);
    assume {:sourceloc "driver.re.c", 181, 2} true;
    $p19 := $shl(1, $p2);
    assume {:sourceloc "driver.re.c", 181, 2} true;
    $p20 := $xor($p19, -1);
    assume {:sourceloc "driver.re.c", 181, 2} true;
    $p21 := $and($p10, $p20);
    assume {:sourceloc "driver.re.c", 181, 2} true;
    $p22 := $shl(val, $p2);
    assume {:sourceloc "driver.re.c", 181, 2} true;
    call $p23 := dev_dbg#8($p12, $pa($pa(.str106, 0, 61), 0, 1), $p18, $p10, $p2, $p21, val, $p22);
    assume {:sourceloc "driver.re.c", 185, 2} true;
    $p24 := $shl(1, $p2);
    assume {:sourceloc "driver.re.c", 185, 2} true;
    $p25 := $xor($p24, -1);
    assume {:sourceloc "driver.re.c", 185, 2} true;
    $p26 := $and($p10, $p25);
    assume {:sourceloc "driver.re.c", 185, 2} true;
    $p27 := $shl(val, $p2);
    assume {:sourceloc "driver.re.c", 185, 2} true;
    $p28 := $or($p26, $p27);
    assume {:sourceloc "driver.re.c", 187, 2} true;
    $p29 := $M.4[pdev];
    yield;
    assert $p29 == $M.4[pdev];
    assume {:sourceloc "driver.re.c", 187, 2} true;
    $p30 := $pa($pa($p29, 0, 168), 16, 1);
    assume {:sourceloc "driver.re.c", 187, 2} true;
    call $p31 := dev_dbg#7($p30, $pa($pa(.str107, 0, 46), 0, 1), $p0, $p1, $p2, $p10, $p28);
    assume {:sourceloc "driver.re.c", 190, 2} true;
    $p32 := $trunc($p28, 8);
    assume {:sourceloc "driver.re.c", 190, 2} true;
    $p33 := $M.2;
    yield;
    assert $p33 == $M.2;
    assume {:sourceloc "driver.re.c", 190, 2} true;
    $p34 := $p1;
    assume {:sourceloc "driver.re.c", 190, 2} true;
    $p35 := $pa($pa(port_offset, 0, 16), $p34, 4);
    assume {:sourceloc "driver.re.c", 190, 2} true;
    $p36 := $M.3[$p35];
    assume {:sourceloc "driver.re.c", 190, 2} true;
    $p37 := $add($p33, $p36);
    assume {:sourceloc "driver.re.c", 190, 2} true;
    $p38 := $add($p37, 0);
    assume {:sourceloc "driver.re.c", 190, 2} true;
    call outb_p($p32, $p38);
    assume {:sourceloc "driver.re.c", 192, 11} true;
    $p39 := $M.2;
    yield;
    assert $p39 == $M.2;
    assume {:sourceloc "driver.re.c", 192, 11} true;
    $p40 := $p1;
    assume {:sourceloc "driver.re.c", 192, 11} true;
    $p41 := $pa($pa(port_offset, 0, 16), $p40, 4);
    assume {:sourceloc "driver.re.c", 192, 11} true;
    $p42 := $M.3[$p41];
    assume {:sourceloc "driver.re.c", 192, 11} true;
    $p43 := $add($p39, $p42);
    assume {:sourceloc "driver.re.c", 192, 11} true;
    $p44 := $add($p43, 0);
    assume {:sourceloc "driver.re.c", 192, 11} true;
    call $p45 := inb_p($p44);
    assume {:sourceloc "driver.re.c", 192, 11} true;
    $p46 := $p45;
    assume {:sourceloc "driver.re.c", 193, 8} true;
    $p47 := $M.2;
    yield;
    assert $p47 == $M.2;
    assume {:sourceloc "driver.re.c", 193, 8} true;
    $p48 := $p1;
    assume {:sourceloc "driver.re.c", 193, 8} true;
    $p49 := $pa($pa(port_offset, 0, 16), $p48, 4);
    assume {:sourceloc "driver.re.c", 193, 8} true;
    $p50 := $M.3[$p49];
    assume {:sourceloc "driver.re.c", 193, 8} true;
    $p51 := $add($p47, $p50);
    assume {:sourceloc "driver.re.c", 193, 8} true;
    $p52 := $add($p51, 1);
    assume {:sourceloc "driver.re.c", 193, 8} true;
    call $p53 := inb_p($p52);
    assume {:sourceloc "driver.re.c", 193, 8} true;
    $p54 := $p53;
    assume {:sourceloc "driver.re.c", 195, 2} true;
    $p55 := $M.4[pdev];
    yield;
    assert $p55 == $M.4[pdev];
    assume {:sourceloc "driver.re.c", 195, 2} true;
    $p56 := $pa($pa($p55, 0, 168), 16, 1);
    assume {:sourceloc "driver.re.c", 195, 2} true;
    call $p57 := dev_dbg#4($p56, $pa($pa(.str108, 0, 20), 0, 1), $p46, $p54);
    assume {:sourceloc "driver.re.c", 196, 2} true;
    yield;
    call mutex_lock(gpio_shadow_lock);
    assume {:sourceloc "driver.re.c", 197, 2} true;
    $p58 := $trunc($p54, 8);
    assume {:sourceloc "driver.re.c", 197, 2} true;
    $p59 := $p1;
    assume {:sourceloc "driver.re.c", 197, 2} true;
    $p60 := $pa($pa(pc8736x_gpio_shadow, 0, 4), $p59, 1);
    assume {:sourceloc "driver.re.c", 197, 2} true;
    $M.6[$p60] := $p58;
    yield;
    assert $M.6[$p60] == $p58;
    assume {:sourceloc "driver.re.c", 198, 2} true;
    yield;
    call mutex_unlock(gpio_shadow_lock);
    assume {:sourceloc "driver.re.c", 199, 1} true;
    return;
}



procedure {:inline 1} pc8736x_init_shadow();
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;



implementation {:inline 1} pc8736x_init_shadow()
{
  var $b1: bool;
  var $p0: int;
  var $p10: int;
  var $p11: int;
  var $p2: int;
  var $p3: int;
  var $p4: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;
  var $p8: int;
  var $p9: int;

  $bb0:
    assume {:sourceloc "driver.re.c", 250, 7} true;
    $p0 := 0;
    goto $bb1;

  $bb1:
    assume {:sourceloc "driver.re.c", 250, 7} true;
    $b1 := $slt($p0, 4);
    assume {:sourceloc "driver.re.c", 250, 7} true;
    goto $bb2, $bb3;

  $bb2:
    assume $b1;
    assume {:sourceloc "driver.re.c", 252, 9} true;
    $p2 := $M.2;
    yield;
    assert $p2 == $M.2;
    assume {:sourceloc "driver.re.c", 252, 9} true;
    $p3 := $p0;
    assume {:sourceloc "driver.re.c", 252, 9} true;
    $p4 := $pa($pa(port_offset, 0, 16), $p3, 4);
    assume {:sourceloc "driver.re.c", 252, 9} true;
    $p5 := $M.3[$p4];
    assume {:sourceloc "driver.re.c", 252, 9} true;
    $p6 := $add($p2, $p5);
    assume {:sourceloc "driver.re.c", 252, 9} true;
    $p7 := $add($p6, 0);
    assume {:sourceloc "driver.re.c", 252, 9} true;
    call $p8 := inb_p($p7);
    assume {:sourceloc "driver.re.c", 252, 9} true;
    $p9 := $p0;
    assume {:sourceloc "driver.re.c", 252, 9} true;
    $p10 := $pa($pa(pc8736x_gpio_shadow, 0, 4), $p9, 1);
    assume {:sourceloc "driver.re.c", 252, 9} true;
    $M.6[$p10] := $p8;
    yield;
    assert $M.6[$p10] == $p8;
    assume {:sourceloc "driver.re.c", 250, 27} true;
    $p11 := $add($p0, 1);
    assume {:sourceloc "driver.re.c", 250, 27} true;
    $p0 := $p11;
    goto $bb1;

  $bb3:
    assume !$b1;
    assume {:sourceloc "driver.re.c", 255, 1} true;
    return;
}



procedure {:inline 1} pc8736x_superio_present() returns ($r: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;



implementation {:inline 1} pc8736x_superio_present() returns ($r: int)
{
  var $b10: bool;
  var $b22: bool;
  var $b23: bool;
  var $b24: bool;
  var $b8: bool;
  var $b9: bool;
  var $p0: int;
  var $p1: int;
  var $p11: int;
  var $p12: int;
  var $p13: int;
  var $p14: int;
  var $p15: int;
  var $p16: int;
  var $p17: int;
  var $p18: int;
  var $p19: int;
  var $p2: int;
  var $p20: int;
  var $p21: int;
  var $p25: int;
  var $p26: int;
  var $p3: int;
  var $p4: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;

  $bb0:
    assume {:sourceloc "driver.re.c", 100, 2} true;
    $M.12 := 46;
    assume {:sourceloc "driver.re.c", 91, 2} true;
    $p0 := $trunc(32, 8);
    assume {:sourceloc "driver.re.c", 91, 2} true;
    $p1 := $M.12;
    assume {:sourceloc "driver.re.c", 91, 2} true;
    $p2 := $p1;
    assume {:sourceloc "driver.re.c", 91, 2} true;
    call outb_p($p0, $p2);
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p3 := $M.12;
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p4 := $p3;
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p5 := $add($p4, 1);
    assume {:sourceloc "driver.re.c", 92, 9} true;
    call $p6 := inb_p($p5);
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p7 := $p6;
    assume {:sourceloc "driver.re.c", 102, 6} true;
    $b8 := $p7 == 229;
    assume {:sourceloc "driver.re.c", 102, 6} true;
    $b9 := $p7 == 233;
    assume {:sourceloc "driver.re.c", 102, 6} true;
    $b10 := $i2b($or($b2i($b8), $b2i($b9)));
    assume {:sourceloc "driver.re.c", 102, 6} true;
    goto $bb1, $bb2;

  $bb1:
    assume $b10;
    assume {:sourceloc "driver.re.c", 103, 3} true;
    $p11 := $M.12;
    assume {:sourceloc "driver.re.c", 103, 3} true;
    $p12 := $p11;
    assume {:sourceloc "driver.re.c", 103, 3} true;
    $p13 := $p12;
    goto $bb3;

  $bb2:
    assume !$b10;
    assume {:sourceloc "driver.re.c", 105, 2} true;
    $M.12 := 78;
    assume {:sourceloc "driver.re.c", 91, 2} true;
    $p14 := $trunc(32, 8);
    assume {:sourceloc "driver.re.c", 91, 2} true;
    $p15 := $M.12;
    assume {:sourceloc "driver.re.c", 91, 2} true;
    $p16 := $p15;
    assume {:sourceloc "driver.re.c", 91, 2} true;
    call outb_p($p14, $p16);
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p17 := $M.12;
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p18 := $p17;
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p19 := $add($p18, 1);
    assume {:sourceloc "driver.re.c", 92, 9} true;
    call $p20 := inb_p($p19);
    assume {:sourceloc "driver.re.c", 92, 9} true;
    $p21 := $p20;
    assume {:sourceloc "driver.re.c", 107, 6} true;
    $b22 := $p21 == 229;
    assume {:sourceloc "driver.re.c", 107, 6} true;
    $b23 := $p21 == 233;
    assume {:sourceloc "driver.re.c", 107, 6} true;
    $b24 := $i2b($or($b2i($b22), $b2i($b23)));
    assume {:sourceloc "driver.re.c", 107, 6} true;
    goto $bb4, $bb5;

  $bb3:
    assume {:sourceloc "driver.re.c", 111, 1} true;
    $r := $p13;
    return;

  $bb4:
    assume $b24;
    assume {:sourceloc "driver.re.c", 108, 3} true;
    $p25 := $M.12;
    assume {:sourceloc "driver.re.c", 108, 3} true;
    $p26 := $p25;
    assume {:sourceloc "driver.re.c", 108, 3} true;
    $p13 := $p26;
    goto $bb3;

  $bb5:
    assume !$b24;
    assume {:sourceloc "driver.re.c", 110, 2} true;
    $p13 := 0;
    goto $bb3;
}



procedure platform_device_add#0() returns ($r: int);



procedure platform_device_add#1(p#0: int) returns ($r: int);



procedure platform_device_alloc#0() returns ($r: int);



procedure platform_device_alloc#2(p#0: int, p#1: int) returns ($r: int);



procedure platform_device_del#0() returns ($r: int);



procedure platform_device_del#1(p#0: int) returns ($r: int);



procedure platform_device_put#0() returns ($r: int);



procedure platform_device_put#1(p#0: int) returns ($r: int);



procedure platform_device_unregister#0() returns ($r: int);



procedure platform_device_unregister#1(p#0: int) returns ($r: int);



procedure {:inline 1} register_chrdev_region(p#0: int, p#1: int, p#2: int) returns ($r: int);



procedure release_region#0() returns ($r: int);



procedure release_region#2(p#0: int, p#1: int) returns ($r: int);



procedure request_region#0() returns ($r: int);



procedure request_region#3(p#0: int, p#1: int, p#2: int) returns ($r: int);



procedure {:inline 1} timespec_trunc1(ret: int, p#1: int, p#2: int, p#3: int) returns ($r: int);



procedure {:inline 1} unregister_chrdev_region(p#0: int, p#1: int);



procedure {:inline 1} whoop$checker();
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;



implementation {:inline 1} whoop$checker()
{
  var $p0: int;
  var $p1: int;
  var $p10: int;
  var $p11: int;
  var $p12: int;
  var $p13: int;
  var $p14: int;
  var $p15: int;
  var $p16: int;
  var $p17: int;
  var $p18: int;
  var $p19: int;
  var $p2: int;
  var $p20: int;
  var $p21: int;
  var $p22: int;
  var $p23: int;
  var $p24: int;
  var $p25: int;
  var $p26: int;
  var $p27: int;
  var $p28: int;
  var $p29: int;
  var $p3: int;
  var $p30: int;
  var $p31: int;
  var $p32: int;
  var $p33: int;
  var $p34: int;
  var $p35: int;
  var $p36: int;
  var $p37: int;
  var $p38: int;
  var $p39: int;
  var $p4: int;
  var $p40: int;
  var $p41: int;
  var $p42: int;
  var $p43: int;
  var $p44: int;
  var $p45: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;
  var $p8: int;
  var $p9: int;

  $bb0:
    assume {:sourceloc "driver.re.c", 361, 49} true;
    call $p0 := $malloc(280);
    assume {:sourceloc "driver.re.c", 361, 49} true;
    $p1 := $p0;
    assume {:sourceloc "driver.re.c", 362, 46} true;
    call $p2 := $malloc(56);
    assume {:sourceloc "driver.re.c", 362, 46} true;
    $p3 := $p2;
    assume {:sourceloc "driver.re.c", 363, 49} true;
    call $p4 := $malloc(280);
    assume {:sourceloc "driver.re.c", 363, 49} true;
    $p5 := $p4;
    assume {:sourceloc "driver.re.c", 364, 46} true;
    call $p6 := $malloc(56);
    assume {:sourceloc "driver.re.c", 364, 46} true;
    $p7 := $p6;
    assume {:sourceloc "driver.re.c", 365, 49} true;
    call $p8 := $malloc(280);
    assume {:sourceloc "driver.re.c", 365, 49} true;
    $p9 := $p8;
    assume {:sourceloc "driver.re.c", 366, 46} true;
    call $p10 := $malloc(56);
    assume {:sourceloc "driver.re.c", 366, 46} true;
    $p11 := $p10;
    assume {:sourceloc "driver.re.c", 367, 49} true;
    call $p12 := $malloc(280);
    assume {:sourceloc "driver.re.c", 367, 49} true;
    $p13 := $p12;
    assume {:sourceloc "driver.re.c", 368, 46} true;
    call $p14 := $malloc(56);
    assume {:sourceloc "driver.re.c", 368, 46} true;
    $p15 := $p14;
    assume {:sourceloc "driver.re.c", 369, 49} true;
    call $p16 := $malloc(280);
    assume {:sourceloc "driver.re.c", 369, 49} true;
    $p17 := $p16;
    assume {:sourceloc "driver.re.c", 370, 46} true;
    call $p18 := $malloc(56);
    assume {:sourceloc "driver.re.c", 370, 46} true;
    $p19 := $p18;
    assume {:sourceloc "driver.re.c", 371, 49} true;
    call $p20 := $malloc(280);
    assume {:sourceloc "driver.re.c", 371, 49} true;
    $p21 := $p20;
    assume {:sourceloc "driver.re.c", 372, 46} true;
    call $p22 := $malloc(56);
    assume {:sourceloc "driver.re.c", 372, 46} true;
    $p23 := $p22;
    assume {:sourceloc "driver.re.c", 373, 49} true;
    call $p24 := $malloc(280);
    assume {:sourceloc "driver.re.c", 373, 49} true;
    $p25 := $p24;
    assume {:sourceloc "driver.re.c", 374, 46} true;
    call $p26 := $malloc(56);
    assume {:sourceloc "driver.re.c", 374, 46} true;
    $p27 := $p26;
    assume {:sourceloc "driver.re.c", 375, 53} true;
    call $p28 := $malloc(512);
    assume {:sourceloc "driver.re.c", 375, 53} true;
    $p29 := $p28;
    assume {:sourceloc "driver.re.c", 376, 35} true;
    call $p30 := $malloc(1);
    assume {:sourceloc "driver.re.c", 377, 77} true;
    call $p31 := $malloc(168);
    assume {:sourceloc "driver.re.c", 377, 77} true;
    $p32 := $p31;
    assume {:sourceloc "driver.re.c", 378, 74} true;
    call $p33 := $malloc(32);
    assume {:sourceloc "driver.re.c", 378, 74} true;
    $p34 := $p33;
    assume {:sourceloc "driver.re.c", 379, 50} true;
    call $p35 := $malloc(152);
    assume {:sourceloc "driver.re.c", 379, 50} true;
    $p36 := $p35;
    assume {:sourceloc "driver.re.c", 381, 48} true;
    call $p37 := $malloc(4);
    assume {:sourceloc "driver.re.c", 381, 48} true;
    $p38 := $p37;
    assume {:sourceloc "driver.re.c", 383, 36} true;
    call $p39 := $malloc(8);
    assume {:sourceloc "driver.re.c", 383, 36} true;
    $p40 := $p39;
    assume {:sourceloc "driver.re.c", 384, 18} true;
    call $p41 := __SMACK_nondet();
    assume {:sourceloc "driver.re.c", 385, 2} true;
    assume $p41 >= 0;
    assume {:sourceloc "driver.re.c", 387, 2} true;
    assume {:sourceloc "driver.re.c", 388, 2} true;
    assume {:sourceloc "driver.re.c", 389, 2} true;
    assume {:sourceloc "driver.re.c", 390, 2} true;
    assume {:sourceloc "driver.re.c", 391, 2} true;
    assume {:sourceloc "driver.re.c", 392, 2} true;
    assume {:sourceloc "driver.re.c", 393, 2} true;
    async call pc8736x_gpio_change$ep($p41);
    assume {:sourceloc "driver.re.c", 394, 1} true;
    return;
}



axiom __SMACK_nondet.XXX == -34;

axiom pc8736x_gpio_base == -5176;

axiom port_offset == -5192;

axiom pdev == -5200;

axiom gpio_shadow_lock == -5375;

axiom pc8736x_gpio_shadow == -5379;

axiom pc8736x_gpio_ops == -5443;

axiom major == -5617;

axiom pc8736x_gpio_cdev == -5691;

axiom pc8736x_gpio_fileops == -5891;

axiom _whoop_init == -5908;

axiom _whoop_exit == -5916;

axiom jiffies == -5939;

axiom selected_device == -5940;

axiom superio_cmd == -5941;

axiom pc8736x_gpio_config_lock == -5949;

axiom $NULL == 0;

axiom $and(0, 0) == 0;

axiom $and(0, 1) == 0;

axiom $and(1, 0) == 0;

axiom $and(1, 1) == 1;

axiom $or(0, 0) == 0;

axiom $or(0, 1) == 1;

axiom $or(1, 0) == 1;

axiom $or(1, 1) == 1;

axiom $xor(0, 0) == 0;

axiom $xor(0, 1) == 1;

axiom $xor(1, 0) == 1;

axiom $xor(1, 1) == 0;

axiom (forall f1: float, f2: float :: f1 != f2 || $foeq(f1, f2));

axiom (forall f: float :: $si2fp($fp2si(f)) == f);

axiom (forall f: float :: $ui2fp($fp2ui(f)) == f);

axiom (forall i: int :: $fp2si($si2fp(i)) == i);

axiom (forall i: int :: $fp2ui($ui2fp(i)) == i);

const $GLOBALS_BOTTOM: int;

const $MOP: $mop;

const $UNDEF: int;

const unique $NULL: int;

function $and(p1: int, p2: int) : int;

function $ashr(p1: int, p2: int) : int;

function $base(int) : int;

function $extractvalue(p: int, i: int) : int;

function $fadd(f1: float, f2: float) : float;

function $fdiv(f1: float, f2: float) : float;

function $ffalse(f1: float, f2: float) : bool;

function $fmul(f1: float, f2: float) : float;

function $foeq(f1: float, f2: float) : bool;

function $foge(f1: float, f2: float) : bool;

function $fogt(f1: float, f2: float) : bool;

function $fole(f1: float, f2: float) : bool;

function $folt(f1: float, f2: float) : bool;

function $fone(f1: float, f2: float) : bool;

function $ford(f1: float, f2: float) : bool;

function $fp(ipart: int, fpart: int, epart: int) : float;

function $fp2si(f: float) : int;

function $fp2ui(f: float) : int;

function $frem(f1: float, f2: float) : float;

function $fsub(f1: float, f2: float) : float;

function $ftrue(f1: float, f2: float) : bool;

function $fueq(f1: float, f2: float) : bool;

function $fuge(f1: float, f2: float) : bool;

function $fugt(f1: float, f2: float) : bool;

function $fule(f1: float, f2: float) : bool;

function $fult(f1: float, f2: float) : bool;

function $fune(f1: float, f2: float) : bool;

function $funo(f1: float, f2: float) : bool;

function $lshr(p1: int, p2: int) : int;

function $nand(p1: int, p2: int) : int;

function $or(p1: int, p2: int) : int;

function $shl(p1: int, p2: int) : int;

function $si2fp(i: int) : float;

function $ui2fp(i: int) : float;

function $xor(p1: int, p2: int) : int;

function {:builtin "div"} $sdiv(p1: int, p2: int) : int;

function {:builtin "div"} $udiv(p1: int, p2: int) : int;

function {:builtin "rem"} $srem(p1: int, p2: int) : int;

function {:builtin "rem"} $urem(p1: int, p2: int) : int;

function {:inline} $add(p1: int, p2: int) : int
{
  p1 + p2
}

function {:inline} $b2i(b: bool) : int
{
  (if b then 1 else 0)
}

function {:inline} $b2p(b: bool) : int
{
  (if b then 1 else 0)
}

function {:inline} $i2b(i: int) : bool
{
  i != 0
}

function {:inline} $i2p(p: int) : int
{
  p
}

function {:inline} $isExternal(p: int) : bool
{
  p < $GLOBALS_BOTTOM - 32768
}

function {:inline} $max(p1: int, p2: int) : int
{
  (if p1 > p2 then p1 else p2)
}

function {:inline} $min(p1: int, p2: int) : int
{
  (if p1 > p2 then p2 else p1)
}

function {:inline} $mul(p1: int, p2: int) : int
{
  p1 * p2
}

function {:inline} $p2b(p: int) : bool
{
  p != 0
}

function {:inline} $p2i(p: int) : int
{
  p
}

function {:inline} $pa(pointer: int, index: int, size: int) : int
{
  pointer + index * size
}

function {:inline} $sge(p1: int, p2: int) : bool
{
  p1 >= p2
}

function {:inline} $sgt(p1: int, p2: int) : bool
{
  p1 > p2
}

function {:inline} $sle(p1: int, p2: int) : bool
{
  p1 <= p2
}

function {:inline} $slt(p1: int, p2: int) : bool
{
  p1 < p2
}

function {:inline} $sub(p1: int, p2: int) : int
{
  p1 - p2
}

function {:inline} $trunc(p: int, size: int) : int
{
  p
}

function {:inline} $uge(p1: int, p2: int) : bool
{
  p1 >= p2
}

function {:inline} $ugt(p1: int, p2: int) : bool
{
  p1 > p2
}

function {:inline} $ule(p1: int, p2: int) : bool
{
  p1 <= p2
}

function {:inline} $ult(p1: int, p2: int) : bool
{
  p1 < p2
}

function {:inline} $umax(p1: int, p2: int) : int
{
  (if p1 > p2 then p1 else p2)
}

function {:inline} $umin(p1: int, p2: int) : int
{
  (if p1 > p2 then p2 else p1)
}

procedure {:inline 1} $alloca(n: int) returns (p: int);
  modifies $CurrAddr, $Alloc;



implementation {:inline 1} $alloca(n: int) returns (p: int)
{
  anon0:
    assume $CurrAddr > 0;
    p := $CurrAddr;
    goto anon4_Then, anon4_Else;

  anon4_Then:
    assume {:partition} n > 0;
    $CurrAddr := $CurrAddr + n;
    goto anon3;

  anon4_Else:
    assume {:partition} 0 >= n;
    $CurrAddr := $CurrAddr + 1;
    goto anon3;

  anon3:
    $Alloc[p] := true;
    return;
}



procedure {:inline 1} $malloc(n: int) returns (p: int);
  modifies $CurrAddr, $Alloc;



implementation {:inline 1} $malloc(n: int) returns (p: int)
{
  anon0:
    assume $CurrAddr > 0;
    p := $CurrAddr;
    goto anon4_Then, anon4_Else;

  anon4_Then:
    assume {:partition} n > 0;
    $CurrAddr := $CurrAddr + n;
    goto anon3;

  anon4_Else:
    assume {:partition} 0 >= n;
    $CurrAddr := $CurrAddr + 1;
    goto anon3;

  anon3:
    $Alloc[p] := true;
    return;
}



procedure $memcpy.51.51(dest: int, src: int, len: int, align: int, isvolatile: bool);
  modifies $M.51;



procedure $memcpy.54.54(dest: int, src: int, len: int, align: int, isvolatile: bool);
  modifies $M.54;



procedure {:inline 1} boogie_si_record_bool(b: bool);



procedure {:inline 1} boogie_si_record_float(f: float);



procedure {:inline 1} boogie_si_record_int(i: int);



procedure {:inline 1} boogie_si_record_mop(m: $mop);



type $mop;

type float;

var $Alloc: [int]bool;

var $CurrAddr: int;

var $exn: bool;

var $exnv: int;

procedure pc8736x_gpio_change$ep($p41: int);
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38, $M.39, $M.40, $M.41, $M.42, $M.43, $M.44, $M.45, $M.46, $M.47, $M.48, $M.49, $M.50, $M.51, $M.52, $M.53, $M.54;



implementation pc8736x_gpio_change$ep($p41: int)
{

  _EP:
    call pc8736x_gpio_change($p41);
    return;
}


