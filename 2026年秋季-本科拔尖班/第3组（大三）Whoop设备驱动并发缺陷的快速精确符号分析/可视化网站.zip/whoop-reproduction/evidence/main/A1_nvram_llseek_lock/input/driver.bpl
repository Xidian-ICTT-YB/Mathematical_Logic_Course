// BEGIN SMACK-GENERATED CODE

// Memory region declarations: 39
var $M.0: [int] int;
var $M.1: int;
var $M.2: [int] int;
var $M.3: int;
var $M.4: [int] int;
var $M.5: [int] int;
var $M.6: [int] int;
var $M.7: [int] int;
var $M.8: [int] int;
var $M.9: [int] int;
var $M.10: [int] int;
var $M.11: [int] int;
var $M.12: [int] int;
var $M.13: [int] int;
var $M.14: [int] int;
var $M.15: [int] int;
var $M.16: [int] int;
var $M.17: [int] int;
var $M.18: [int] int;
var $M.19: [int] int;
var $M.20: [int] int;
var $M.21: [int] int;
var $M.22: [int] int;
var $M.23: [int] int;
var $M.24: [int] int;
var $M.25: [int] int;
var $M.26: [int] int;
var $M.27: [int] int;
var $M.28: [int] int;
var $M.29: [int] int;
var $M.30: [int] int;
var $M.31: [int] int;
var $M.32: [int] int;
var $M.33: [int] int;
var $M.34: [int] int;
var $M.35: [int] int;
var $M.36: [int] int;
var $M.37: [int] int;
var $M.38: [int] int;

axiom $GLOBALS_BOTTOM == -5503;
const $u16: int;
const $u19: int;
const unique .str: int;
const unique .str1: int;
const unique .str10: int;
const unique .str100: int;
const unique .str101: int;
const unique .str102: int;
const unique .str103: int;
const unique .str104: int;
const unique .str105: int;
const unique .str106: int;
const unique .str107: int;
const unique .str108: int;
const unique .str11: int;
const unique .str12: int;
const unique .str13: int;
const unique .str14: int;
const unique .str15: int;
const unique .str16: int;
const unique .str17: int;
const unique .str18: int;
const unique .str19: int;
const unique .str2: int;
const unique .str20: int;
const unique .str21: int;
const unique .str22: int;
const unique .str23: int;
const unique .str24: int;
const unique .str25: int;
const unique .str26: int;
const unique .str27: int;
const unique .str28: int;
const unique .str29: int;
const unique .str3: int;
const unique .str30: int;
const unique .str31: int;
const unique .str32: int;
const unique .str33: int;
const unique .str34: int;
const unique .str35: int;
const unique .str36: int;
const unique .str37: int;
const unique .str38: int;
const unique .str39: int;
const unique .str4: int;
const unique .str40: int;
const unique .str41: int;
const unique .str42: int;
const unique .str43: int;
const unique .str44: int;
const unique .str45: int;
const unique .str46: int;
const unique .str47: int;
const unique .str48: int;
const unique .str49: int;
const unique .str5: int;
const unique .str50: int;
const unique .str51: int;
const unique .str52: int;
const unique .str53: int;
const unique .str54: int;
const unique .str55: int;
const unique .str56: int;
const unique .str57: int;
const unique .str58: int;
const unique .str59: int;
const unique .str6: int;
const unique .str60: int;
const unique .str61: int;
const unique .str62: int;
const unique .str63: int;
const unique .str64: int;
const unique .str65: int;
const unique .str66: int;
const unique .str67: int;
const unique .str68: int;
const unique .str69: int;
const unique .str7: int;
const unique .str70: int;
const unique .str71: int;
const unique .str72: int;
const unique .str73: int;
const unique .str74: int;
const unique .str75: int;
const unique .str76: int;
const unique .str77: int;
const unique .str78: int;
const unique .str79: int;
const unique .str8: int;
const unique .str80: int;
const unique .str81: int;
const unique .str82: int;
const unique .str83: int;
const unique .str84: int;
const unique .str85: int;
const unique .str86: int;
const unique .str87: int;
const unique .str88: int;
const unique .str89: int;
const unique .str9: int;
const unique .str90: int;
const unique .str91: int;
const unique .str92: int;
const unique .str93: int;
const unique .str94: int;
const unique .str95: int;
const unique .str96: int;
const unique .str97: int;
const unique .str98: int;
const unique .str99: int;
const unique __SMACK_decls: int;
const unique __SMACK_nondet: int;
const unique __SMACK_nondet.XXX: int;
const unique __get_user: int;
const unique __put_user: int;
const unique _whoop_exit: int;
const unique _whoop_init: int;
const unique access_ok: int;
const unique alloc_testdev: int;
const unique assert_: int;
const unique assume_: int;
const unique copy_from_user: int;
const unique copy_to_user: int;
const unique current_fs_time3: int;
const unique current_kernel_time2: int;
const unique jiffies: int;
const unique malloc: int;
const unique misc_deregister: int;
const unique misc_register: int;
const unique mutex_init: int;
const unique mutex_lock: int;
const unique mutex_lock_interruptible: int;
const unique mutex_unlock: int;
const unique nvram_cleanup: int;
const unique nvram_dev: int;
const unique nvram_fops: int;
const unique nvram_get_size: int;
const unique nvram_init: int;
const unique nvram_ioctl: int;
const unique nvram_len: int;
const unique nvram_llseek: int;
const unique nvram_mutex: int;
const unique nvram_read_byte: int;
const unique nvram_sync: int;
const unique nvram_unlocked_ioctl: int;
const unique nvram_write_byte: int;
const unique printk: int;
const unique read_nvram: int;
const unique spin_lock: int;
const unique spin_lock_bh: int;
const unique spin_lock_init: int;
const unique spin_lock_irq: int;
const unique spin_lock_irqsave: int;
const unique spin_unlock: int;
const unique spin_unlock_bh: int;
const unique spin_unlock_irq: int;
const unique spin_unlock_irqrestore: int;
const unique timespec_trunc1: int;
const unique usb_register: int;
const unique whoop$checker: int;
const unique write_nvram: int;
procedure {:inline 1} $static_init()
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  $M.1 := 0;
  $M.2[$pa(nvram_mutex, 0, 1)] := 1;
  $M.2[$pa(nvram_mutex, 4, 1)] := 0;
  $M.3 := 0;
  $M.0[$pa(nvram_fops, 0, 1)] := 0;
  $M.0[$pa(nvram_fops, 8, 1)] := nvram_llseek;
  $M.0[$pa(nvram_fops, 16, 1)] := read_nvram;
  $M.0[$pa(nvram_fops, 24, 1)] := write_nvram;
  $M.0[$pa(nvram_fops, 32, 1)] := 0;
  $M.0[$pa(nvram_fops, 40, 1)] := 0;
  $M.0[$pa(nvram_fops, 48, 1)] := 0;
  $M.0[$pa(nvram_fops, 56, 1)] := nvram_unlocked_ioctl;
  $M.0[$pa(nvram_fops, 64, 1)] := 0;
  $M.0[$pa(nvram_fops, 72, 1)] := 0;
  $M.0[$pa(nvram_fops, 80, 1)] := 0;
  $M.0[$pa(nvram_fops, 88, 1)] := 0;
  $M.0[$pa(nvram_fops, 96, 1)] := 0;
  $M.0[$pa(nvram_fops, 104, 1)] := 0;
  $M.0[$pa(nvram_fops, 112, 1)] := 0;
  $M.0[$pa(nvram_fops, 120, 1)] := 0;
  $M.0[$pa(nvram_fops, 128, 1)] := 0;
  $M.0[$pa(nvram_fops, 136, 1)] := 0;
  $M.0[$pa(nvram_fops, 144, 1)] := 0;
  $M.0[$pa(nvram_fops, 152, 1)] := 0;
  $M.0[$pa(nvram_fops, 160, 1)] := 0;
  $M.0[$pa(nvram_fops, 168, 1)] := 0;
  $M.0[$pa(nvram_fops, 176, 1)] := 0;
  $M.0[$pa(nvram_fops, 184, 1)] := 0;
  $M.0[$pa(nvram_fops, 192, 1)] := 0;
  $M.0[$pa(nvram_dev, 0, 1)] := 144;
  $M.0[$pa(nvram_dev, 8, 1)] := $pa($pa(.str108, 0, 6), 0, 1);
  $M.0[$pa(nvram_dev, 16, 1)] := nvram_fops;
  $M.4[_whoop_init] := nvram_init;
  $M.5[_whoop_exit] := nvram_cleanup;
  $M.6[jiffies] := 0;
  return;
}
procedure {:inline 1} __SMACK_nondet()
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
$bb0:
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 53, 3} true;
  $p0 := $M.1;
  call {:cexpr "x"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 54, 3} true;
  havoc $p0;
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 55, 3} true;
  $r := $p0;
  $exn := false;
  return;
}
procedure {:inline 1} __get_user(p#0: int, p#1: int)
  returns ($r: int);
procedure {:inline 1} __put_user(p#0: int, p#1: int)
  returns ($r: int);
procedure {:inline 1} access_ok(p#0: int, p#1: int, p#2: int)
  returns ($r: int);
procedure {:inline 1} alloc_testdev(sizeof_priv: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
$bb0:
  call {:cexpr "sizeof_priv"} boogie_si_record_int(sizeof_priv);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 20, 51} true;
  $p0 := sizeof_priv;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 20, 51} true;
  call $p1 := $malloc($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 20, 51} true;
  $p2 := $p1;
  call {:cexpr "dev"} boogie_si_record_int($p2);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/whoop.h", 21, 2} true;
  $r := $p2;
  $exn := false;
  return;
}
procedure {:inline 1} assert_(v: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
$bb0:
  call {:cexpr "v"} boogie_si_record_int(v);
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 37, 3} true;
  assert v != 0;
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 38, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} assume_(v: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
$bb0:
  call {:cexpr "v"} boogie_si_record_int(v);
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 41, 3} true;
  assume v != 0;
  assume {:sourceloc "/opt/whoop/local/include/smack/smack.h", 42, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} copy_from_user(to: int, from: int, n: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "to"} boogie_si_record_int(to);
  call {:cexpr "from"} boogie_si_record_int(from);
  call {:cexpr "n"} boogie_si_record_int(n);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/uaccess.h", 29, 10} true;
  call $p0 := __SMACK_nondet();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/uaccess.h", 29, 10} true;
  $p1 := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/uaccess.h", 29, 10} true;
  $r := $p1;
  $exn := false;
  return;
}
procedure {:inline 1} copy_to_user(to: int, from: int, n: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "to"} boogie_si_record_int(to);
  call {:cexpr "from"} boogie_si_record_int(from);
  call {:cexpr "n"} boogie_si_record_int(n);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/uaccess.h", 24, 10} true;
  call $p0 := __SMACK_nondet();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/uaccess.h", 24, 10} true;
  $p1 := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/uaccess.h", 24, 10} true;
  $r := $p1;
  $exn := false;
  return;
}
procedure {:inline 1} current_fs_time3(ret: int, sb: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
  var $p1: int;
  var $p10: int;
  var $p11: int;
  var $p12: int;
  var $p13: int;
  var $p14: int;
  var $p15: int;
  var $p16: int;
  var $p17: int;
  var $p18: int;
  var $p19: int;
  var $p2: int;
  var $p20: int;
  var $p21: int;
  var $p22: int;
  var $p23: int;
  var $p24: int;
  var $p25: int;
  var $p26: int;
  var $p27: int;
  var $p28: int;
  var $p29: int;
  var $p3: int;
  var $p30: int;
  var $p31: int;
  var $p32: int;
  var $p4: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;
  var $p8: int;
  var $p9: int;
$bb0:
  call $p0 := $alloca($mul(16, 1));
  call $p1 := $alloca($mul(16, 1));
  call {:cexpr "sb"} boogie_si_record_int(sb);
  // WARNING: ignoring llvm.debug call.
  assume true;
  call $p2 := $alloca($mul(16, 1));
  call $p3 := current_kernel_time2($p2);
  $p4 := $pa($pa($p2, 0, 16), 0, 1);
  $p5 := $M.0[$p4];
  $p6 := $pa($pa($p2, 0, 16), 8, 1);
  $p7 := $M.0[$p6];
  $p8 := $M.0[$p2];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 545, 25} true;
  $p9 := $p1;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 545, 25} true;
  $p10 := $pa($pa($p9, 0, 16), 0, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 545, 25} true;
  $M.37[$p10] := $p5;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 545, 25} true;
  $p11 := $pa($pa($p9, 0, 16), 8, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 545, 25} true;
  $M.37[$p11] := $p7;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p12 := $pa($pa(sb, 0, 304), 268, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p13 := $M.38[$p12];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p14 := $p1;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p15 := $pa($pa($p14, 0, 16), 0, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p16 := $M.37[$p15];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p17 := $pa($pa($p14, 0, 16), 8, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p18 := $M.37[$p17];
  call $p19 := $alloca($mul(16, 1));
  call $p20 := timespec_trunc1($p19, $p16, $p18, $p13);
  $p21 := $pa($pa($p19, 0, 16), 0, 1);
  $p22 := $M.0[$p21];
  $p23 := $pa($pa($p19, 0, 16), 8, 1);
  $p24 := $M.0[$p23];
  $p25 := $M.0[$p19];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p26 := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p27 := $pa($pa($p26, 0, 16), 0, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $M.36[$p27] := $p22;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p28 := $pa($pa($p26, 0, 16), 8, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $M.36[$p28] := $p24;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p29 := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p30 := $M.36[$p29];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p31 := ret;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $p32 := $p29;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  call $memcpy.36.36($p31, $p32, 16, 8, false);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/fs.h", 546, 10} true;
  $r := $p30;
  $exn := false;
  return;
}
procedure {:inline 1} current_kernel_time2(ret: int)
  returns ($r: int);
procedure {:inline 1} misc_deregister(p#0: int)
  returns ($r: int);
procedure {:inline 1} misc_register(p#0: int)
  returns ($r: int);
procedure {:inline 1} mutex_init(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 29, 2} true;
  $p0 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 29, 2} true;
  $M.7[$p0] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 30, 2} true;
  $p1 := $pa($pa(lock, 0, 8), 0, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 30, 2} true;
  $M.7[$p1] := 1;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 31, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} mutex_lock(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 35, 12} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 36, 2} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 38, 2} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 39, 2} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 39, 2} true;
  $p2 := $M.2[$p1];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 39, 2} true;
  assume $p2 == 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 40, 2} true;
  $p3 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 40, 2} true;
  $M.2[$p3] := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 41, 2} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 42, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} mutex_lock_interruptible(lock: int)
  returns ($r: bool)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $b1: bool;
  var $b3: bool;
  var $b8: bool;
  var $p0: int;
  var $p2: int;
  var $p4: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 46, 19} true;
  call $p0 := __SMACK_nondet();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 46, 19} true;
  $b1 := ($p0 != 0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 46, 19} true;
  $p2 := $b2p($b1);
  call {:cexpr "ret"} boogie_si_record_int($p2);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 47, 5} true;
  $b3 := $i2b($p2);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 47, 5} true;
  goto $bb1, $bb3;
$bb1:
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 47, 5} true;
  assume $b3;
  goto $bb2;
$bb2:
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 56, 2} true;
  $b8 := $i2b($p2);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 56, 2} true;
  $r := $b8;
  $exn := false;
  return;
$bb3:
  assume !($b3);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 48, 13} true;
  call $p4 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p4);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 49, 3} true;
  call $p4 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 51, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 52, 3} true;
  $p5 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 52, 3} true;
  $p6 := $M.8[$p5];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 52, 3} true;
  assume $p6 == 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 53, 3} true;
  $p7 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 53, 3} true;
  $M.8[$p7] := $p4;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 54, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 55, 2} true;
  goto $bb2;
}
procedure {:inline 1} mutex_unlock(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 61, 12} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 62, 2} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 64, 2} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 65, 2} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 65, 2} true;
  $M.2[$p1] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 66, 2} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/mutex.h", 67, 1} true;
  $exn := false;
  return;
}
procedure nvram_cleanup()
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
$bb0:
  assume {:sourceloc "driver.re.c", 178, 9} true;
  call $p0 := misc_deregister(nvram_dev);
  assume {:sourceloc "driver.re.c", 179, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} nvram_get_size()
  returns ($r: int);
procedure nvram_init()
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $b2: bool;
  var $b5: bool;
  var $p0: int;
  var $p1: int;
  var $p3: int;
  var $p4: int;
  var $p6: int;
$bb0:
  call {:cexpr "ret"} boogie_si_record_int(0);
  assume {:sourceloc "driver.re.c", 162, 2} true;
  call $p0 := printk#2($pa($pa(.str105, 0, 42), 0, 1), $pa($pa(.str106, 0, 4), 0, 1));
  assume {:sourceloc "driver.re.c", 164, 8} true;
  call $p1 := misc_register(nvram_dev);
  call {:cexpr "ret"} boogie_si_record_int($p1);
  assume {:sourceloc "driver.re.c", 165, 6} true;
  $b2 := ($p1 != 0);
  assume {:sourceloc "driver.re.c", 165, 6} true;
  goto $bb1, $bb3;
$bb1:
  assume {:sourceloc "driver.re.c", 165, 6} true;
  assume $b2;
  goto $bb2;
$bb2:
  assume {:sourceloc "driver.re.c", 173, 2} true;
  $r := $p1;
  $exn := false;
  return;
$bb3:
  assume !($b2);
  assume {:sourceloc "driver.re.c", 168, 14} true;
  call $p3 := nvram_get_size();
  assume {:sourceloc "driver.re.c", 168, 14} true;
  $M.3 := $p3;
  call {:cexpr "nvram_len"} boogie_si_record_int($p3);
  assume {:sourceloc "driver.re.c", 169, 6} true;
  $p4 := $M.3;
  assume {:sourceloc "driver.re.c", 169, 6} true;
  $b5 := $slt($p4, 0);
  assume {:sourceloc "driver.re.c", 169, 6} true;
  havoc $p6;
  assume (($b5 ==> ($p6 == 8192)) && (!($b5) ==> ($p6 == $p3)));
  assume {:sourceloc "driver.re.c", 170, 3} true;
  $M.3 := $p6;
  call {:cexpr "nvram_len"} boogie_si_record_int($p6);
  assume {:sourceloc "driver.re.c", 169, 18} true;
  goto $bb2;
}
procedure {:inline 1} nvram_ioctl(file: int, cmd: int, arg: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $b0: bool;
  var $p1: int;
$bb0:
  call {:cexpr "file"} boogie_si_record_int(file);
  call {:cexpr "cmd"} boogie_si_record_int(cmd);
  call {:cexpr "arg"} boogie_si_record_int(arg);
  $b0 := (cmd == 28739);
  goto $bb1, $bb2;
$bb1:
  assume $b0;
  assume {:sourceloc "driver.re.c", 124, 3} true;
  call nvram_sync();
  assume {:sourceloc "driver.re.c", 130, 2} true;
  $p1 := 0;
  goto $bb3;
$bb2:
  assume !($b0);
  assume {:sourceloc "driver.re.c", 127, 3} true;
  $p1 := -22;
  goto $bb3;
$bb3:
  assume {:sourceloc "driver.re.c", 131, 1} true;
  $r := $p1;
  $exn := false;
  return;
}
procedure nvram_llseek(file: int, offset: int, origin: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $b0: bool;
  var $b1: bool;
  var $b10: bool;
  var $b2: bool;
  var $b3: bool;
  var $p11: int;
  var $p12: int;
  var $p4: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;
  var $p8: int;
  var $p9: int;
$bb0:
  call {:cexpr "file"} boogie_si_record_int(file);
  call {:cexpr "offset"} boogie_si_record_int(offset);
  call {:cexpr "origin"} boogie_si_record_int(origin);
  assume {:sourceloc "driver.re.c", 40, 2} true;
  call mutex_lock(nvram_mutex);
  $b0 := $slt(origin, 1);
  goto $bb1, $bb2;
$bb1:
  assume $b0;
  $b3 := (origin == 0);
  $p4 := offset;
  goto $bb8, $bb10;
$bb2:
  assume !($b0);
  $b1 := $slt(origin, 2);
  goto $bb3, $bb4;
$bb3:
  assume $b1;
  assume {:sourceloc "driver.re.c", 45, 3} true;
  $p5 := $pa($pa(file, 0, 56), 32, 1);
  assume {:sourceloc "driver.re.c", 45, 3} true;
  $p6 := $M.0[$p5];
  assume {:sourceloc "driver.re.c", 45, 3} true;
  $p7 := $add(offset, $p6);
  call {:cexpr "offset"} boogie_si_record_int($p7);
  assume {:sourceloc "driver.re.c", 46, 3} true;
  $p4 := $p7;
  goto $bb9;
$bb4:
  assume !($b1);
  $b2 := (origin == 2);
  goto $bb5, $bb6;
$bb5:
  assume $b2;
  assume {:sourceloc "driver.re.c", 48, 3} true;
  $p8 := $M.3;
  assume {:sourceloc "driver.re.c", 48, 3} true;
  $p9 := $add(offset, $p8);
  call {:cexpr "offset"} boogie_si_record_int($p9);
  assume {:sourceloc "driver.re.c", 49, 3} true;
  $p4 := $p9;
  goto $bb9;
$bb6:
  assume !($b2);
  goto $bb7;
$bb7:
  call {:cexpr "offset"} boogie_si_record_int(-1);
  assume {:sourceloc "driver.re.c", 52, 2} true;
  $p4 := -1;
  goto $bb9;
$bb8:
  assume $b3;
  goto $bb9;
$bb9:
  assume {:sourceloc "driver.re.c", 53, 6} true;
  $b10 := $slt($p4, 0);
  assume {:sourceloc "driver.re.c", 53, 6} true;
  goto $bb11, $bb12;
$bb10:
  assume !($b3);
  goto $bb7;
$bb11:
  assume $b10;
  call {:cexpr "result"} boogie_si_record_int(-22);
  assume {:sourceloc "driver.re.c", 55, 3} true;
  $p11 := -22;
  goto $bb13;
$bb12:
  assume !($b10);
  assume {:sourceloc "driver.re.c", 58, 2} true;
  $p12 := $pa($pa(file, 0, 56), 32, 1);
  assume {:sourceloc "driver.re.c", 58, 2} true;
  $M.0[$p12] := $p4;
  call {:cexpr "result"} boogie_si_record_int($p4);
  assume {:sourceloc "driver.re.c", 59, 2} true;
  $p11 := $p4;
  goto $bb13;
$bb13:
  assume {:sourceloc "driver.re.c", 61, 2} true;
  call mutex_unlock(nvram_mutex);
  assume {:sourceloc "driver.re.c", 62, 2} true;
  $r := $p11;
  $exn := false;
  return;
}
procedure {:inline 1} nvram_read_byte(p#0: int)
  returns ($r: int);
procedure {:inline 1} nvram_sync();
procedure nvram_unlocked_ioctl(file: int, cmd: int, arg: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "file"} boogie_si_record_int(file);
  call {:cexpr "cmd"} boogie_si_record_int(cmd);
  call {:cexpr "arg"} boogie_si_record_int(arg);
  assume {:sourceloc "driver.re.c", 137, 2} true;
  call mutex_lock(nvram_mutex);
  assume {:sourceloc "driver.re.c", 138, 8} true;
  call $p0 := nvram_ioctl(file, cmd, arg);
  call {:cexpr "ret"} boogie_si_record_int($p0);
  assume {:sourceloc "driver.re.c", 139, 2} true;
  call mutex_unlock(nvram_mutex);
  assume {:sourceloc "driver.re.c", 141, 2} true;
  $p1 := $p0;
  assume {:sourceloc "driver.re.c", 141, 2} true;
  $r := $p1;
  $exn := false;
  return;
}
procedure {:inline 1} nvram_write_byte(p#0: int, p#1: int);
procedure printk#0(p#0: int)
  returns ($r: int);
procedure printk#2(p#0: int, p#1: int)
  returns ($r: int);
procedure read_nvram(file: int, buf: int, count: int, ppos: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $b1: bool;
  var $b11: bool;
  var $b12: bool;
  var $b15: bool;
  var $b19: bool;
  var $b5: bool;
  var $p0: int;
  var $p10: int;
  var $p13: int;
  var $p14: int;
  var $p16: int;
  var $p17: int;
  var $p18: int;
  var $p2: int;
  var $p20: int;
  var $p21: int;
  var $p22: int;
  var $p23: int;
  var $p24: int;
  var $p25: int;
  var $p26: int;
  var $p3: int;
  var $p4: int;
  var $p6: int;
  var $p7: int;
  var $p8: int;
  var $p9: int;
$bb0:
  call {:cexpr "file"} boogie_si_record_int(file);
  call {:cexpr "buf"} boogie_si_record_int(buf);
  call {:cexpr "count"} boogie_si_record_int(count);
  call {:cexpr "ppos"} boogie_si_record_int(ppos);
  call {:cexpr "p"} boogie_si_record_int(buf);
  assume {:sourceloc "driver.re.c", 71, 7} true;
  call $p0 := access_ok(1, buf, count);
  assume {:sourceloc "driver.re.c", 71, 7} true;
  $b1 := ($p0 != 0);
  assume {:sourceloc "driver.re.c", 71, 7} true;
  goto $bb1, $bb2;
$bb1:
  assume $b1;
  assume {:sourceloc "driver.re.c", 73, 6} true;
  $p3 := $M.0[ppos];
  assume {:sourceloc "driver.re.c", 73, 6} true;
  $p4 := $M.3;
  assume {:sourceloc "driver.re.c", 73, 6} true;
  $b5 := $sge($p3, $p4);
  assume {:sourceloc "driver.re.c", 73, 6} true;
  goto $bb4, $bb5;
$bb2:
  assume !($b1);
  assume {:sourceloc "driver.re.c", 72, 3} true;
  $p2 := -14;
  goto $bb3;
$bb3:
  assume {:sourceloc "driver.re.c", 80, 1} true;
  $r := $p2;
  $exn := false;
  return;
$bb4:
  assume $b5;
  assume {:sourceloc "driver.re.c", 74, 3} true;
  $p2 := 0;
  goto $bb3;
$bb5:
  assume !($b5);
  assume {:sourceloc "driver.re.c", 75, 7} true;
  $p6 := $M.0[ppos];
  assume {:sourceloc "driver.re.c", 75, 7} true;
  $p7 := $trunc($p6, 32);
  call {:cexpr "i"} boogie_si_record_int($p7);
  assume {:sourceloc "driver.re.c", 75, 7} true;
  $p8 := count;
  $p9 := $p7;
  $p10 := buf;
  goto $bb6;
$bb6:
  assume {:sourceloc "driver.re.c", 75, 7} true;
  $b11 := $ugt($p8, 0);
  assume {:sourceloc "driver.re.c", 75, 7} true;
  $b12 := false;
  goto $bb7, $bb8;
$bb7:
  assume $b11;
  assume {:sourceloc "driver.re.c", 75, 7} true;
  $p13 := $p9;
  assume {:sourceloc "driver.re.c", 75, 7} true;
  $p14 := $M.3;
  assume {:sourceloc "driver.re.c", 75, 7} true;
  $b15 := $slt($p13, $p14);
  $b12 := $b15;
  goto $bb9;
$bb8:
  assume {:sourceloc "driver.re.c", 75, 7} true;
  assume !($b11);
  goto $bb9;
$bb9:
  assume {:sourceloc "driver.re.c", 75, 7} true;
  goto $bb10, $bb11;
$bb10:
  assume $b12;
  assume {:sourceloc "driver.re.c", 76, 18} true;
  call $p16 := nvram_read_byte($p9);
  assume {:sourceloc "driver.re.c", 76, 18} true;
  $p17 := $p16;
  assume {:sourceloc "driver.re.c", 76, 7} true;
  call $p18 := __put_user($p17, $p10);
  assume {:sourceloc "driver.re.c", 76, 7} true;
  $b19 := ($p18 != 0);
  assume {:sourceloc "driver.re.c", 76, 7} true;
  goto $bb12, $bb13;
$bb11:
  assume !($b12);
  assume {:sourceloc "driver.re.c", 78, 2} true;
  $p23 := $p9;
  assume {:sourceloc "driver.re.c", 78, 2} true;
  $M.0[ppos] := $p23;
  assume {:sourceloc "driver.re.c", 79, 2} true;
  $p24 := $p2i($p10);
  assume {:sourceloc "driver.re.c", 79, 2} true;
  $p25 := $p2i(buf);
  assume {:sourceloc "driver.re.c", 79, 2} true;
  $p26 := $sub($p24, $p25);
  assume {:sourceloc "driver.re.c", 79, 2} true;
  $p2 := $p26;
  goto $bb3;
$bb12:
  assume $b19;
  assume {:sourceloc "driver.re.c", 77, 4} true;
  $p2 := -14;
  goto $bb3;
$bb13:
  assume !($b19);
  assume {:sourceloc "driver.re.c", 75, 46} true;
  $p20 := $add($p9, 1);
  call {:cexpr "i"} boogie_si_record_int($p20);
  assume {:sourceloc "driver.re.c", 75, 46} true;
  $p21 := $pa($p10, 1, 1);
  call {:cexpr "p"} boogie_si_record_int($p21);
  assume {:sourceloc "driver.re.c", 75, 46} true;
  $p22 := $add($p8, -1);
  call {:cexpr "count"} boogie_si_record_int($p22);
  assume {:sourceloc "driver.re.c", 75, 46} true;
  $p8 := $p22;
  $p9 := $p20;
  $p10 := $p21;
  goto $bb6;
}
procedure {:inline 1} spin_lock(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 34, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 35, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 37, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 38, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 38, 3} true;
  $p2 := $M.10[$p1];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 38, 3} true;
  assume $p2 == 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 39, 3} true;
  $p3 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 39, 3} true;
  $M.10[$p3] := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 40, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 41, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_lock_bh(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 67, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 68, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 70, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 71, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 71, 3} true;
  $p2 := $M.13[$p1];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 71, 3} true;
  assume $p2 == 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 72, 3} true;
  $p3 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 72, 3} true;
  $M.13[$p3] := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 73, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 74, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_lock_init(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 28, 3} true;
  $p0 := $pa($pa(lock, 0, 8), 0, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 28, 3} true;
  $M.9[$p0] := 1;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 29, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 29, 3} true;
  $M.9[$p1] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 30, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_lock_irq(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 56, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 57, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 59, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 60, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 60, 3} true;
  $p2 := $M.12[$p1];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 60, 3} true;
  assume $p2 == 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 61, 3} true;
  $p3 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 61, 3} true;
  $M.12[$p3] := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 62, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 63, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_lock_irqsave(lock: int, value: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
  var $p1: int;
  var $p2: int;
  var $p3: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  call {:cexpr "value"} boogie_si_record_int(value);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 45, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 46, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 48, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 49, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 49, 3} true;
  $p2 := $M.11[$p1];
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 49, 3} true;
  assume $p2 == 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 50, 3} true;
  $p3 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 50, 3} true;
  $M.11[$p3] := $p0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 51, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 52, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_unlock(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 78, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 79, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 81, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 82, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 82, 3} true;
  $M.14[$p1] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 83, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 84, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_unlock_bh(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 108, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 109, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 111, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 112, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 112, 3} true;
  $M.17[$p1] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 113, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 114, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_unlock_irq(lock: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 98, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 99, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 101, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 102, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 102, 3} true;
  $M.16[$p1] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 103, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 104, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} spin_unlock_irqrestore(lock: int, value: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
  var $p1: int;
$bb0:
  call {:cexpr "lock"} boogie_si_record_int(lock);
  call {:cexpr "value"} boogie_si_record_int(value);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 88, 13} true;
  call $p0 := __SMACK_nondet();
  call {:cexpr "tid"} boogie_si_record_int($p0);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 89, 3} true;
  call $p0 := corral_getThreadID();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 91, 3} true;
  call corral_atomic_begin();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 92, 3} true;
  $p1 := $pa($pa(lock, 0, 8), 4, 1);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 92, 3} true;
  $M.15[$p1] := 0;
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 93, 3} true;
  call corral_atomic_end();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/spinlock.h", 94, 1} true;
  $exn := false;
  return;
}
procedure {:inline 1} timespec_trunc1(ret: int, p#1: int, p#2: int, p#3: int)
  returns ($r: int);
procedure {:inline 1} usb_register(driver: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
$bb0:
  call {:cexpr "driver"} boogie_si_record_int(driver);
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/usb.h", 1146, 9} true;
  call $p0 := __SMACK_nondet();
  assume {:sourceloc "/opt/whoop/src/whoop/Model/linux/usb.h", 1146, 9} true;
  $r := $p0;
  $exn := false;
  return;
}
procedure {:inline 1} whoop$checker()
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $p0: int;
  var $p1: int;
  var $p10: int;
  var $p11: int;
  var $p12: int;
  var $p13: int;
  var $p14: int;
  var $p15: int;
  var $p16: int;
  var $p17: int;
  var $p18: int;
  var $p19: int;
  var $p2: int;
  var $p20: int;
  var $p21: int;
  var $p22: int;
  var $p23: int;
  var $p24: int;
  var $p25: int;
  var $p26: int;
  var $p27: int;
  var $p28: int;
  var $p29: int;
  var $p3: int;
  var $p30: int;
  var $p31: int;
  var $p32: int;
  var $p33: int;
  var $p34: int;
  var $p35: int;
  var $p36: int;
  var $p37: int;
  var $p38: int;
  var $p39: int;
  var $p4: int;
  var $p40: int;
  var $p41: int;
  var $p42: int;
  var $p43: int;
  var $p44: int;
  var $p5: int;
  var $p6: int;
  var $p7: int;
  var $p8: int;
  var $p9: int;
$bb0:
  call $p0 := $alloca($mul(8, 1));
  assume {:sourceloc "driver.re.c", 187, 49} true;
  call $p1 := $malloc(280);
  assume {:sourceloc "driver.re.c", 187, 49} true;
  $p2 := $p1;
  call {:cexpr "whoop_inode$0"} boogie_si_record_int($p2);
  assume {:sourceloc "driver.re.c", 188, 46} true;
  call $p3 := $malloc(56);
  assume {:sourceloc "driver.re.c", 188, 46} true;
  $p4 := $p3;
  call {:cexpr "whoop_file$0"} boogie_si_record_int($p4);
  assume {:sourceloc "driver.re.c", 189, 49} true;
  call $p5 := $malloc(280);
  assume {:sourceloc "driver.re.c", 189, 49} true;
  $p6 := $p5;
  call {:cexpr "whoop_inode$1"} boogie_si_record_int($p6);
  assume {:sourceloc "driver.re.c", 190, 46} true;
  call $p7 := $malloc(56);
  assume {:sourceloc "driver.re.c", 190, 46} true;
  $p8 := $p7;
  call {:cexpr "whoop_file$1"} boogie_si_record_int($p8);
  assume {:sourceloc "driver.re.c", 191, 49} true;
  call $p9 := $malloc(280);
  assume {:sourceloc "driver.re.c", 191, 49} true;
  $p10 := $p9;
  call {:cexpr "whoop_inode$2"} boogie_si_record_int($p10);
  assume {:sourceloc "driver.re.c", 192, 46} true;
  call $p11 := $malloc(56);
  assume {:sourceloc "driver.re.c", 192, 46} true;
  $p12 := $p11;
  call {:cexpr "whoop_file$2"} boogie_si_record_int($p12);
  assume {:sourceloc "driver.re.c", 193, 49} true;
  call $p13 := $malloc(280);
  assume {:sourceloc "driver.re.c", 193, 49} true;
  $p14 := $p13;
  call {:cexpr "whoop_inode$3"} boogie_si_record_int($p14);
  assume {:sourceloc "driver.re.c", 194, 46} true;
  call $p15 := $malloc(56);
  assume {:sourceloc "driver.re.c", 194, 46} true;
  $p16 := $p15;
  call {:cexpr "whoop_file$3"} boogie_si_record_int($p16);
  assume {:sourceloc "driver.re.c", 195, 49} true;
  call $p17 := $malloc(280);
  assume {:sourceloc "driver.re.c", 195, 49} true;
  $p18 := $p17;
  call {:cexpr "whoop_inode$4"} boogie_si_record_int($p18);
  assume {:sourceloc "driver.re.c", 196, 46} true;
  call $p19 := $malloc(56);
  assume {:sourceloc "driver.re.c", 196, 46} true;
  $p20 := $p19;
  call {:cexpr "whoop_file$4"} boogie_si_record_int($p20);
  assume {:sourceloc "driver.re.c", 197, 53} true;
  call $p21 := $malloc(512);
  assume {:sourceloc "driver.re.c", 197, 53} true;
  $p22 := $p21;
  call {:cexpr "whoop_pci_dev"} boogie_si_record_int($p22);
  assume {:sourceloc "driver.re.c", 198, 35} true;
  call $p23 := $malloc(1);
  call {:cexpr "whoop_buf"} boogie_si_record_int($p23);
  assume {:sourceloc "driver.re.c", 199, 77} true;
  call $p24 := $malloc(168);
  assume {:sourceloc "driver.re.c", 199, 77} true;
  $p25 := $p24;
  call {:cexpr "whoop_platform_device"} boogie_si_record_int($p25);
  assume {:sourceloc "driver.re.c", 200, 74} true;
  call $p26 := $malloc(32);
  assume {:sourceloc "driver.re.c", 200, 74} true;
  $p27 := $p26;
  call {:cexpr "whoop_vm_area_struct"} boogie_si_record_int($p27);
  assume {:sourceloc "driver.re.c", 201, 50} true;
  call $p28 := $malloc(152);
  assume {:sourceloc "driver.re.c", 201, 50} true;
  $p29 := $p28;
  call {:cexpr "whoop_cx_dev"} boogie_si_record_int($p29);
  assume {:sourceloc "driver.re.c", 203, 48} true;
  call $p30 := $malloc(4);
  assume {:sourceloc "driver.re.c", 203, 48} true;
  $p31 := $p30;
  call {:cexpr "whoop_poll_table"} boogie_si_record_int($p31);
  // WARNING: ignoring llvm.debug call.
  assume true;
  assume {:sourceloc "driver.re.c", 205, 36} true;
  call $p32 := $malloc(8);
  assume {:sourceloc "driver.re.c", 205, 36} true;
  $p33 := $p32;
  assume {:sourceloc "driver.re.c", 205, 36} true;
  $M.19[$p0] := $p33;
  assume {:sourceloc "driver.re.c", 206, 18} true;
  call $p34 := __SMACK_nondet();
  call {:cexpr "whoop_int"} boogie_si_record_int($p34);
  assume {:sourceloc "driver.re.c", 207, 2} true;
  assume $p34 >= 0;
  assume {:sourceloc "driver.re.c", 209, 2} true;
  $p35 := $p34;
  assume {:sourceloc "driver.re.c", 209, 2} true;
  $p36 := $M.19[$p0];
  assume {:sourceloc "driver.re.c", 209, 2} true;
  call $p37 := write_nvram($p4, $p23, $p35, $p36);
  assume {:sourceloc "driver.re.c", 210, 2} true;
  $p38 := $p34;
  assume {:sourceloc "driver.re.c", 210, 2} true;
  $p39 := $M.19[$p0];
  assume {:sourceloc "driver.re.c", 210, 2} true;
  call $p40 := read_nvram($p8, $p23, $p38, $p39);
  assume {:sourceloc "driver.re.c", 211, 2} true;
  $p41 := $p34;
  assume {:sourceloc "driver.re.c", 211, 2} true;
  call $p42 := nvram_unlocked_ioctl($p12, $p34, $p41);
  assume {:sourceloc "driver.re.c", 212, 2} true;
  $p43 := $p2i($p0);
  assume {:sourceloc "driver.re.c", 212, 2} true;
  call $p44 := nvram_llseek($p16, $p43, $p34);
  assume {:sourceloc "driver.re.c", 213, 2} true;
  call nvram_cleanup();
  assume {:sourceloc "driver.re.c", 214, 1} true;
  $exn := false;
  return;
}
procedure write_nvram(file: int, buf: int, count: int, ppos: int)
  returns ($r: int)
  modifies $Alloc, $CurrAddr, $exn, $exnv, $M.0, $M.1, $M.2, $M.3, $M.4, $M.5, $M.6, $M.7, $M.8, $M.9, $M.10, $M.11, $M.12, $M.13, $M.14, $M.15, $M.16, $M.17, $M.18, $M.19, $M.20, $M.21, $M.22, $M.23, $M.24, $M.25, $M.26, $M.27, $M.28, $M.29, $M.30, $M.31, $M.32, $M.33, $M.34, $M.35, $M.36, $M.37, $M.38;
{
  var $b1: bool;
  var $b11: bool;
  var $b14: bool;
  var $b18: bool;
  var $b5: bool;
  var $p0: int;
  var $p10: int;
  var $p12: int;
  var $p13: int;
  var $p15: int;
  var $p17: int;
  var $p2: int;
  var $p20: int;
  var $p21: int;
  var $p22: int;
  var $p23: int;
  var $p24: int;
  var $p25: int;
  var $p26: int;
  var $p3: int;
  var $p4: int;
  var $p6: int;
  var $p7: int;
  var $p8: int;
  var $p9: int;
$bb0:
  call {:cexpr "file"} boogie_si_record_int(file);
  call {:cexpr "buf"} boogie_si_record_int(buf);
  call {:cexpr "count"} boogie_si_record_int(count);
  call {:cexpr "ppos"} boogie_si_record_int(ppos);
  call {:cexpr "p"} boogie_si_record_int(buf);
  assume {:sourceloc "driver.re.c", 89, 7} true;
  call $p0 := access_ok(0, buf, count);
  assume {:sourceloc "driver.re.c", 89, 7} true;
  $b1 := ($p0 != 0);
  assume {:sourceloc "driver.re.c", 89, 7} true;
  goto $bb1, $bb2;
$bb1:
  assume $b1;
  assume {:sourceloc "driver.re.c", 91, 6} true;
  $p3 := $M.0[ppos];
  assume {:sourceloc "driver.re.c", 91, 6} true;
  $p4 := $M.3;
  assume {:sourceloc "driver.re.c", 91, 6} true;
  $b5 := $sge($p3, $p4);
  assume {:sourceloc "driver.re.c", 91, 6} true;
  goto $bb4, $bb5;
$bb2:
  assume !($b1);
  assume {:sourceloc "driver.re.c", 90, 3} true;
  $p2 := -14;
  goto $bb3;
$bb3:
  assume {:sourceloc "driver.re.c", 100, 1} true;
  $r := $p2;
  $exn := false;
  return;
$bb4:
  assume $b5;
  assume {:sourceloc "driver.re.c", 92, 3} true;
  $p2 := 0;
  goto $bb3;
$bb5:
  assume !($b5);
  assume {:sourceloc "driver.re.c", 93, 7} true;
  $p6 := $M.0[ppos];
  assume {:sourceloc "driver.re.c", 93, 7} true;
  $p7 := $trunc($p6, 32);
  call {:cexpr "i"} boogie_si_record_int($p7);
  assume {:sourceloc "driver.re.c", 93, 7} true;
  $p8 := $p7;
  $p9 := count;
  $p10 := buf;
  goto $bb6;
$bb6:
  assume {:sourceloc "driver.re.c", 93, 7} true;
  $b11 := $ugt($p9, 0);
  assume {:sourceloc "driver.re.c", 93, 7} true;
  goto $bb7, $bb8;
$bb7:
  assume $b11;
  assume {:sourceloc "driver.re.c", 93, 7} true;
  $p12 := $p8;
  assume {:sourceloc "driver.re.c", 93, 7} true;
  $p13 := $M.3;
  assume {:sourceloc "driver.re.c", 93, 7} true;
  $b14 := $slt($p12, $p13);
  assume {:sourceloc "driver.re.c", 93, 7} true;
  goto $bb10, $bb11;
$bb8:
  assume {:sourceloc "driver.re.c", 93, 7} true;
  assume !($b11);
  goto $bb9;
$bb9:
  assume {:sourceloc "driver.re.c", 98, 2} true;
  $p23 := $p8;
  assume {:sourceloc "driver.re.c", 98, 2} true;
  $M.0[ppos] := $p23;
  assume {:sourceloc "driver.re.c", 99, 2} true;
  $p24 := $p2i($p10);
  assume {:sourceloc "driver.re.c", 99, 2} true;
  $p25 := $p2i(buf);
  assume {:sourceloc "driver.re.c", 99, 2} true;
  $p26 := $sub($p24, $p25);
  assume {:sourceloc "driver.re.c", 99, 2} true;
  $p2 := $p26;
  goto $bb3;
$bb10:
  assume $b14;
  assume {:sourceloc "driver.re.c", 94, 7} true;
  $p15 := $u16;
  assume {:sourceloc "driver.re.c", 94, 7} true;
  call $p17 := __get_user($p15, $p10);
  assume {:sourceloc "driver.re.c", 94, 7} true;
  $b18 := ($p17 != 0);
  assume {:sourceloc "driver.re.c", 94, 7} true;
  goto $bb12, $bb13;
$bb11:
  assume {:sourceloc "driver.re.c", 93, 7} true;
  assume !($b14);
  goto $bb9;
$bb12:
  assume $b18;
  assume {:sourceloc "driver.re.c", 95, 4} true;
  $p2 := -14;
  goto $bb3;
$bb13:
  assume !($b18);
  assume {:sourceloc "driver.re.c", 96, 3} true;
  call nvram_write_byte($u19, $p8);
  assume {:sourceloc "driver.re.c", 93, 46} true;
  $p20 := $add($p8, 1);
  call {:cexpr "i"} boogie_si_record_int($p20);
  assume {:sourceloc "driver.re.c", 93, 46} true;
  $p21 := $pa($p10, 1, 1);
  call {:cexpr "p"} boogie_si_record_int($p21);
  assume {:sourceloc "driver.re.c", 93, 46} true;
  $p22 := $add($p9, -1);
  call {:cexpr "count"} boogie_si_record_int($p22);
  assume {:sourceloc "driver.re.c", 93, 46} true;
  $p8 := $p20;
  $p9 := $p22;
  $p10 := $p21;
  goto $bb6;
}
axiom (__SMACK_nondet.XXX == -34);
axiom (nvram_mutex == -5180);
axiom (nvram_len == -5188);
axiom (nvram_fops == -5388);
axiom (nvram_dev == -5458);
axiom (_whoop_init == -5466);
axiom (_whoop_exit == -5474);
axiom (jiffies == -5497);
axiom $NULL == 0;
axiom $and(0,0) == 0;
axiom $and(0,1) == 0;
axiom $and(1,0) == 0;
axiom $and(1,1) == 1;
axiom $or(0,0) == 0;
axiom $or(0,1) == 1;
axiom $or(1,0) == 1;
axiom $or(1,1) == 1;
axiom $xor(0,0) == 0;
axiom $xor(0,1) == 1;
axiom $xor(1,0) == 1;
axiom $xor(1,1) == 0;
axiom (forall f1, f2: float :: f1 != f2 || $foeq(f1,f2));
axiom (forall f: float :: $si2fp($fp2si(f)) == f);
axiom (forall f: float :: $ui2fp($fp2ui(f)) == f);
axiom (forall i: int :: $fp2si($si2fp(i)) == i);
axiom (forall i: int :: $fp2ui($ui2fp(i)) == i);
const $GLOBALS_BOTTOM: int;
const $MOP: $mop;
const $UNDEF: int;
const unique $NULL: int;
function $and(p1:int, p2:int) returns (int);
function $ashr(p1:int, p2:int) returns (int);
function $base(int) returns (int);
function $extractvalue(p: int, i: int) returns (int);
function $fadd(f1:float, f2:float) returns (float);
function $fdiv(f1:float, f2:float) returns (float);
function $ffalse(f1:float, f2:float) returns (bool);
function $fmul(f1:float, f2:float) returns (float);
function $foeq(f1:float, f2:float) returns (bool);
function $foge(f1:float, f2:float) returns (bool);
function $fogt(f1:float, f2:float) returns (bool);
function $fole(f1:float, f2:float) returns (bool);
function $folt(f1:float, f2:float) returns (bool);
function $fone(f1:float, f2:float) returns (bool);
function $ford(f1:float, f2:float) returns (bool);
function $fp(ipart:int, fpart:int, epart:int) returns (float);
function $fp2si(f:float) returns (int);
function $fp2ui(f:float) returns (int);
function $frem(f1:float, f2:float) returns (float);
function $fsub(f1:float, f2:float) returns (float);
function $ftrue(f1:float, f2:float) returns (bool);
function $fueq(f1:float, f2:float) returns (bool);
function $fuge(f1:float, f2:float) returns (bool);
function $fugt(f1:float, f2:float) returns (bool);
function $fule(f1:float, f2:float) returns (bool);
function $fult(f1:float, f2:float) returns (bool);
function $fune(f1:float, f2:float) returns (bool);
function $funo(f1:float, f2:float) returns (bool);
function $lshr(p1:int, p2:int) returns (int);
function $nand(p1:int, p2:int) returns (int);
function $or(p1:int, p2:int) returns (int);
function $shl(p1:int, p2:int) returns (int);
function $si2fp(i:int) returns (float);
function $ui2fp(i:int) returns (float);
function $xor(p1:int, p2:int) returns (int);
function {:builtin "div"} $sdiv(p1:int, p2:int) returns (int);
function {:builtin "div"} $udiv(p1:int, p2:int) returns (int);
function {:builtin "rem"} $srem(p1:int, p2:int) returns (int);
function {:builtin "rem"} $urem(p1:int, p2:int) returns (int);
function {:inline} $add(p1:int, p2:int) returns (int) {p1 + p2}
function {:inline} $b2i(b: bool) returns (int) {if b then 1 else 0}
function {:inline} $b2p(b: bool) returns (int) {if b then 1 else 0}
function {:inline} $i2b(i: int) returns (bool) {i != 0}
function {:inline} $i2p(p: int) returns (int) {p}
function {:inline} $isExternal(p: int) returns (bool) { p < $GLOBALS_BOTTOM - 32768 }
function {:inline} $max(p1:int, p2:int) returns (int) {if p1 > p2 then p1 else p2}
function {:inline} $min(p1:int, p2:int) returns (int) {if p1 > p2 then p2 else p1}
function {:inline} $mul(p1:int, p2:int) returns (int) {p1 * p2}
function {:inline} $p2b(p: int) returns (bool) {p != 0}
function {:inline} $p2i(p: int) returns (int) {p}
function {:inline} $pa(pointer: int, index: int, size: int) returns (int) {pointer + index * size}
function {:inline} $sge(p1:int, p2:int) returns (bool) {p1 >= p2}
function {:inline} $sgt(p1:int, p2:int) returns (bool) {p1 > p2}
function {:inline} $sle(p1:int, p2:int) returns (bool) {p1 <= p2}
function {:inline} $slt(p1:int, p2:int) returns (bool) {p1 < p2}
function {:inline} $sub(p1:int, p2:int) returns (int) {p1 - p2}
function {:inline} $trunc(p: int, size: int) returns (int) {p}
function {:inline} $uge(p1:int, p2:int) returns (bool) {p1 >= p2}
function {:inline} $ugt(p1:int, p2:int) returns (bool) {p1 > p2}
function {:inline} $ule(p1:int, p2:int) returns (bool) {p1 <= p2}
function {:inline} $ult(p1:int, p2:int) returns (bool) {p1 < p2}
function {:inline} $umax(p1:int, p2:int) returns (int) {if p1 > p2 then p1 else p2}
function {:inline} $umin(p1:int, p2:int) returns (int) {if p1 > p2 then p2 else p1}
procedure {:inline 1} $alloca(n: int) returns (p: int)
modifies $CurrAddr, $Alloc;
{
  assume $CurrAddr > 0;
  p := $CurrAddr;
  if (n > 0) {
    $CurrAddr := $CurrAddr + n;
  } else {
    $CurrAddr := $CurrAddr + 1;
  }
  $Alloc[p] := true;
}
procedure {:inline 1} $free(p: int)
modifies $Alloc;
{
  $Alloc[p] := false;
}
procedure {:inline 1} $malloc(n: int) returns (p: int)
modifies $CurrAddr, $Alloc;
{
  assume $CurrAddr > 0;
  p := $CurrAddr;
  if (n > 0) {
    $CurrAddr := $CurrAddr + n;
  } else {
    $CurrAddr := $CurrAddr + 1;
  }
  $Alloc[p] := true;
}
procedure $memcpy.36.36(dest: int, src: int, len: int, align: int, isvolatile: bool);
modifies $M.36;
ensures (forall x:int :: dest <= x && x < dest + len ==> $M.36[x] == old($M.36)[src - dest + x]);
ensures (forall x:int :: !(dest <= x && x < dest + len) ==> $M.36[x] == old($M.36)[x]);

procedure {:inline 1} boogie_si_record_bool(b: bool);
procedure {:inline 1} boogie_si_record_float(f: float);
procedure {:inline 1} boogie_si_record_int(i: int);
procedure {:inline 1} boogie_si_record_mop(m: $mop);
type $mop;
type float;
var $Alloc: [int] bool;
var $CurrAddr:int;
var $exn: bool;
var $exnv: int;

// END SMACK-GENERATED CODE
