/* Teaching adaptation of the synchronous-counter example in VSTTE 2016. */
extern void __VERIFIER_error(void);
int main(void) {
  unsigned int x = 0;
  unsigned int y = 0;
  while (x < 12) {
    x++;
    y++;
    unsigned int z = y;
    if (x != z) {
      __VERIFIER_error();
    }
  }
  return 0;
}
