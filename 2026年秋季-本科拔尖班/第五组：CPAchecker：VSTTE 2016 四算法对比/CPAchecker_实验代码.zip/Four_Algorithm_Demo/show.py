#!/usr/bin/env python3
"""Execute the same example with four author configurations; show actual evidence."""
import json
import pathlib
import re
import sys
import datetime

DEMO=pathlib.Path(__file__).resolve().parent
ROOT=DEMO.parent
sys.path.insert(0,str(ROOT/'scripts'))
from experiment_runner import ALGORITHM_OPTIONS, build_cpachecker_command, execute_run
STATE=DEMO/'filming_session.json'
TITLES={'bmc':'BMC','k-induction':'k-induction','predicate':'Predicate CEGAR','impact':'Impact'}

def state():return json.loads(STATE.read_text()) if STATE.exists() else {}
def messages(path):
    output=[]
    for line in path.read_text(errors='replace').splitlines():
        fields=line.split('\t',3)
        if len(fields)==4 and fields[1]!='CONFIG':output.append(fields[3])
    return output
def stats(text,labels):
    for label in labels:
        line=next((x.strip() for x in text.splitlines() if x.strip().startswith(label)),None)
        if line:print(re.sub(r'\s{2,}',' ',line))
def equations(text):
    return list(dict.fromkeys(f'{a} = {b}' for a,b in re.findall(r'\(= \|main::(\w+)\| \|main::(\w+)\|\)',text)))

def run(alg):
    stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    run_dir=DEMO/'filming_runs'/f'{stamp}-{alg}'
    artifacts=run_dir/'artifacts'
    command=build_cpachecker_command(alg,str(DEMO/'code/example.c'),str(DEMO/'code/ALL.prp'),1200,55)
    command.remove('-noout')
    command[1:1]=['-outputpath',str(artifacts),'-setprop','log.level=FINE']
    print(f'{TITLES[alg]} / example.c',flush=True)
    print('正在执行验证……',flush=True)
    result=execute_run(command,cwd=ROOT/'supplements-vstte/CPAchecker',output_dir=run_dir,
        wall_limit_s=60,expected='true',metadata={'phase':'four_algorithm_filming','algorithm':alg,'task_id':'example','heap_mb':1200,'internal_time_s':55})
    saved=state();saved[alg]=str(run_dir)
    STATE.write_text(json.dumps(saved,indent=2),encoding='utf-8')
    text=(run_dir/'run.log').read_text(errors='replace')
    events=messages(artifacts/'CPALog.txt') if (artifacts/'CPALog.txt').exists() else []
    print('\n本次运行的关键过程：')
    if alg=='bmc':
        print('maxLoopIterations 初值：1（运行配置）')
        bounds=[]
        for event in events:
            if event.startswith('Adjusting maxLoopIterations'):
                bounds.append(event.rsplit(' ',1)[-1])
        if bounds:
            print('日志中的界限调整：')
            print('  1 -> '+' -> '.join(bounds))
        stats(text,['Bound k:'])
    elif alg=='k-induction':
        base=next((event for event in events if event=='Starting satisfiability check...'),None)
        if base:print('Base case: '+base)
        for event in events:
            if event.startswith(('Running algorithm to create induction hypothesis','Starting induction check')):print(event)
        for event in events:
            if event.endswith('finished successfully.'):
                if 'invariantGeneration-no-out.properties' in event:
                    print('Proof completed by parallel invariant generator.')
                elif 'k-induction-noAI.properties' in event:
                    print('Proof completed by k-induction analysis.')
        stats(text,['Bound k:','Time for induction check:'])
    else:
        for event in events:
            if event.startswith(('Using refinement for predicate analysis','Error found, performing CEGAR','Refinement successful:')):print(event)
        stats(text,['Number of predicates discovered:','Number of refinements:','Number of successful refinements:'])
        if alg=='impact':stats(text,['Attempted forced coverings:','Successful forced coverings:'])
    print('')
    answer=next((line for line in text.splitlines() if line.startswith('Verification result:')),None)
    print(answer or f"结果分类：{result['category']}")
    print(f"工具退出码：{result['exit_code']}")
    print(f'本次输出：{run_dir.name}')
    if result['category']!='CORRECT_PROOF':
        print(f'请保留日志：{run_dir}/run.log')
        raise SystemExit(1)

def detail(alg):
    saved=state()
    if alg not in saved:raise SystemExit(f'请先执行：python3 Four_Algorithm_Demo/show.py run {alg}')
    run_dir=pathlib.Path(saved[alg]);artifacts=run_dir/'artifacts'
    if alg=='predicate':
        print('本次 predmap.txt 中的关系谓词（简写变量前缀）：\n')
        for equation in equations((artifacts/'predmap.txt').read_text()):print('  '+equation)
        print('\n谓词表用于定义抽象精度；原始文件：artifacts/predmap.txt')
    elif alg=='impact':
        text=(artifacts/'abstractions.txt').read_text()
        print('本次 abstractions.txt 中的节点公式（简写变量前缀）：\n')
        blocks=re.split(r'(?m)^(\d+) \(([^)]*)\) @(\d+):\s*\n',text)
        formulas={}
        for i in range(1,len(blocks),4):
            number,_,location,body=blocks[i:i+4]
            eqs=equations(body)
            if eqs:
                formulas[number]=' AND '.join(eqs)
                print(f"  ABS{number} @ N{location}: {formulas[number]}")
        dot=(artifacts/'ARG.dot').read_text()
        nodes={node:absid for node,absid in re.findall(r'(?m)^(\d+) \[.*?AbstractionState: ABS(\d+)',dot)}
        print('\n本次 ARG.dot 中的覆盖关系：')
        for newer,older in re.findall(r'(?m)^(\d+) -> (\d+) \[style="dashed".*?label="covered by"',dot):
            print(f'  节点 {newer} 被节点 {older} 覆盖')
            if newer in nodes and older in nodes:
                print(f'  ABS{nodes[newer]} => ABS{nodes[older]}')
        print('\n原始文件：artifacts/abstractions.txt 与 artifacts/ARG.dot')
    else:
        text=(run_dir/'run.log').read_text(errors='replace')
        stats(text,['Bound k:','Maximum loop iteration reached:','Time for induction check:'])
        if alg=='k-induction':
            print('\n本次完成证明的实际分析分支：')
            for event in messages(artifacts/'CPALog.txt'):
                if event.endswith('finished successfully.'):print(event)

def main():
    args=sys.argv[1:]
    if args==['code']:
        for n,line in enumerate((DEMO/'code/example.c').read_text().splitlines(),1):
            if n>1:print(f'{n:2d}  {line}')
    elif len(args)==2 and args[1] in ALGORITHM_OPTIONS and args[0] in ('run','detail'):
        (run if args[0]=='run' else detail)(args[1])
    else:raise SystemExit('Usage: show.py code | run ALGORITHM | detail ALGORITHM')

if __name__=='__main__':main()
