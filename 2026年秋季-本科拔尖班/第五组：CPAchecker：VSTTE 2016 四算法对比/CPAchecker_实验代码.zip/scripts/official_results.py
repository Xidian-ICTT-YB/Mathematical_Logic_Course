#!/usr/bin/env python3
"""Read the official VSTTE 2016 DeviceDriversLinux64 comparison table."""

import csv


ALGORITHM_MARKERS = {
    "bmc": "bmc-bitprecise",
    "k-induction": "k-induction-bitprecise",
    "predicate": "predicateanalysis-bitprecise",
    "impact": "impact-bitprecise",
}


def _number(value, cast=float):
    return cast(value) if value else None


def read_official_results(path):
    with open(path, encoding="utf-8", newline="") as source:
        rows = list(csv.reader(source, delimiter="\t"))

    run_sets = rows[1]
    columns = rows[2]
    indexes = {}
    for algorithm, marker in ALGORITHM_MARKERS.items():
        matching = [
            index
            for index, run_set in enumerate(run_sets)
            if marker in run_set.lower()
        ]
        indexes[algorithm] = {
            "status": next(index for index in matching if columns[index] == "status"),
            "walltime": next(
                index for index in matching if columns[index] == "walltime (s)"
            ),
            "mem_bytes": next(
                index for index in matching if columns[index] == "memUsage"
            ),
        }

    records = []
    for row in rows[3:]:
        if not row or not row[0]:
            continue
        algorithms = {}
        for algorithm, fields in indexes.items():
            algorithms[algorithm] = {
                "status": row[fields["status"]],
                "walltime": _number(row[fields["walltime"]]),
                "mem_bytes": _number(row[fields["mem_bytes"]], int),
            }
        records.append({"task": row[0], "algorithms": algorithms})
    return records
