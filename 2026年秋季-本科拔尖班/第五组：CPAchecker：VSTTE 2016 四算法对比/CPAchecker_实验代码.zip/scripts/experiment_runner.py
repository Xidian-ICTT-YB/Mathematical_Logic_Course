#!/usr/bin/env python3
"""Build, execute, and classify reproducible CPAchecker runs."""

import datetime
import argparse
import collections
import csv
import json
import pathlib
import shlex
import subprocess


COMMON_OPTIONS = [
    "-noout",
    "-stats",
    "-64",
]

ALGORITHM_OPTIONS = {
    "bmc": [
        "-bmc",
        "-setprop",
        "solver.solver=MATHSAT5",
        "-setprop",
        "cpa.predicate.encodeBitvectorAs=BITVECTOR",
        "-setprop",
        "cpa.predicate.encodeFloatAs=FLOAT",
        "-setprop",
        "analysis.checkCounterexamples=true",
        "-setprop",
        "counterexample.checker=CBMC",
        "-setprop",
        "cpa.bounds.maxLoopIterationsUpperBound=0",
        "-setprop",
        "cpa.bounds.maxLoopIterations=1",
        "-setprop",
        "cpa.bounds.maxLoopIterationAdjusterFactory=INCREMENT",
    ],
    "k-induction": [
        "-sv-comp16--k-induction",
        "-setprop",
        "limits.time.cpu.thread=10000s",
    ],
    "predicate": [
        "-predicateAnalysis-PredAbsRefiner-ABEl-bitprecise",
        "-setprop",
        "cpa.predicate.encodeFloatAs=FLOAT",
        "-setprop",
        "analysis.checkCounterexamples=true",
        "-setprop",
        "counterexample.checker=CBMC",
    ],
    "impact": [
        "-predicateAnalysis-ImpactRefiner-ABEl-bitprecise",
        "-setprop",
        "cpa.predicate.encodeFloatAs=FLOAT",
        "-setprop",
        "analysis.checkCounterexamples=true",
        "-setprop",
        "counterexample.checker=CBMC",
        "-setprop",
        "cpa.forcedCovering=cpa.predicate.PredicateForcedCovering",
    ],
}


def read_manifest(path):
    with open(path, encoding="utf-8", newline="") as source:
        tasks = list(csv.DictReader(source, delimiter="\t"))
    for task in tasks:
        task["specification"] = str(
            pathlib.PurePosixPath(task["task"]).parent / "ALL.prp"
        )
    return tasks


def build_cpachecker_command(
    algorithm, task, specification, heap_mb, internal_time_s
):
    return [
        "scripts/cpa.sh",
        "-heap",
        f"{heap_mb}M",
        *COMMON_OPTIONS,
        *ALGORITHM_OPTIONS[algorithm],
        "-timelimit",
        f"{internal_time_s}s",
        "-spec",
        specification,
        task,
    ]


def classify_run(log_text, exit_code, expected, max_rss_kb=0):
    lower = log_text.lower()
    if (
        "outofmemoryerror" in lower
        or "insufficient memory" in lower
        or "std::bad_alloc" in lower
    ):
        return {"raw_result": "OOM", "category": "OOM"}
    if "verification result: true" in lower:
        category = "CORRECT_PROOF" if expected == "true" else "WRONG_RESULT"
        return {"raw_result": "TRUE", "category": category}
    if "verification result: false" in lower:
        category = (
            "CORRECT_COUNTEREXAMPLE" if expected == "false" else "WRONG_RESULT"
        )
        return {"raw_result": "FALSE", "category": category}
    if "time limit" in lower and "elapsed" in lower:
        return {"raw_result": "TIMEOUT", "category": "TIMEOUT"}
    if exit_code == 124:
        return {"raw_result": "TIMEOUT", "category": "TIMEOUT"}
    if exit_code == 137 and max_rss_kb >= 2_000_000:
        return {"raw_result": "OOM", "category": "OOM"}
    if (
        "unsupported c feature" in lower
        or "recursion detected" in lower
        or "verification result: error" in lower
    ):
        return {"raw_result": "ERROR", "category": "TOOL_ERROR"}
    if "verification result: unknown" in lower:
        return {"raw_result": "UNKNOWN", "category": "UNKNOWN"}
    return {"raw_result": "ERROR", "category": "TOOL_ERROR"}


def _time_metrics(text):
    metrics = {}
    labels = {
        "Elapsed (wall clock) time (h:mm:ss or m:ss)": "wall_time",
        "User time (seconds)": "user_time_s",
        "System time (seconds)": "system_time_s",
        "Maximum resident set size (kbytes)": "max_rss_kb",
        "Exit status": "time_exit_status",
    }
    for line in text.splitlines():
        stripped = line.strip()
        for label, key in labels.items():
            prefix = f"{label}: "
            if stripped.startswith(prefix):
                value = stripped[len(prefix) :]
                metrics[key] = (
                    int(value)
                    if key in {"max_rss_kb", "time_exit_status"}
                    else value
                )
    return metrics


def execute_run(
    command, *, cwd, output_dir, wall_limit_s, expected, metadata
):
    output_dir = pathlib.Path(output_dir)
    status_path = output_dir / "status.json"
    if status_path.is_file():
        status = json.loads(status_path.read_text(encoding="utf-8"))
        if status.get("complete"):
            log_path = output_dir / "run.log"
            if log_path.is_file():
                status.update(
                    classify_run(
                        log_path.read_text(encoding="utf-8", errors="replace"),
                        status["exit_code"],
                        status["expected"],
                        status.get("max_rss_kb", 0),
                    )
                )
            status["resumed"] = True
            _write_json_atomic(status_path, status)
            return status

    output_dir.mkdir(parents=True, exist_ok=True)
    time_path = output_dir / "time.txt"
    log_path = output_dir / "run.log"
    (output_dir / "command.txt").write_text(
        shlex.join(command) + "\n", encoding="utf-8"
    )

    full_command = [
        "/usr/bin/time",
        "-v",
        "-o",
        str(time_path),
        "timeout",
        "--signal=TERM",
        "--kill-after=5s",
        f"{wall_limit_s}s",
        *command,
    ]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with log_path.open("w", encoding="utf-8") as log:
        completed = subprocess.run(
            full_command,
            cwd=cwd,
            stdout=log,
            stderr=subprocess.STDOUT,
            check=False,
        )
    finished = datetime.datetime.now(datetime.timezone.utc).isoformat()

    log_text = log_path.read_text(encoding="utf-8", errors="replace")
    metrics = _time_metrics(
        time_path.read_text(encoding="utf-8", errors="replace")
    )
    status = {
        **metadata,
        **classify_run(
            log_text,
            completed.returncode,
            expected,
            metrics.get("max_rss_kb", 0),
        ),
        **metrics,
        "expected": expected,
        "exit_code": completed.returncode,
        "wall_limit_s": wall_limit_s,
        "started_utc": started,
        "finished_utc": finished,
        "complete": True,
        "resumed": False,
    }
    temporary = status_path.with_suffix(".json.tmp")
    temporary.write_text(
        json.dumps(status, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(status_path)
    return status


def _write_json_atomic(path, value):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest", type=pathlib.Path)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--wall-limit", type=int, default=60)
    parser.add_argument("--internal-time", type=int, default=55)
    parser.add_argument("--heap-mb", type=int, default=1200)
    parser.add_argument(
        "--algorithms",
        default="bmc,k-induction,predicate,impact",
    )
    args = parser.parse_args()

    root = pathlib.Path(__file__).resolve().parents[1]
    cpachecker = root / "supplements-vstte" / "CPAchecker"
    benchmark_prefix = pathlib.PurePosixPath("test/programs/benchmarks")
    algorithms = args.algorithms.split(",")
    tasks = read_manifest(args.manifest)
    records = []
    for task in tasks:
        for algorithm in algorithms:
            command = build_cpachecker_command(
                algorithm,
                str(benchmark_prefix / task["task"]),
                str(benchmark_prefix / task["specification"]),
                args.heap_mb,
                args.internal_time,
            )
            output = root / "runs" / args.phase / task["id"] / algorithm
            status = execute_run(
                command,
                cwd=cpachecker,
                output_dir=output,
                wall_limit_s=args.wall_limit,
                expected=task["expected"],
                metadata={
                    "phase": args.phase,
                    "algorithm": algorithm,
                    "task_id": task["id"],
                    "task": task["task"],
                    "specification": task["specification"],
                    "rationale": task["rationale"],
                    "heap_mb": args.heap_mb,
                    "internal_time_s": args.internal_time,
                },
            )
            records.append(status)
            print(
                f"{task['id']}\t{algorithm}\t{status['category']}\t"
                f"{status.get('wall_time', '')}\tresume={status['resumed']}",
                flush=True,
            )

    summary = {
        "phase": args.phase,
        "task_count": len(tasks),
        "run_count": len(records),
        "categories": dict(
            sorted(collections.Counter(r["category"] for r in records).items())
        ),
        "records": records,
    }
    _write_json_atomic(root / "runs" / args.phase / "summary.json", summary)


if __name__ == "__main__":
    main()
