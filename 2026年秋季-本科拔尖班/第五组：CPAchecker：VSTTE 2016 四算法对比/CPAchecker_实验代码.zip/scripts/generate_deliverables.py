#!/usr/bin/env python3
"""Generate the Chinese handoff and reproduction package from real run data."""

import argparse
import collections
import csv
import difflib
import hashlib
import json
import math
import pathlib
import re
import shutil
import statistics
import tarfile


ALGORITHMS = ["bmc", "k-induction", "predicate", "impact"]
ALGORITHM_ZH = {
    "bmc": "BMC",
    "k-induction": "k-induction",
    "predicate": "谓词抽象 CEGAR",
    "impact": "Impact",
}
CATEGORIES = [
    "CORRECT_PROOF",
    "CORRECT_COUNTEREXAMPLE",
    "WRONG_RESULT",
    "UNKNOWN",
    "TIMEOUT",
    "OOM",
    "TOOL_ERROR",
]
CATEGORY_ZH = {
    "CORRECT_PROOF": "正确证明",
    "CORRECT_COUNTEREXAMPLE": "正确反例",
    "WRONG_RESULT": "错误结论",
    "UNKNOWN": "UNKNOWN",
    "TIMEOUT": "TIMEOUT",
    "OOM": "OOM",
    "TOOL_ERROR": "工具异常",
}


def wall_time_to_seconds(value):
    parts = [float(part) for part in value.split(":")]
    if len(parts) == 2:
        return parts[0] * 60 + parts[1]
    if len(parts) == 3:
        return parts[0] * 3600 + parts[1] * 60 + parts[2]
    return parts[0]


def collect_records(run_root):
    records = []
    for status_path in sorted(pathlib.Path(run_root).glob("*/*/status.json")):
        record = json.loads(status_path.read_text(encoding="utf-8"))
        record["wall_seconds"] = wall_time_to_seconds(record["wall_time"])
        record["status_path"] = str(status_path.resolve())
        record["run_dir"] = str(status_path.parent.resolve())
        records.append(record)
    return records


def summarize_algorithms(records):
    output = {}
    for algorithm in ALGORITHMS:
        rows = [row for row in records if row["algorithm"] == algorithm]
        counts = collections.Counter(row["category"] for row in rows)
        correct = [
            row
            for row in rows
            if row["category"] in {"CORRECT_PROOF", "CORRECT_COUNTEREXAMPLE"}
        ]
        output[algorithm] = {
            "algorithm": algorithm,
            **{category: counts[category] for category in CATEGORIES},
            "total": len(rows),
            "correct_total": len(correct),
            "correct_rate": len(correct) / len(rows) if rows else 0,
            "median_wall_s": statistics.median(
                row["wall_seconds"] for row in rows
            ),
            "median_correct_wall_s": (
                statistics.median(row["wall_seconds"] for row in correct)
                if correct
                else None
            ),
            "total_wall_s": sum(row["wall_seconds"] for row in rows),
        }
    return output


def _write_csv(path, fieldnames, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as target:
        writer = csv.DictWriter(target, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _markdown_table(headers, rows):
    lines = [
        "| " + " | ".join(headers) + " |",
        "|" + "|".join(["---"] * len(headers)) + "|",
    ]
    lines.extend("| " + " | ".join(str(value) for value in row) + " |" for row in rows)
    return "\n".join(lines)


def _chart_context():
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager

    font_path = pathlib.Path("/mnt/c/Windows/Fonts/msyh.ttc")
    if font_path.is_file():
        font_manager.fontManager.addfont(font_path)
        name = font_manager.FontProperties(fname=font_path).get_name()
        plt.rcParams["font.sans-serif"] = [name]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["figure.facecolor"] = "white"
    return plt


def _generate_charts(records, summary, figures):
    plt = _chart_context()
    figures.mkdir(parents=True, exist_ok=True)
    colors = {
        "CORRECT_PROOF": "#4C78A8",
        "CORRECT_COUNTEREXAMPLE": "#59A14F",
        "WRONG_RESULT": "#E15759",
        "UNKNOWN": "#BAB0AC",
        "TIMEOUT": "#F28E2B",
        "OOM": "#B07AA1",
        "TOOL_ERROR": "#9C755F",
    }

    fig, ax = plt.subplots(figsize=(11, 6.2))
    bottoms = [0] * len(ALGORITHMS)
    for category in CATEGORIES:
        values = [summary[algorithm][category] for algorithm in ALGORITHMS]
        bars = ax.bar(
            [ALGORITHM_ZH[a] for a in ALGORITHMS],
            values,
            bottom=bottoms,
            label=CATEGORY_ZH[category],
            color=colors[category],
        )
        for bar, value, bottom in zip(bars, values, bottoms):
            if value:
                ax.text(
                    bar.get_x() + bar.get_width() / 2,
                    bottom + value / 2,
                    str(value),
                    ha="center",
                    va="center",
                    color="white" if category != "UNKNOWN" else "black",
                    fontsize=9,
                    fontweight="bold",
                )
        bottoms = [bottom + value for bottom, value in zip(bottoms, values)]
    ax.set_title("四算法验证结果分类（24 个任务，每算法 24 次）")
    ax.set_ylabel("运行次数")
    ax.set_ylim(0, 27)
    ax.grid(axis="y", alpha=0.25)
    ax.legend(ncol=4, loc="upper center", bbox_to_anchor=(0.5, -0.10))
    fig.tight_layout()
    fig.savefig(figures / "四算法验证结果.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(10.5, 6.2))
    data = [
        [row["wall_seconds"] for row in records if row["algorithm"] == algorithm]
        for algorithm in ALGORITHMS
    ]
    box = ax.boxplot(data, patch_artist=True, tick_labels=[ALGORITHM_ZH[a] for a in ALGORITHMS])
    for patch, color in zip(box["boxes"], ["#4C78A8", "#F28E2B", "#59A14F", "#B07AA1"]):
        patch.set_facecolor(color)
        patch.set_alpha(0.72)
    medians = [statistics.median(values) for values in data]
    ax.scatter(range(1, 5), medians, color="black", marker="D", label="中位数")
    ax.set_yscale("log")
    ax.set_ylabel("墙钟时间（秒，对数尺度）")
    ax.set_title("四算法单任务运行时间分布")
    ax.grid(axis="y", alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(figures / "四算法运行时间.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

    selected_ids = [
        "S02_kind_only",
        "S10_bmc_oom",
        "U02_bmc_gap",
        "U11_vhost_oom",
        "U12_mpt2sas_timeout",
    ]
    selected = {
        (row["task_id"], row["algorithm"]): row
        for row in records
        if row["task_id"] in selected_ids
    }
    fig, ax = plt.subplots(figsize=(13, 7))
    width = 0.19
    x_values = list(range(len(selected_ids)))
    algorithm_colors = ["#4C78A8", "#F28E2B", "#59A14F", "#B07AA1"]
    short = {
        "S02_kind_only": "S02 仅 k-induction",
        "S10_bmc_oom": "S10 BMC 超时",
        "U02_bmc_gap": "U02 BMC 递归异常",
        "U11_vhost_oom": "U11 Predicate/Impact OOM",
        "U12_mpt2sas_timeout": "U12 BMC/k-induction 超时",
    }
    symbols = {
        "CORRECT_PROOF": "证",
        "CORRECT_COUNTEREXAMPLE": "反",
        "WRONG_RESULT": "错",
        "UNKNOWN": "?",
        "TIMEOUT": "超",
        "OOM": "OOM",
        "TOOL_ERROR": "异",
    }
    for index, algorithm in enumerate(ALGORITHMS):
        values = [selected[(task_id, algorithm)]["wall_seconds"] for task_id in selected_ids]
        positions = [x + (index - 1.5) * width for x in x_values]
        bars = ax.bar(positions, values, width, label=ALGORITHM_ZH[algorithm], color=algorithm_colors[index])
        for bar, task_id in zip(bars, selected_ids):
            category = selected[(task_id, algorithm)]["category"]
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 0.8,
                symbols[category],
                ha="center",
                va="bottom",
                fontsize=8,
            )
    ax.set_xticks(x_values, [short[value] for value in selected_ids], rotation=12, ha="right")
    ax.set_ylabel("墙钟时间（秒）")
    ax.set_title("典型任务的算法差异（柱顶：证/反/超/OOM/异）")
    ax.grid(axis="y", alpha=0.25)
    ax.legend(ncol=4)
    fig.tight_layout()
    fig.savefig(figures / "典型任务差异.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def _write_reports(root, handoff, records, summary):
    total = len(records)
    correct = sum(row["correct_total"] for row in summary.values())
    wrong = sum(row["WRONG_RESULT"] for row in summary.values())
    summary_rows = []
    for algorithm in ALGORITHMS:
        row = summary[algorithm]
        summary_rows.append(
            [
                ALGORITHM_ZH[algorithm],
                row["CORRECT_PROOF"],
                row["CORRECT_COUNTEREXAMPLE"],
                row["TIMEOUT"],
                row["OOM"],
                row["TOOL_ERROR"],
                row["UNKNOWN"],
                row["WRONG_RESULT"],
                f"{row['correct_rate']:.1%}",
                f"{row['median_wall_s']:.2f}",
            ]
        )

    settings = """# 实验设置

## 实验目标

比较 CPAchecker 补充包中的 BMC、k-induction、Predicate Abstraction with CEGAR、Impact 四种 SMT 软件模型检测算法。正式矩阵为 24 个 SV-COMP 2016 DeviceDriversLinux64 任务 × 4 种算法，共 96 次真实运行。

## 数据与版本

- 官方补充包 SHA-256：0e531f81b8fa079b3611fe22c6c7d3261ed7dbbf9210b23346abab33d14aefe9。
- SV-COMP 数据标签：svcomp16；提交 dbb9372541d3c068d970a2b76a92d8fa8f9a9d48。
- JAR 实际版本：CPAchecker 1.6.1-svn 23022；网页描述与历史 CSV 的版本标识不同，详见 environment_report.md。
- SMT：MathSAT5 5.3.12（归档内置 JNI）。
- Java：OpenJDK 11.0.29；对旧 cpa.sh 仅修复 Java 主版本解析。

## 运行协议

- WSL2 Ubuntu 22.04，x86_64，DeviceDriversLinux64 统一使用 -64。
- 单并发；所有算法均使用 JVM heap 1200 MiB、CPAchecker CPU 时间 55 秒、外部墙钟 60 秒（另给 5 秒 TERM→KILL 清理）。
- GNU time -v 保存时间、RSS、退出信息；每次运行保存 command.txt、run.log、time.txt、status.json。
- 预实验 4×4=16 次通过后，正式实验重新执行完整 24×4=96 次。

## 与论文协议的差异

- 作者 XML：900 秒 CPU、1000 秒 hard time、15 GB、10 GB heap、2 核；本实验受 3.8 GiB WSL 内存限制而降低资源。
- 归档 BenchExec 1.10-dev 只识别 cgroups v1；当前 WSL 是不可委派的 cgroups v2，因此不能可靠施限。
- 替代方案没有进程树聚合内存硬限；以单并发、JVM heap 和运行中 RSS 审计控制风险。
- Swap 保持启用；未使用 sudo 或修改系统配置。
- 两个 SIGKILL/OOM 运行的外层 GNU time RSS 不可靠；原始日志 std::bad_alloc 与运行中约 3.64 GiB RSS 快照是 OOM 依据。
- 任务是按安全/不安全与官方历史算法差异有意分层的 24 项样本，不代表完整 DeviceDriversLinux64 总体分布。
"""
    (handoff / "实验设置.md").write_text(settings, encoding="utf-8")

    table = _markdown_table(
        ["算法", "正确证明", "正确反例", "超时", "OOM", "工具异常", "UNKNOWN", "错误结论", "正确率", "时间中位数/s"],
        summary_rows,
    )
    best_correct = max(summary.values(), key=lambda row: row["correct_total"])
    fastest = min(summary.values(), key=lambda row: row["median_wall_s"])
    conclusion = f"""# 实验结论

## 总览

- 正式实验完成 {total}/96 次，未将失败运行视为完成。
- 正确结论 {correct} 次（正确证明与正确反例合计），错误结论 {wrong} 次。
- 其余运行按原始证据分类为 TIMEOUT、OOM、UNKNOWN 或工具异常。

{table}

## 直接观察

1. 本样本中正确结论最多的是 {ALGORITHM_ZH[best_correct['algorithm']]}（{best_correct['correct_total']}/24）。
2. 全部运行墙钟中位数最低的是 {ALGORITHM_ZH[fastest['algorithm']]}（{fastest['median_wall_s']:.2f} 秒）。
3. k-induction 在 S02/S03/S04 等递归任务上能给出证明，而其他配置因递归支持限制返回工具异常。
4. U11 上 Predicate 与 Impact 均出现 std::bad_alloc；BMC 找到真实反例，k-induction 达到时间限制。
5. U12 上 Predicate 与 Impact 找到反例，而 BMC 与 k-induction 达到时间限制。

## 解释边界

这些结论只针对固定的 24 项有意分层样本和本机 55/60 秒、1200 MiB heap 协议。由于资源限制、Java 版本、BenchExec/cgroup 能力和工具版本标识均与论文环境不同，不应用本结果推断论文完整数据集上的总体排名。
"""
    (handoff / "实验结论.md").write_text(conclusion, encoding="utf-8")

    false_groups = collections.defaultdict(list)
    for record in records:
        if record["expected"] == "false" and record["category"] == "CORRECT_COUNTEREXAMPLE":
            false_groups[record["task_id"]].append(record)
    candidates = []
    for task_id, rows in sorted(false_groups.items(), key=lambda item: (-len(item[1]), item[0]))[:6]:
        line_numbers = set()
        for row in rows:
            log = pathlib.Path(row["run_dir"]) / "run.log"
            for match in re.finditer(r"called in line (\d+)", log.read_text(encoding="utf-8", errors="replace")):
                line_numbers.add(match.group(1))
        candidates.append(
            [
                task_id,
                len(rows),
                "、".join(ALGORITHM_ZH[row["algorithm"]] for row in rows),
                "、".join(sorted(line_numbers, key=int)) or "日志未给行号",
                rows[0]["task"],
            ]
        )
    candidate_doc = """# 真实错误轨迹候选

下列任务的文件名预期为不安全，且本实验至少一个算法输出明确 FALSE 与属性违例位置；它们适合 PPT 中展示真实反例。由于正式运行遵循作者的 -noout，未额外导出 GraphML，原始 run.log 是当前证据。

""" + _markdown_table(["任务 ID", "找到反例的算法数", "算法", "违例行", "源任务"], candidates)
    (handoff / "cases" / "真实错误轨迹候选.md").write_text(candidate_doc, encoding="utf-8")

    by_task = collections.defaultdict(dict)
    for record in records:
        by_task[record["task_id"]][record["algorithm"]] = record
    difference_ids = [
        task_id
        for task_id, values in by_task.items()
        if len({row["category"] for row in values.values()}) > 1
    ]
    difference_rows = []
    for task_id in difference_ids:
        values = by_task[task_id]
        difference_rows.append(
            [
                task_id,
                *[
                    f"{CATEGORY_ZH[values[a]['category']]} / {values[a]['wall_seconds']:.2f}s"
                    for a in ALGORITHMS
                ],
            ]
        )
    difference_doc = """# 算法差异案例

仅列出四算法分类不完全一致的任务；时间为本次墙钟时间。递归警告若仍有明确 TRUE/FALSE，按有效结论分类。

""" + _markdown_table(
        ["任务 ID", "BMC", "k-induction", "谓词 CEGAR", "Impact"],
        difference_rows,
    )
    (handoff / "cases" / "算法差异案例.md").write_text(difference_doc, encoding="utf-8")


def _sha256(path):
    digest = hashlib.sha256()
    with pathlib.Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _build_reproduction(root, reproduction, records):
    (reproduction / "scripts").mkdir(parents=True, exist_ok=True)
    (reproduction / "manifests").mkdir(parents=True, exist_ok=True)
    (reproduction / "configs").mkdir(parents=True, exist_ok=True)
    (reproduction / "results").mkdir(parents=True, exist_ok=True)
    for path in sorted((root / "scripts").glob("*.py")):
        shutil.copy2(path, reproduction / "scripts" / path.name)
    for name in ("formal24.tsv", "preexperiment.tsv"):
        shutil.copy2(root / "manifests" / name, reproduction / "manifests" / name)

    cpa = root / "supplements-vstte" / "CPAchecker"
    configs = [
        "test/test-sets/bmc-bitprecise.xml",
        "test/test-sets/k-induction-bitprecise.xml",
        "test/test-sets/predicateAnalysis-bitprecise.xml",
        "test/test-sets/impact-bitprecise.xml",
    ]
    for relative in configs:
        source = cpa / relative
        shutil.copy2(source, reproduction / "configs" / source.name)
    shutil.copy2(cpa / "scripts" / "cpa.sh", reproduction / "configs" / "cpa.sh")

    archive = root / "supplements-vstte.tar.bz2"
    with tarfile.open(archive, "r:bz2") as bundle:
        original = bundle.extractfile("supplements-vstte/CPAchecker/scripts/cpa.sh").read().decode("utf-8")
    patched = (cpa / "scripts" / "cpa.sh").read_text(encoding="utf-8")
    patch = "".join(
        difflib.unified_diff(
            original.splitlines(True),
            patched.splitlines(True),
            fromfile="cpa.sh.original",
            tofile="cpa.sh.java11-compatible",
        )
    )
    (reproduction / "configs" / "cpa.sh.patch").write_text(patch, encoding="utf-8")
    shutil.copy2(root / "runs" / "formal24" / "summary.json", reproduction / "results" / "formal24-summary.json")
    shutil.copy2(root / "runs" / "preexperiment" / "summary.json", reproduction / "results" / "preexperiment-summary.json")
    shutil.copy2(root / "environment_report.md", reproduction / "environment_report.md")

    versions = f"""CPAchecker JAR: 1.6.1-svn 23022
MathSAT5: 5.3.12 (fd820dac73f2), 64-bit
Java: OpenJDK 11.0.29
WSL kernel: 6.18.40.1-microsoft-standard-WSL2
SV-COMP tag: svcomp16
SV-COMP commit: dbb9372541d3c068d970a2b76a92d8fa8f9a9d48
BenchExec packaged script: 1.10-dev (unusable for limits on this cgroups-v2 WSL)
Supplement SHA-256: {_sha256(archive)}
Formal runs: 96
"""
    (reproduction / "versions.txt").write_text(versions, encoding="utf-8")

    index_rows = []
    for record in records:
        run_dir = pathlib.Path(record["run_dir"])
        for name in ("command.txt", "run.log", "time.txt", "status.json"):
            path = run_dir / name
            index_rows.append(
                {
                    "task_id": record["task_id"],
                    "algorithm": record["algorithm"],
                    "artifact": name,
                    "linux_path": str(path),
                    "bytes": path.stat().st_size,
                    "sha256": _sha256(path),
                }
            )
    _write_csv(
        reproduction / "raw_logs_index.csv",
        ["task_id", "algorithm", "artifact", "linux_path", "bytes", "sha256"],
        index_rows,
    )

    startup_rows = []
    for algorithm in ALGORITHMS:
        path = root / "startup_acceptance" / algorithm
        log = (path / "run.log").read_text(encoding="utf-8", errors="replace")
        result = re.search(r"Verification result: ([A-Z]+)", log)
        mathsat = re.search(r"MathSAT5 version ([^ ]+)", log)
        startup_rows.append(
            [
                ALGORITHM_ZH[algorithm],
                result.group(1) if result else "未解析",
                mathsat.group(1) if mathsat else "未解析",
                str(path / "run.log"),
                str(path / "time.txt"),
            ]
        )
    startup = """# 四算法启动验收

四种算法均在 S01 原始安全任务上退出 0 并输出 TRUE。配置探测日志另存于 startup_acceptance/*_config_probe；-printUsedOptions 会停止分析，因此与真实运行分开。

""" + _markdown_table(["算法", "结果", "MathSAT5", "运行日志", "资源日志"], startup_rows)
    (reproduction / "启动验收.md").write_text(startup, encoding="utf-8")

    readme = """# Reproduction

本目录保存 VSTTE 2016 四算法对比实验的真实脚本、固定任务清单、作者配置副本、Java 11 最小补丁、版本信息、结构化结果和原始日志索引。

## 复现步骤

1. 在 WSL2 中准备官方 supplements-vstte.tar.bz2 与 sv-benchmarks 的 svcomp16 标签。
2. 建立 CPAchecker/test/programs/benchmarks 指向 sv-comp16/c 的绝对符号链接。
3. 应用 configs/cpa.sh.patch。
4. 在实验根目录运行：
   PYTHONPATH=python-packages python3 scripts/experiment_runner.py manifests/formal24.tsv --phase formal24 --wall-limit 60 --internal-time 55 --heap-mb 1200
5. 完成状态会被跳过；可安全中断后续跑。

## 原始日志

原始日志保留在 Linux 工作目录 runs/formal24/。raw_logs_index.csv 为 96 次运行的 command.txt、run.log、time.txt、status.json 提供绝对路径、字节数和 SHA-256。索引使用 UTF-8 BOM，便于 Excel 打开。

## 限制

请先阅读 environment_report.md。当前 WSL 无法用归档 BenchExec 在 cgroups v2 上可靠施限，因此本复现协议不是论文原协议的等价替代。
"""
    (reproduction / "README.md").write_text(readme, encoding="utf-8")


def generate_delivery(root, output):
    root = pathlib.Path(root)
    output = pathlib.Path(output)
    handoff = output / "PPT_Handoff"
    reproduction = output / "Reproduction"
    (handoff / "figures").mkdir(parents=True, exist_ok=True)
    (handoff / "cases").mkdir(parents=True, exist_ok=True)
    reproduction.mkdir(parents=True, exist_ok=True)

    records = collect_records(root / "runs" / "formal24")
    summary = summarize_algorithms(records)
    full_rows = []
    for record in records:
        full_rows.append(
            {
                **record,
                "category_zh": CATEGORY_ZH[record["category"]],
                "algorithm_zh": ALGORITHM_ZH[record["algorithm"]],
                "log_path": str(pathlib.Path(record["run_dir"]) / "run.log"),
                "time_path": str(pathlib.Path(record["run_dir"]) / "time.txt"),
                "command_path": str(pathlib.Path(record["run_dir"]) / "command.txt"),
            }
        )
    full_fields = [
        "task_id", "task", "expected", "algorithm", "algorithm_zh",
        "category", "category_zh", "raw_result", "exit_code", "wall_seconds",
        "user_time_s", "system_time_s", "max_rss_kb", "heap_mb",
        "internal_time_s", "wall_limit_s", "rationale", "started_utc",
        "finished_utc", "command_path", "log_path", "time_path",
    ]
    _write_csv(handoff / "完整结果.csv", full_fields, full_rows)

    stats_fields = [
        "algorithm", *CATEGORIES, "total", "correct_total", "correct_rate",
        "median_wall_s", "median_correct_wall_s", "total_wall_s",
    ]
    _write_csv(
        handoff / "算法统计汇总.csv",
        stats_fields,
        [summary[algorithm] for algorithm in ALGORITHMS],
    )
    _write_reports(root, handoff, records, summary)
    _generate_charts(records, summary, handoff / "figures")
    _build_reproduction(root, reproduction, records)
    shutil.make_archive(
        str(output / "PPT_Handoff"),
        "zip",
        root_dir=output,
        base_dir="PPT_Handoff",
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=pathlib.Path,
        default=pathlib.Path("/mnt/c/Code/CPAchecker-Course"),
    )
    args = parser.parse_args()
    generate_delivery(pathlib.Path(__file__).resolve().parents[1], args.output)


if __name__ == "__main__":
    main()
