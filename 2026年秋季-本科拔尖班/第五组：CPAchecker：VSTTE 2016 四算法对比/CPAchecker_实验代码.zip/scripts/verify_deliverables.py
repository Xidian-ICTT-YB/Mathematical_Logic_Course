#!/usr/bin/env python3
"""Verify the generated handoff matrix, log index, and ZIP integrity."""

import csv
import collections
import hashlib
import pathlib
import sys
import zipfile


REQUIRED = [
    "PPT_Handoff/实验设置.md",
    "PPT_Handoff/完整结果.csv",
    "PPT_Handoff/算法统计汇总.csv",
    "PPT_Handoff/实验结论.md",
    "PPT_Handoff/figures/四算法验证结果.png",
    "PPT_Handoff/figures/四算法运行时间.png",
    "PPT_Handoff/figures/典型任务差异.png",
    "PPT_Handoff/cases/真实错误轨迹候选.md",
    "PPT_Handoff/cases/算法差异案例.md",
    "PPT_Handoff.zip",
    "Reproduction/README.md",
    "Reproduction/versions.txt",
    "Reproduction/manifests/formal24.tsv",
    "Reproduction/raw_logs_index.csv",
]


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    output = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "/mnt/c/Code/CPAchecker-Course")
    for relative in REQUIRED:
        path = output / relative
        if not path.is_file() or path.stat().st_size == 0:
            raise SystemExit(f"missing or empty: {relative}")
        print(f"FILE\t{relative}\t{path.stat().st_size}")

    results = read_csv(output / "PPT_Handoff/完整结果.csv")
    identities = {(row["task_id"], row["algorithm"]) for row in results}
    if len(results) != 96 or len(identities) != 96:
        raise SystemExit(f"invalid result matrix: rows={len(results)} unique={len(identities)}")

    index = read_csv(output / "Reproduction/raw_logs_index.csv")
    missing = [
        row["linux_path"]
        for row in index
        if not pathlib.Path(row["linux_path"]).is_file()
    ]
    if len(index) != 384 or missing:
        raise SystemExit(f"invalid raw log index: rows={len(index)} missing={len(missing)}")
    hash_mismatches = [
        row["linux_path"]
        for row in index
        if sha256(pathlib.Path(row["linux_path"])) != row["sha256"]
    ]
    if hash_mismatches:
        raise SystemExit(f"raw log hash mismatches: {len(hash_mismatches)}")

    stats = read_csv(output / "PPT_Handoff/算法统计汇总.csv")
    if len(stats) != 4 or any(int(row["total"]) != 24 for row in stats):
        raise SystemExit("invalid algorithm summary totals")
    categories = collections.Counter(row["category"] for row in results)
    if categories["WRONG_RESULT"] != 0 or sum(categories.values()) != 96:
        raise SystemExit(f"invalid result category totals: {dict(categories)}")

    for relative in REQUIRED:
        if relative.endswith(".png"):
            if (output / relative).read_bytes()[:8] != b"\x89PNG\r\n\x1a\n":
                raise SystemExit(f"invalid PNG signature: {relative}")

    with zipfile.ZipFile(output / "PPT_Handoff.zip") as archive:
        bad = archive.testzip()
        names = archive.namelist()
    if bad or not names or not all(name.startswith("PPT_Handoff/") for name in names):
        raise SystemExit(f"invalid zip: bad={bad!r} entries={len(names)}")

    print(f"RESULT_ROWS\t{len(results)}\tUNIQUE\t{len(identities)}")
    print(f"INDEX_ROWS\t{len(index)}\tMISSING\t{len(missing)}")
    print(f"INDEX_HASH_MISMATCHES\t{len(hash_mismatches)}")
    print("CATEGORIES\t" + "\t".join(f"{key}={value}" for key, value in sorted(categories.items())))
    print(f"ZIP_ENTRIES\t{len(names)}\tBAD\t{bad}")


if __name__ == "__main__":
    main()
