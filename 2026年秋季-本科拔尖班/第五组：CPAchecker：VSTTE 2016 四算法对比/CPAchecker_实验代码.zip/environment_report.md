# VSTTE 2016 CPAchecker 四算法实验环境报告

生成日期：2026-10-23（Asia/Shanghai）

## 1. 执行环境

- 宿主调用方式：Windows Native PowerShell 通过 wsl.exe -- bash -lc 调用默认 WSL。
- WSL 发行版：Ubuntu 22.04，x86_64。
- 内核：6.18.40.1-microsoft-standard-WSL2。
- Linux 工作目录：/home/sidusantares/data/cpa/vstte2016-exp。
- Windows 交付目录：C:\\Code\\CPAchecker-Course（WSL 路径 /mnt/c/Code/CPAchecker-Course）。
- 根文件系统可用空间：约 915 GiB。
- 内存：3.8 GiB；检查时约 3.4 GiB 可用。
- Swap：2 GiB，处于启用状态。
- Java：OpenJDK 11.0.29，64 位。
- Python：3.10.12。

## 2. 官方材料

- 论文：https://www.sosy-lab.org/research/pub/2016-VSTTE.SMT-based_Software_Model_Checking_An_Experimental_Comparison_of_Four_Algorithms.pdf
- 官方实验页：https://www.sosy-lab.org/research/k-ind-compare/index-vstte.html
- 官方补充包：https://www.sosy-lab.org/research/k-ind-compare/supplements-vstte.tar.bz2
- 下载文件：supplements-vstte.tar.bz2，HTTP Content-Length 138,287,971 字节。
- SHA-256：0e531f81b8fa079b3611fe22c6c7d3261ed7dbbf9210b23346abab33d14aefe9。
- bzip2 -t 校验通过。

补充包真实顶层结构：

- supplements-vstte/CPAchecker/：二进制发布、配置、脚本和测试集定义。
- supplements-vstte/results/：论文 XML 结果、表格 CSV/HTML 和四算法日志 ZIP。
- supplements-vstte/README：复现实验说明。

## 3. CPAchecker 与求解器

- JAR Manifest 实际版本：CPAchecker 1.6.1-svn 23022。
- 官方网页将归档描述为 cpachecker-1.6.8-vstte。
- 官方历史结果 CSV 表头为 CPAchecker 1.6.1-svn 22870。
- 三处版本标识不一致；本实验按实际 JAR Manifest 记录，不把工具改称 1.6.8。
- JAR 构建环境：Oracle Java 1.8.0_101。
- MathSAT5 随包提供：lib/java/runtime/libmathsat5j.so，x86-64；动态依赖均可解析。
- JavaSMT JAR 含 MathSAT5 适配器与插值接口。
- CBMC 随包提供：lib/native/x86_64-linux/cbmc，静态 x86-64 可执行文件。

### Java 11 最小兼容修复

原 scripts/cpa.sh 把 Java 1.8 转成 18 比较，却把 Java 11 解析成 11，错误报告“Java 太旧”。已仅修正主版本提取和 >=8 判断；CPAchecker JAR、算法配置和求解器均未更换。修复后 CPAchecker 能启动并打印实际版本。

## 4. 四种作者配置

四个官方 test-set XML：

- BMC：test/test-sets/bmc-bitprecise.xml
- k-induction：test/test-sets/k-induction-bitprecise.xml
- Predicate Abstraction with CEGAR：test/test-sets/predicateAnalysis-bitprecise.xml
- Impact：test/test-sets/impact-bitprecise.xml

四者原始统一限制为 900 s CPU、1000 s hard time、15,000 MB 内存、2 核、Java heap 10,000 MB；DeviceDriversLinux64 都附加 -64。四个 rundefinition 使用不同入口和配置，具体启动验收将保存完整命令与日志。

## 5. SV-COMP 2016 数据

按归档 README 从 https://github.com/dbeyer/sv-benchmarks.git 获取固定标签：

- 标签：svcomp16
- 提交：dbb9372541d3c068d970a2b76a92d8fa8f9a9d48
- 克隆方式：--depth 1 --branch svcomp16
- 完成后 Git 工作树修改数：0。
- DeviceDriversLinux64.set 通配展开得到 2168 个候选任务。
- 已建立 README 要求的绝对符号链接：
  CPAchecker/test/programs/benchmarks -> /home/sidusantares/data/cpa/vstte2016-exp/sv-comp16/c

## 6. BenchExec 与资源限制

- README 声明作者使用 BenchExec 1.9。
- 归档实际由 scripts/benchmark.py --version 报告 1.10-dev，并同时携带 BenchExec 1.8 与 1.10-dev wheel。
- WSL 挂载 cgroups v2，当前进程位于 /non-systemd；PID 1 是 WSL /init，没有 systemd user bus。
- 当前用户不能在 /sys/fs/cgroup 根创建控制组。
- 真实 runexecutor.py 探测报告缺少它所要求的 cgroups v1 cpuacct、freezer、memory、cpuset，并以 Cannot limit CPU cores without cpuset cgroup 终止。
- 原始证据：evidence/benchexec_cgroup_probe.log。

因此 BenchExec 1.10-dev 在此 WSL2 环境中不能可靠施加或记录作者协议中的资源限制。未使用 sudo，未修改系统 cgroup 挂载，也未关闭 Swap。

正式运行采用可审计替代：

- GNU timeout：墙钟超时，先 TERM 后 KILL。
- Java -Xmx：限制 CPAchecker 主 JVM 堆。
- GNU /usr/bin/time -v：记录墙钟、CPU、最大常驻集、退出码和信号。
- 单并发：避免 3.8 GiB 主机内存过载。

曾实测 prlimit --as=3.5GB，但 64 位 Java 11 在实际 RSS 仅 71 MiB 时已因约 4 GiB 虚拟地址空间预留失败，故弃用。当前 /sys/fs/cgroup/non-systemd 属于 root 且不可写，无法无 sudo 创建 v2 子控制组。

限制：没有 cgroup 整棵进程树聚合内存硬上限；仅 JVM 堆有硬限制，其他本机内存风险通过单并发控制并由 time -v 审计。CPU 亲和性和 CPU 时间限制也不等价于作者 BenchExec 协议。所有差异会在最终报告中明确列出。

## 7. 已确认的论文协议差异

1. 本机 3.8 GiB 内存无法采用作者 15 GB memory / 10 GB heap。
2. WSL2 cgroups v2 与归档 BenchExec 1.10-dev 不兼容，改用上述审计方案。
3. Swap 保持启用，作者 README 要求 BenchExec 场景关闭 Swap；按用户要求未作系统级修改。
4. Java 11 取代构建时 Java 8，并对启动脚本做了版本检测最小修复。
5. 实际 JAR、网页描述和历史 CSV 的 CPAchecker 版本标识互不一致。
6. 正式实验只选 24 个 DeviceDriversLinux64 任务，不重复论文完整类别。
